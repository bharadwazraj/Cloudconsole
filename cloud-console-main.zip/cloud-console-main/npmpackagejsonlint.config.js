module.exports = {
  extends: '@oss-ui/npm-package-json-lint-config',
  rules: {
    'require-version': 'off',
    'require-main': 'off',
    'require-publishConfig': 'off',
    'no-file-devDependencies': 'off',
    'no-git-devDependencies': 'off',
    'valid-values-name-scope': 'off',
    'no-file-dependencies': 'off',
    'no-git-dependencies': 'off',
  },
};
