import React from 'react';
import { render } from '@testing-library/react';
import { App } from '../App';

const handleRender = () => render(<App />);

describe('<App /> component', () => {
  it('should mount app', () => {
    const { container } = handleRender();
    expect(container).toBeInTheDocument();
  });
});
