import React from 'react';
import { MemoryRouter } from 'react-router-dom';
import type { MemoryRouterProps } from 'react-router';

export const RouterProvider: React.FC<MemoryRouterProps> = ({ children, initialEntries }) => (
  <MemoryRouter initialEntries={initialEntries}>{children}</MemoryRouter>
);
