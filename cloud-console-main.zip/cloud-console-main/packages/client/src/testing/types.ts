import type React from 'react';
import type { MemoryRouterProps } from 'react-router-dom';
import type { IntlProvider } from 'react-intl';
import type { ThemeProvider } from '@onespan/components';
import type { AppProvider, AppStateType } from '../contexts/AppContext';
import type { DeviceListProvider, DeviceListStateType } from '../contexts/DeviceListContext';
import type { RouterProvider } from './RouterProvider';

// whole list of available providers
export type ProviderListType = {
  AppContext: typeof AppProvider;
  DeviceListContext: typeof DeviceListProvider;
  Intl: typeof IntlProvider;
  Router: typeof RouterProvider;
  Theme: typeof ThemeProvider;
};

// mock types
export type IntlMockType = ['Intl', { locale: string }];
export type RouterMockType = ['Router', MemoryRouterProps];
export type AppContextMockType = ['AppContext', { initialState: AppStateType }];
export type DeviceListContextMockType = [
  'DeviceListContext',
  { initialState: DeviceListStateType }
];

// provider type
export type ProviderType =
  | (keyof ProviderListType)[]
  | IntlMockType
  | RouterMockType
  | AppContextMockType
  | DeviceListContextMockType;

// test wrapper
export type TestWrapperType = { children: React.ReactNode; providers: ProviderType[] };
