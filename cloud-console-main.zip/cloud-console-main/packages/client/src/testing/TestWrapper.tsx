import React from 'react';
import { Provider } from './Provider';
import type { TestWrapperType } from './types';
import { getNormalizedProviders, getOrderedProviders, defaultProviders } from './utils';

export const TestWrapper = ({ providers = defaultProviders, children }: TestWrapperType) => {
  const normalizedProviders = getNormalizedProviders(providers);
  const orderedProviders = getOrderedProviders(normalizedProviders).reverse();
  const defaultContent = <div>{children}</div>;
  return orderedProviders.reduce((content, [provider, props = {}]) => {
    return (
      <Provider provider={provider} {...props}>
        {content}
      </Provider>
    );
  }, defaultContent);
};
