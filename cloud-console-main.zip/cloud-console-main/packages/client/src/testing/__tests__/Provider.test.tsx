import { render, screen } from '@testing-library/react';
import React from 'react';
import { TestWrapper } from '../TestWrapper';
import type { ProviderType } from '../types';

const handleRender = (children: React.ReactNode, providers: ProviderType[]) =>
  render(<TestWrapper providers={providers}>{children}</TestWrapper>);

describe('<Provider /> component', () => {
  it('should render <Provider /> component with IntlProvider', () => {
    handleRender(<p>Hello children</p>, [['Intl']]);
    expect(screen.getByText('Hello children')).toBeInTheDocument();
  });

  it('should render <Provider /> component with Empty component', () => {
    handleRender(<p>Hello children</p>, [] as ProviderType[]);
    expect(screen.getByText('Hello children')).toBeInTheDocument();
  });
});
