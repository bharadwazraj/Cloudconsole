import { render, screen } from '@testing-library/react';
import React from 'react';
import { TestWrapper } from '../TestWrapper';
import type { ProviderType } from '../types';

const handleRender = (providers: ProviderType[]) =>
  render(
    <TestWrapper providers={providers}>
      <p>Testing Wrapper</p>
    </TestWrapper>
  );

describe('<TestWrapper />', () => {
  it('should get through first clause of ternary operator in getNormalizedProviders', () => {
    handleRender([['Intl']]);
    expect(screen.getByText('Testing Wrapper')).toBeInTheDocument();
  });

  it('should get sorted providers via getOrderedProviders', () => {
    handleRender([['Theme'], ['Intl']]);
    expect(screen.getByText('Testing Wrapper')).toBeInTheDocument();
  });
});
