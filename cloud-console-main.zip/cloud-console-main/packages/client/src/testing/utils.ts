import type { ProviderListType, ProviderType } from './types';
import { DEVICE_LIST_INITIAL_STATE } from '../contexts/DeviceListContext';

/**
 *   This is the default list of supported providers.
 *   Providers will be rendered in the order they are present in the following array:
 */
export const defaultProviders: ProviderType[] = [
  ['Theme'],
  ['Intl', { locale: 'en' }],
  ['Router', { initialEntries: [{ pathname: '/' }] }],
  ['AppContext', { initialState: { isDrawerOpened: false } }],
  ['DeviceListContext', { initialState: { ...DEVICE_LIST_INITIAL_STATE } }],
];

/**
 *  The flat list of providers:
 *  ['Provider', 'Other provider' ...]
 */
export const availableProviders = [...defaultProviders].map((provider) => provider[0]);

/**
 *  Sorts providers based on the default list, useful in case the consumer sets them in a random order,
 *  or we need to change the order without having to refactor all the tests.
 *  ['Provider', 'Other provider' ...]
 *
 * @param providers
 * @param order
 */
export const getOrderedProviders = (providers: ProviderType[], order = availableProviders) => {
  providers.sort((a, b) => {
    const A = a[0];
    const B = b[0];

    if (order.indexOf(A) > order.indexOf(B)) {
      return 1;
    }
    return -1;
  });

  return providers;
};

/**
 *  Gets the provider in the form of an object
 *  {
 *    Provider: { defaults },
 *    OtherProvider: { defaults }
 *  }
 * @param providers
 */
const getProviderDefaultProps = (
  providers: ProviderType[]
): Record<keyof ProviderListType, object> => {
  return providers.reduce((defaults, provider) => {
    return {
      ...defaults,
      [provider[0]]: provider[1],
    };
  }, {} as Record<keyof ProviderListType, object>);
};

export const providerDefaultProps = getProviderDefaultProps(defaultProviders);

/**
 * Transforms ['Provider', ['Other Provider', {}]] to [['Provider'], ['Other Provider', {}]]
 * @param providers
 */
export const getNormalizedProviders = (providers: ProviderType[]) =>
  providers.map((provider) => (Array.isArray(provider) ? provider : [provider]));
