import React from 'react';
import { IntlProvider } from 'react-intl';
import { ThemeProvider } from '@onespan/components';
import { providerDefaultProps } from './utils';
import { RouterProvider } from './RouterProvider';
import { AppProvider } from '../contexts/AppContext';
import { DeviceListProvider } from '../contexts/DeviceListContext';
import type { ProviderListType } from './types';

const providers: ProviderListType = {
  AppContext: AppProvider,
  DeviceListContext: DeviceListProvider,
  Intl: IntlProvider,
  Router: RouterProvider,
  Theme: ThemeProvider,
};

export const Provider: React.FC<{
  provider: keyof ProviderListType;
}> = ({ provider, ...props }) => {
  const Component = providers[provider];

  // eslint-disable-next-line @typescript-eslint/ban-ts-comment
  // @ts-ignore
  return <Component {...providerDefaultProps[provider]} {...props} />;
};
