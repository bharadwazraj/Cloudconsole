import React from 'react';
import { render, screen } from '@testing-library/react';
import { List } from '@mui/material';
import { ListItems } from '../ListItems';
import type { ListItemType } from '../types';

const listItems: ListItemType[] = [
  {
    divider: true,
    label: 'Number of digipass',
    value: 1000,
  },
];

const handleRender = () =>
  render(
    <List>
      <ListItems listItems={listItems} />
    </List>
  );

describe('should render by default <ListItems /> component', () => {
  it('should match snapshot', () => {
    const { asFragment } = handleRender();
    expect(asFragment()).toMatchSnapshot();
  });

  it('should render by default listItems', () => {
    handleRender();
    expect(screen.getByRole('listitem')).toBeInTheDocument();
    expect(screen.getByText(/digipass/i)).toHaveTextContent('Number of digipass');
    expect(screen.getByText(/1000/i)).toHaveTextContent('1000');
  });
});
