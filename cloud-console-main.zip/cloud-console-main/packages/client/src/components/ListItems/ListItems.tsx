import React from 'react';
import { ListItem as MuiListItem, ListItemText } from '@mui/material';
import type { ListItemsType } from './types';

export const ListItems: React.FC<ListItemsType> = React.memo(
  ({ listItemProps, listItems }: ListItemsType) => {
    return (
      <>
        {listItems.map(({ divider, label, value }, index) => (
          <MuiListItem
            component="li"
            componentsProps={{ root: { role: 'listitem' } }}
            divider={divider}
            // eslint-disable-next-line react/no-array-index-key
            key={index}
            sx={{ padding: (theme) => theme.spacing(2.5) }}
            {...listItemProps}
          >
            <ListItemText
              disableTypography
              primary={label}
              secondary={value}
              sx={{ marginBottom: 0, marginTop: 0 }}
            />
          </MuiListItem>
        ))}
      </>
    );
  }
);
