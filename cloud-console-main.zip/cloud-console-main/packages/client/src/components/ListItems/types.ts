import type { ListItemProps } from '@mui/material';

export type ListItemsType = {
  listItemProps?: ListItemProps;
  listItems: ListItemType[];
};

export type ListItemType = {
  divider?: boolean;
  label: string | React.ReactNode;
  value: string | React.ReactNode;
};
