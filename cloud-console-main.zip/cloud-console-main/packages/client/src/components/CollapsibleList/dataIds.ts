export default {
  CollapsibleList: {
    ExpandLessIcon: {
      id: 'CollapsibleList-ExpandLessIcon',
    },
    ExpandMoreIcon: {
      id: 'CollapsibleList-ExpandMoreIcon',
    },
    id: 'CollapsibleList',
  },
};
