import React, { useCallback, useMemo } from 'react';
import { Collapse, List } from '@mui/material';
import { ExpandLess, ExpandMore } from '@mui/icons-material';
import { ListItems } from '../ListItems';
import {
  StyledPaper,
  StyledSubHeaderText,
  StyledListSubHeaderButton,
} from './CollapsibleList.styled';
import DataIds from './dataIds';
import type { CollapsibleListType } from './types';

export const CollapsibleList: React.FC<CollapsibleListType> = React.memo(
  ({ listItemProps, listItems, listSubHeader }: CollapsibleListType) => {
    const [open, setOpen] = React.useState(true);

    const subHeader = useMemo(() => {
      if (listSubHeader) {
        const { component, text } = listSubHeader;
        return component || <StyledSubHeaderText>{text}</StyledSubHeaderText>;
      }
      return undefined;
    }, [listSubHeader]);

    const handleClick = useCallback(() => {
      setOpen(!open);
    }, [open]);

    const icon = useMemo(
      () =>
        open ? (
          <ExpandLess data-testid={DataIds.CollapsibleList.ExpandLessIcon.id} />
        ) : (
          <ExpandMore data-testid={DataIds.CollapsibleList.ExpandMoreIcon.id} />
        ),
      [open]
    );

    return (
      <StyledPaper elevation={2}>
        <List
          role="list"
          subheader={
            <StyledListSubHeaderButton role="button" onClick={handleClick}>
              {subHeader}
              {icon}
            </StyledListSubHeaderButton>
          }
        >
          <Collapse unmountOnExit in={open} timeout="auto">
            <ListItems listItemProps={listItemProps} listItems={listItems} />
          </Collapse>
        </List>
      </StyledPaper>
    );
  }
);
