import type { ListItemProps } from '@mui/material';
import type { ListItemType } from '../ListItems';

export type CollapsibleListType = {
  listItemProps?: ListItemProps;
  listItems: ListItemType[];
  listSubHeader?: ListSubheaderType;
};

export type ListSubheaderType = {
  component?: string | React.ReactNode;
  text?: string;
};
