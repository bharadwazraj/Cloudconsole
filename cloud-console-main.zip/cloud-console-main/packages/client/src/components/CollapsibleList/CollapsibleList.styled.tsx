import { Paper, styled, Typography } from '@mui/material';

export const StyledListSubHeaderButton = styled('button')(({ theme }) => ({
  alignItems: 'center',
  background: 'transparent',
  border: 'none',
  color: '#444444',
  cursor: 'pointer',
  display: 'flex',
  flexDirection: 'row',
  fontSize: '1rem',
  fontWeight: 600,
  justifyContent: 'space-between',
  lineHeight: '1.5rem',
  minHeight: '64px',
  padding: theme.spacing(0, 2.5),
  width: '100%',
}));

export const StyledSubHeaderText = styled(Typography)(({ theme }) => ({
  color: '#444444',
  fontSize: '1rem',
  fontWeight: 600,
  margin: theme.spacing(0.5, 0, 0, 0),
  padding: 0,
}));

export const StyledPaper = styled(Paper)(({ theme }) => ({
  borderRadius: theme.spacing(0.5),
  marginTop: 0,
  width: '100%',
}));
