import React from 'react';
import { render, screen, waitForElementToBeRemoved } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { CollapsibleList } from '../CollapsibleList';
import DataIds from '../dataIds';
import type { ListItemType } from '../../ListItems';

const listItems: ListItemType[] = [
  {
    divider: true,
    label: 'Number of digipass',
    value: 1000,
  },
];

const handleRender = () => ({
  user: userEvent.setup(),
  ...render(<CollapsibleList listItems={listItems} />),
});

describe('<Collapsable /> component', () => {
  it('should match snapshot', () => {
    const { asFragment } = handleRender();
    expect(asFragment()).toMatchSnapshot();
  });

  it('should render by default <CollapsibleList/>', () => {
    handleRender();
    const button = screen.getByRole('button');
    expect(screen.getByRole('list')).toBeInTheDocument();
    expect(screen.getByRole('listitem')).toBeInTheDocument();
    expect(screen.getByText(/digipass/i)).toHaveTextContent('Number of digipass');
    expect(screen.getByText(/1000/i)).toHaveTextContent('1000');
    expect(button).toHaveStyle({
      alignItems: 'center',
      background: 'transparent',
      border: 'none',
      color: '#444444',
      cursor: 'pointer',
      display: 'flex',
      flexDirection: 'row',
      fontSize: '1rem',
      fontWeight: 600,
      justifyContent: 'space-between',
      lineHeight: '1.5rem',
      minHeight: '64px',
      padding: '0px 20px',
      width: '100%',
    });
  });

  it('should change icon on click and check if list items are empty', async () => {
    const { asFragment, user } = handleRender();
    const button = screen.getByRole('button');
    expect(screen.getByTestId(DataIds.CollapsibleList.ExpandLessIcon.id)).toBeInTheDocument();
    expect(screen.queryByTestId(DataIds.CollapsibleList.ExpandMoreIcon.id)).not.toBeInTheDocument();
    expect(asFragment()).toMatchSnapshot();
    await user.click(button);
    await waitForElementToBeRemoved(() => screen.queryByRole('listitem')).then(() => {
      expect(screen.queryByText(/digipass/i)).not.toBeInTheDocument();
      expect(screen.queryByText(/1000/i)).not.toBeInTheDocument();
    });
    expect(asFragment()).toMatchSnapshot();
    expect(screen.getByTestId(DataIds.CollapsibleList.ExpandMoreIcon.id)).toBeInTheDocument();
    expect(screen.queryByTestId(DataIds.CollapsibleList.ExpandLessIcon.id)).not.toBeInTheDocument();
  });
});
