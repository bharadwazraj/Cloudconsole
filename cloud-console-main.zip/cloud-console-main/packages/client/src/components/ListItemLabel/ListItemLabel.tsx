import React from 'react';
import { Box } from '@mui/material';
import type { ListItemLabelType } from './types';
import { StyledLabel } from './ListItemLabel.styled';

export const ListItemLabel: React.FC<ListItemLabelType> = React.memo(({ component, text }) => {
  if (component) {
    return <Box sx={{ margin: (theme) => theme.spacing(0, 0, 0.5, 0) }}>{component}</Box>;
  }
  if (text) {
    return <StyledLabel>{text}</StyledLabel>;
  }
  return null;
});
