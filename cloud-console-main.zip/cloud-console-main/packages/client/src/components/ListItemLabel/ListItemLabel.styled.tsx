import { styled } from '@mui/material';
import { Typography } from '@onespan/components';

export const StyledLabel = styled(Typography)(({ theme }) => ({
  fontSize: '0.75rem',
  fontWeight: 600,
  lineHeight: '1.25rem',
  margin: theme.spacing(0, 0, 0.5, 0),
  padding: 0,
  textTransform: 'uppercase',
}));
