import type React from 'react';

export type ListItemLabelType = {
  component?: React.ReactNode;
  text?: string;
};
