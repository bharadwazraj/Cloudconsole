import React from 'react';
import { render, screen } from '@testing-library/react';
import type { ListItemLabelType } from '../types';
import { ListItemLabel } from '../ListItemLabel';

const handleRender = (props?: ListItemLabelType) => render(<ListItemLabel {...props} />);

describe('<ListItemLabel /> component', () => {
  it('should check the text <ListItemLabel/> component', () => {
    const { asFragment } = handleRender({ text: 'DigipassLabel' });
    expect(asFragment()).toMatchSnapshot();
    expect(screen.getByText(/digipass/i)).toHaveTextContent('Digipass');
  });

  it('should check the component <ListItemLabel/> is exist', () => {
    const { asFragment } = handleRender({ component: <div>DigipassLabel</div> });
    expect(asFragment()).toMatchSnapshot();
    expect(screen.getByText(/digipass/i)).toHaveTextContent('Digipass');
  });

  it('should check if <ListItemLabel/> component is empty', () => {
    const { asFragment, container } = handleRender();
    expect(asFragment()).toMatchSnapshot();
    expect(container).toBeEmptyDOMElement();
  });
});
