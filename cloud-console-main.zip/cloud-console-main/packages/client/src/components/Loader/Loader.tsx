import React from 'react';
import { CircularProgress } from '@mui/material';
import { StyledBox } from './Loader.styled';

const Loader = () => (
  <StyledBox>
    <CircularProgress sx={{ color: (theme) => theme.palette.primary.main }} />
  </StyledBox>
);

export default React.memo(Loader);
