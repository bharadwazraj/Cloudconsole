import React from 'react';
import { render, screen } from '@testing-library/react';
import Loader from '../Loader';

const handleRender = () => render(<Loader />);

describe('<Loader /> component', () => {
  it('should render <Loader /> component', () => {
    handleRender();
    const progressbar = screen.getByRole('progressbar');
    expect(progressbar).toBeInTheDocument();
  });
});
