import { Box, styled } from '@mui/material';

export const StyledBox = styled(Box)(() => ({
  alignItems: 'center',
  backgroundColor: '#f6f6f6',
  bottom: 0,
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'center',
  left: 0,
  position: 'absolute',
  right: 0,
  top: 0,
  zIndex: 9999,
}));
