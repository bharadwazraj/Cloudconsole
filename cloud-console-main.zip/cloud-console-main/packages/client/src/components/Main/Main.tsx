import React, { PropsWithChildren } from 'react';
import { IntlProvider } from 'react-intl';
import { createMuiTheme, defaultTheme, ThemeProvider } from '@onespan/components';
import CssBaseline from '@mui/material/CssBaseline';
import { AppProvider } from '../../contexts/AppContext';
import messages from '../../shared/i18n/en.json';

const theme = createMuiTheme({
  ...defaultTheme,
  palette: {
    ...defaultTheme.palette,
    background: { default: '#f6f6f6' },
  },
  typography: {
    ...defaultTheme.typography,
    fontFamily: `"Montserrat", "Helvetica", "Arial", sans-serif`,
  },
});

export const Main: React.FC<PropsWithChildren> = React.memo(({ children }) => (
  <ThemeProvider theme={theme}>
    <CssBaseline />
    <IntlProvider locale="en" messages={messages}>
      <AppProvider>{children}</AppProvider>
    </IntlProvider>
  </ThemeProvider>
));
