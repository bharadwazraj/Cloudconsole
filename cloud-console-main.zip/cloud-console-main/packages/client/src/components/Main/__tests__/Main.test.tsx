import React from 'react';
import { render, screen } from '@testing-library/react';
import { Main } from '../Main';

const handleRender = () =>
  render(
    <Main>
      <div data-testid="content" />
    </Main>
  );

describe('<Main /> component', () => {
  it('should render content', () => {
    handleRender();
    const content = screen.getByTestId('content');
    expect(content).toBeInTheDocument();
  });
});
