import React, { useMemo } from 'react';
import { ListSubheader, List as MuiList } from '@mui/material';
import type { ListType } from './types';
import { StyledPaper, StyledSubHeaderText } from './List.styled';
import { ListItems } from '../ListItems';

export const List: React.FC<ListType> = React.memo(
  ({ listItemProps, listItems, listProps, listSubHeader }) => {
    const subHeader = useMemo(() => {
      if (listSubHeader) {
        const { component, text } = listSubHeader;
        return component || <StyledSubHeaderText>{text}</StyledSubHeaderText>;
      }
      return undefined;
    }, [listSubHeader]);

    return (
      <StyledPaper elevation={2}>
        <MuiList
          role="list"
          subheader={<ListSubheader component="div">{subHeader}</ListSubheader>}
          {...listProps}
        >
          <ListItems listItemProps={listItemProps} listItems={listItems} />
        </MuiList>
      </StyledPaper>
    );
  }
);
