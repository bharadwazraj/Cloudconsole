import React from 'react';
import { render, screen } from '@testing-library/react';
import { List } from '../List';
import type { ListItemType } from '../../ListItems';

const listItems: ListItemType[] = [
  {
    divider: true,
    label: 'Number of digipass',
    value: 1000,
  },
];

const handleRender = () => render(<List listItems={listItems} />);

describe('<List /> component', () => {
  it('should match snapshot', () => {
    const { asFragment } = handleRender();
    expect(asFragment()).toMatchSnapshot();
  });

  it('should render by default <List /> component', () => {
    handleRender();
    expect(screen.getByText(/digipass/i)).toHaveTextContent('Number of digipass');
    expect(screen.getByText(/1000/i)).toHaveTextContent('1000');
  });
});
