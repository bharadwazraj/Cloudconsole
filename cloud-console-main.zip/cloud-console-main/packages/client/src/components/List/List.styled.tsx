import { Paper, styled, Typography } from '@mui/material';

export const StyledSubHeaderText = styled(Typography)(({ theme }) => ({
  color: '#444444',
  fontSize: '1rem',
  fontWeight: 600,
  margin: theme.spacing(0.5, 0, 0, 0),
  padding: 0,
}));

export const StyledPaper = styled(Paper)(({ theme }) => ({
  borderRadius: theme.spacing(0.5),
  marginTop: 0,
  width: '100%',
}));
