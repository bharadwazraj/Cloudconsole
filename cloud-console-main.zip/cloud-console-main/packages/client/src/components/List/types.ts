import type { ListItemProps, ListProps } from '@mui/material';
import type { ListItemType } from '../ListItems';

export type ListSubheaderType = {
  component?: string | React.ReactNode;
  text?: string;
};

export type ListType = {
  listItemProps?: ListItemProps;
  listItems: ListItemType[];
  listProps?: ListProps;
  listSubHeader?: ListSubheaderType;
};
