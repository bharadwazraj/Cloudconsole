import React from 'react';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import Loader from '../Loader';

const ManagementConsole = React.lazy(() => import('../../pages/ManagementConsole'));

const router = createBrowserRouter([
  {
    element: <ManagementConsole />,
    path: '/',
  },
]);

export const ReactRouter: React.FC = React.memo(() => (
  <React.Suspense fallback={<Loader />}>
    <RouterProvider router={router} />
  </React.Suspense>
));
