import React from 'react';

export const ColumnResizeIcon: React.FC = React.memo(() => null);
