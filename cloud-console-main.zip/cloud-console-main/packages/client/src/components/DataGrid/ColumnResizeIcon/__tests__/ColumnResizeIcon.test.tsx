import React from 'react';
import { render } from '@testing-library/react';
import { ColumnResizeIcon } from '../ColumnResizeIcon';

const handleRender = () => render(<ColumnResizeIcon />);

describe('<ColumnResizeIcon /> component', () => {
  it('should match to snapshot', () => {
    const { asFragment } = handleRender();
    expect(asFragment()).toMatchSnapshot();
  });

  it('should return empty component', () => {
    const { container } = handleRender();
    expect(container).toBeEmptyDOMElement();
  });
});
