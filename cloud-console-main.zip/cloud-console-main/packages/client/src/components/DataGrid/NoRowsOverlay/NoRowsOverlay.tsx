import React from 'react';
import { GridNoRowsOverlay } from '@mui/x-data-grid';
import type { EnhancedDataGridProps } from '../types';
import { StyledDiv } from './NoRowsOverlay.styled';
import DataIds from './dataIds';

export const NoRowsOverlay: React.FC<Pick<EnhancedDataGridProps, 'noRowsOverlayText'>> = React.memo(
  ({ noRowsOverlayText }) => {
    if (noRowsOverlayText) {
      return <StyledDiv data-testid={DataIds.NoRowsOverlay.id}>{noRowsOverlayText}</StyledDiv>;
    }
    return <GridNoRowsOverlay data-testid={DataIds.NoRowsOverlay.id} />;
  }
);
