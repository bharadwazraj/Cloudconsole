export default {
  NoRowsOverlay: {
    id: 'NoRowsOverlay',
  },
};
