import React from 'react';
import { render, screen } from '@testing-library/react';
import { DataGridMock } from '../../__mocks__';
import { NoRowsOverlay } from '../NoRowsOverlay';

const NO_ROWS_OVERLAY_TEXT = 'Some custom no overlay text.';

const handleRender = (noRowsOverlayText?: string) => {
  return render(
    <DataGridMock
      components={{ NoRowsOverlay: () => <NoRowsOverlay noRowsOverlayText={noRowsOverlayText} /> }}
      rows={[]}
    />
  );
};

describe('<NoRowsOverlay /> component', () => {
  it('should match to snapshot', () => {
    const { asFragment } = handleRender();
    expect(asFragment()).toMatchSnapshot();
  });

  it('should display default overlay text', () => {
    handleRender();
    expect(screen.getByText(/no rows/i)).toHaveTextContent('No rows');
  });

  it('should display provided overlay text', () => {
    const { asFragment } = handleRender(NO_ROWS_OVERLAY_TEXT);
    const noRowsOverlayText = screen.getByText(/custom/i);
    expect(asFragment()).toMatchSnapshot();
    expect(noRowsOverlayText).toHaveTextContent(NO_ROWS_OVERLAY_TEXT);
    expect(noRowsOverlayText).toHaveStyle({
      alignItems: 'center',
      color: '#444444',
      display: 'flex',
      flexDirection: 'row',
      fontSize: '0.875rem',
      height: '100%',
      justifyContent: 'center',
      lineHeight: '1.5rem',
      padding: '20px',
    });
  });
});
