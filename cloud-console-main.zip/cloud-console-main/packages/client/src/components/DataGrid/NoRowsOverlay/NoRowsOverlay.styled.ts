import { styled } from '@mui/material';

export const StyledDiv = styled('div')(({ theme }) => ({
  alignItems: 'center',
  color: '#444444',
  display: 'flex',
  flexDirection: 'row',
  fontSize: '0.875rem',
  height: '100%',
  justifyContent: 'center',
  lineHeight: '1.5rem',
  padding: theme.spacing(2.5),
}));
