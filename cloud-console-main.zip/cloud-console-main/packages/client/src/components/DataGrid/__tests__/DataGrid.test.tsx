import React from 'react';
import { render, screen } from '@testing-library/react';
import type { GridColumns, GridSortModel } from '@mui/x-data-grid';
import type { GridRowsProp } from '@mui/x-data-grid/models/gridRows';
import { TestWrapper } from '../../../testing';
import { DataGrid } from '../DataGrid';
import type { EnhancedDataGridProps } from '../types';
import DataIds from '../dataIds';

type RowType = { id: number; text: string };

const columns: GridColumns<RowType> = [{ field: 'id', flex: 1, headerName: 'ID' }];
const rows: GridRowsProp<RowType> = [
  { id: 1, text: '1st value' },
  { id: 2, text: '2nd value' },
  { id: 3, text: '3rd value' },
  { id: 4, text: '4th value' },
  { id: 5, text: '5th value' },
];
const sortModel: GridSortModel = [{ field: 'id', sort: 'asc' }];
const filters: EnhancedDataGridProps['filters'] = [
  {
    formFieldProps: { id: '' },
    options: [{ optionProps: { value: 'ACTIVE' }, optionText: 'Active' }],
    selectProps: { value: 'ACTIVE' },
  },
];

const handleRender = () => {
  return render(
    <TestWrapper providers={[['Intl']]}>
      <DataGrid
        dataGridProps={{
          columns,
          filters,
          initialState: { sorting: { sortModel } },
          page: 0,
          pageSize: 25,
          rows,
          totalCount: rows.length,
        }}
      />
    </TestWrapper>
  );
};

describe('<DataGrid /> component', () => {
  it('should match to snapshot', () => {
    const { asFragment } = handleRender();
    expect(asFragment()).toMatchSnapshot();
  });

  it('should has <StyledContainerBox /> component correct styles', () => {
    handleRender();
    expect(screen.getByTestId(DataIds.DataGrid.StyledContainerBox.id)).toHaveStyle({
      display: 'flex',
      height: '100%',
      maxHeight: '1440px',
      minHeight: '450px',
    });
  });

  it('should has <StyledInnerContainerBox /> component correct styles', () => {
    handleRender();
    expect(screen.getByTestId(DataIds.DataGrid.StyledInnerContainerBox.id)).toHaveStyle({
      flexGrow: 1,
    });
  });
});
