import { render, screen } from '@testing-library/react';
import React from 'react';
import { TestWrapper } from '@cloud-console/test';
import type { FiltersType } from '../types';
import DataIds from '../dataIds';
import { Filters } from '../Filters';
import type { DataGridFilterType } from '../../../types';

const formFieldProps: DataGridFilterType['formFieldProps'] = { id: '' };
const options: DataGridFilterType['options'] = [
  { optionProps: { value: 'ACTIVE' }, optionText: 'Active' },
];
const selectProps: DataGridFilterType['selectProps'] = { value: 'ACTIVE' };

const handleRender = (filters?: FiltersType['filters']) => {
  return render(
    <TestWrapper providers={[['Intl']]}>
      <Filters filters={filters} />
    </TestWrapper>
  );
};

describe('<Filters /> component', () => {
  it('should match to snapshot', () => {
    const { asFragment } = handleRender([{ formFieldProps, options, selectProps }]);
    expect(asFragment()).toMatchSnapshot();
  });

  it('should not render filters', () => {
    handleRender();
    expect(screen.getByTestId(DataIds.Filters.id)).toBeEmptyDOMElement();
  });

  it('should render filters', () => {
    const { asFragment } = handleRender([{ formFieldProps, options, selectProps }]);
    expect(asFragment()).toMatchSnapshot();
    expect(screen.getByTestId(DataIds.Filters.id)).not.toBeEmptyDOMElement();
  });
});
