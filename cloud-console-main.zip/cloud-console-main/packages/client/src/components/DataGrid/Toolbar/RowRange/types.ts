import type { ToolbarType } from '../types';

export type RowRangeType = Pick<ToolbarType, 'totalCount'>;
