export default {
  RowRange: {
    id: 'RowRange',
  },
};
