import CheckIcon from '@mui/icons-material/Check';
import { InputAdornment, ListItemText, OutlinedInput, Paper, styled } from '@mui/material';

export const StyledPaper = styled(Paper, {
  shouldForwardProp: (prop) => prop !== 'hasFormFieldLabelText',
})<{ hasFormFieldLabelText: boolean }>(({ hasFormFieldLabelText, theme }) => ({
  // it depends on @onespan/components, need to remove margin-top when there is no form label
  '& > div > div > div': {
    marginTop: hasFormFieldLabelText ? theme.spacing(0.5) : 0,
  },
  borderRadius: '4px',
  marginRight: theme.spacing(2.5),
}));

export const StyledOutlinedInput = styled(OutlinedInput)(({ theme }) => ({
  '& .MuiListItemIcon-root': {
    display: 'none',
  },
  borderRadius: '4px',
  cursor: 'pointer',
  margin: 0,
  minHeight: '44px',
  padding: theme.spacing(1.25, 2.5),
}));

export const StyledInputAdornment = styled(InputAdornment)(() => ({
  color: 'rgba(0, 0, 0, 0.57)',
  cursor: 'pointer',
  fontSize: '0.875rem',
  fontWeight: 400,
  lineHeight: '1.5rem',
  margin: 0,
  padding: 0,
}));

export const StyledCheckIcon = styled(CheckIcon)(() => ({
  color: '#757575',
  fontSize: '1.25rem',
}));

export const StyledOptionText = styled(ListItemText)(() => ({
  color: '#444444',
  fontSize: '0.875rem',
  fontWeight: 500,
  lineHeight: '1.25rem',
  margin: 0,
  padding: 0,
}));
