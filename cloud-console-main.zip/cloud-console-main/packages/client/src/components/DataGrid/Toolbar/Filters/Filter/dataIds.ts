export default {
  Filter: {
    ListItemIcon: {
      id: 'Filter-ListItemIcon',
    },
    StyledCheckIcon: {
      id: 'Filter-StyledCheckIcon',
    },
    StyledInputAdornment: {
      id: 'Filter-StyledInputAdornment',
    },
    StyledListItemText: {
      id: 'Filter-StyledListItemText',
    },
    StyledMenuItem: {
      id: 'Filter-StyledMenuItem',
    },
    StyledOutlinedInput: {
      id: 'Filter-StyledOutlinedInput',
    },
    StyledPaper: {
      id: 'Filter-StyledPaper',
    },
    id: 'Filter',
  },
};
