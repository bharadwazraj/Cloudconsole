import React, { useMemo } from 'react';
import {
  gridPageCountSelector,
  gridPageSizeSelector,
  gridPaginationRowRangeSelector,
  useGridApiContext,
  useGridSelector,
} from '@mui/x-data-grid';
import { useIntl } from 'react-intl';
import messages from './messages';
import type { RowRangeType } from './types';
import { useTotalCountAbbreviation } from './hooks/useTotalCountAbbreviation';
import DataIds from './dataIds';
import { StyledBox } from './RowRange.styled';

// do not set React.memo(), as this will cause a problem with pagination status refreshing
export const RowRange: React.FC<RowRangeType> = ({ totalCount }) => {
  const { formatMessage } = useIntl();
  const totalCountAbbreviation = useTotalCountAbbreviation(totalCount);
  const apiRef = useGridApiContext();
  const pageCount = useGridSelector(apiRef, gridPageCountSelector);
  const pageSize = useGridSelector(apiRef, gridPageSizeSelector);
  const rowRange = useGridSelector(apiRef, gridPaginationRowRangeSelector);

  const value = useMemo(() => {
    if (rowRange) {
      let { firstRowIndex, lastRowIndex } = rowRange;

      firstRowIndex += 1;
      lastRowIndex += 1;

      if (lastRowIndex <= pageSize && pageCount === 1) {
        return formatMessage(messages.onePageResults, { lastRowIndex });
      }

      return formatMessage(messages.multiPageResults, {
        firstRowIndex,
        lastRowIndex,
        totalCount: totalCountAbbreviation,
      });
    }
    return formatMessage(messages.zeroResults);
  }, [formatMessage, pageCount, pageSize, rowRange, totalCountAbbreviation]);

  return <StyledBox data-testid={DataIds.RowRange.id}>{value}</StyledBox>;
};
