import React from 'react';
import { render, screen } from '@testing-library/react';
import { DataGridMock } from '../../__mocks__';
import { Toolbar } from '../Toolbar';
import { TestWrapper } from '../../../../testing';
import DataIds from '../dataIds';

const handleRender = () => {
  return render(
    <TestWrapper providers={[['Intl']]}>
      <DataGridMock components={{ Toolbar: () => <Toolbar filters={[]} totalCount={0} /> }} />
    </TestWrapper>
  );
};

describe('<Toolbar /> component', () => {
  it('should match to snapshot', () => {
    const { asFragment } = handleRender();
    expect(asFragment()).toMatchSnapshot();
  });

  it('should <StyledGridContainer /> has correct styles', () => {
    handleRender();
    const styledGridContainer = screen.getByTestId(DataIds.Toolbar.StyledGridContainer.id);
    expect(styledGridContainer).toHaveStyle({
      marginBottom: '20px',
    });
  });

  it('should <StyledGridItem /> has correct styles', () => {
    handleRender();
    const styledGridItem = screen.getByTestId(DataIds.Toolbar.StyledGridItem.id);
    expect(styledGridItem).toHaveStyle({
      alignItems: 'center',
      display: 'flex',
      flexDirection: 'row',
      justifyContent: 'space-between',
    });
  });
});
