import { renderHook } from '@testing-library/react';
import { useTotalCountAbbreviation } from '../useTotalCountAbbreviation';

const handleRender = (totalCount: number) =>
  renderHook(() => useTotalCountAbbreviation(totalCount));

describe('useTotalCountAbbreviation() hook', () => {
  it('should return value without abbreviation', () => {
    const { result } = handleRender(999);
    expect(result.current).toEqual('999');
  });

  it('should return value with "k+" abbreviation', () => {
    const { result } = handleRender(999999);
    expect(result.current).toEqual('999k+');
  });

  it('should return value with "kk+" abbreviation', () => {
    const { result } = handleRender(999999999);
    expect(result.current).toEqual('999kk+');
  });

  it('should return value with "kkk+" abbreviation', () => {
    const { result } = handleRender(999999999999);
    expect(result.current).toEqual('999kkk+');
  });
});
