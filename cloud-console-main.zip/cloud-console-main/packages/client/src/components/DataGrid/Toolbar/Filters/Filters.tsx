import React, { useMemo } from 'react';
import type { FiltersType } from './types';
import { Filter } from './Filter';
import { StyledBox } from './Filters.styled';
import DataIds from './dataIds';

export const Filters: React.FC<FiltersType> = React.memo(({ filters }) => {
  const items = useMemo(() => {
    if (filters) {
      return filters.map(
        (
          {
            formFieldLabelText,
            formFieldProps,
            hasOptionIcon,
            options,
            selectProps,
            startAdornmentText,
          },
          index
        ) => {
          return (
            <Filter
              formFieldLabelText={formFieldLabelText}
              formFieldProps={formFieldProps}
              hasOptionIcon={hasOptionIcon}
              // eslint-disable-next-line react/no-array-index-key
              key={index}
              options={options}
              selectProps={selectProps}
              startAdornmentText={startAdornmentText}
            />
          );
        }
      );
    }
    return null;
  }, [filters]);

  return <StyledBox data-testid={DataIds.Filters.id}>{items}</StyledBox>;
});
