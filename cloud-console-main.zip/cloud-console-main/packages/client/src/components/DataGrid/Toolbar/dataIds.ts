export default {
  Toolbar: {
    StyledGridContainer: {
      id: 'Toolbar-StyledGridContainer',
    },
    StyledGridItem: {
      id: 'Toolbar-StyledGridItem',
    },
    id: 'Toolbar',
  },
};
