export default {
  Filters: {
    id: 'Filters',
  },
};
