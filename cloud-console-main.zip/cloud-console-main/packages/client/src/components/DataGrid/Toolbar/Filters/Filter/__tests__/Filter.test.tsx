import React from 'react';
import { render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Filter } from '../Filter';
import type { DataGridFilterType } from '../../../../types';
import DataIds from '../dataIds';
import DescendingIconDataIds from '../../../../ColumnSortedDescendingIcon/dataIds';
import AscendingIconDataIds from '../../../../ColumnSortedAscendingIcon/dataIds';

const handleRender = ({ ...props }: DataGridFilterType) => ({
  user: userEvent.setup(),
  ...render(<Filter {...props} />),
});

const formFieldProps: DataGridFilterType['formFieldProps'] = { id: '' };
const selectProps: DataGridFilterType['selectProps'] = { value: '' };
const options: DataGridFilterType['options'] = [
  { optionProps: { value: 'ACTIVE' }, optionText: 'Active' },
];

describe('<Filter /> component', () => {
  it('should match to snapshot', () => {
    const { asFragment } = handleRender({ formFieldProps, options, selectProps });
    expect(asFragment()).toMatchSnapshot();
  });

  it('should has <StyledPaper /> component correct styles', () => {
    handleRender({ formFieldProps, options, selectProps });
    expect(screen.getByTestId(DataIds.Filter.StyledPaper.id)).toHaveStyle({
      borderRadius: '4px',
      marginRight: '20px',
    });
  });

  it('should has <StyledOutlinedInput /> component correct styles', () => {
    handleRender({ formFieldProps, options, selectProps });
    expect(screen.getByTestId(DataIds.Filter.id)).toHaveStyle({
      borderRadius: '4px',
      cursor: 'pointer',
      margin: 0,
      minHeight: '44px',
      padding: '10px 20px',
    });
  });

  describe('when select is closed', () => {
    beforeEach(() => handleRender({ formFieldProps, options, selectProps }));

    it('should has descending icon', () => {
      expect(
        screen.getByTestId(DescendingIconDataIds.ColumnSortedDescendingIcon.id)
      ).toBeInTheDocument();
    });

    it('should not has ascending icon', () => {
      expect(
        screen.queryByTestId(AscendingIconDataIds.ColumnSortedAscendingIcon.id)
      ).not.toBeInTheDocument();
    });
  });

  describe('when select is open', () => {
    it('should has ascending icon', async () => {
      const { user } = handleRender({ formFieldProps, options, selectProps });
      const filter = within(screen.getByTestId(DataIds.Filter.id));
      await user.click(filter.getByRole('button'));
      expect(
        screen.getByTestId(AscendingIconDataIds.ColumnSortedAscendingIcon.id)
      ).toBeInTheDocument();
    });

    it('should not has descending icon', async () => {
      const { user } = handleRender({ formFieldProps, options, selectProps });
      const filter = within(screen.getByTestId(DataIds.Filter.id));
      await user.click(filter.getByRole('button'));
      expect(
        screen.queryByTestId(DescendingIconDataIds.ColumnSortedDescendingIcon.id)
      ).not.toBeInTheDocument();
    });

    it('should render correct number of items', async () => {
      const { user } = handleRender({ formFieldProps, options, selectProps });
      const filter = within(screen.getByTestId(DataIds.Filter.id));
      await user.click(filter.getByRole('button'));
      const presentation = within(screen.getByRole('presentation'));
      const listbox = presentation.getByRole('listbox');
      expect(listbox.children.length).toEqual(1);
    });

    it('should has <StyledMenuItem /> component correct styles', async () => {
      const { user } = handleRender({ formFieldProps, options, selectProps });
      const filter = within(screen.getByTestId(DataIds.Filter.id));
      await user.click(filter.getByRole('button'));
      const presentation = within(screen.getByRole('presentation'));
      const listbox = presentation.getByRole('listbox');
      const option = within(listbox).getByRole('option');
      expect(option).toHaveStyle({
        margin: '0px',
        paddingBottom: '12px',
        paddingTop: '12px',
      });
    });

    it('should has <StyledListItemText /> component correct styles', async () => {
      const { user } = handleRender({ formFieldProps, options, selectProps });
      const filter = within(screen.getByTestId(DataIds.Filter.id));
      await user.click(filter.getByRole('button'));
      const presentation = within(screen.getByRole('presentation'));
      const listbox = presentation.getByRole('listbox');
      const text = within(listbox).getByText(/active/i);
      expect(text).toHaveStyle({
        fontSize: '0.875rem',
        fontWeight: 500,
        lineHeight: '1.25rem',
        margin: 0,
        padding: 0,
      });
    });

    describe('when "hasListItemIcon" is "true" and "selectProps.value" does not match "menuItemProps.value"', () => {
      it('should render <ListItemIcon /> and should not render <StyledCheckIcon /> component', async () => {
        const { user } = handleRender({
          formFieldProps,
          hasOptionIcon: true,
          options,
          selectProps: { value: '' },
        });
        const filter = within(screen.getByTestId(DataIds.Filter.id));
        await user.click(filter.getByRole('button'));
        const presentation = within(screen.getByRole('presentation'));
        expect(presentation.getByTestId(DataIds.Filter.ListItemIcon.id)).toBeInTheDocument();
        expect(
          presentation.queryByTestId(DataIds.Filter.StyledCheckIcon.id)
        ).not.toBeInTheDocument();
      });
    });

    describe('when "hasListItemIcon" is "true" and "selectProps.value" match "menuItemProps.value"', () => {
      it('should render <ListItemIcon /> and <StyledCheckIcon /> component', async () => {
        const { user } = handleRender({
          formFieldProps,
          hasOptionIcon: true,
          options,
          selectProps: { value: 'ACTIVE' },
        });
        await user.click(within(screen.getByTestId(DataIds.Filter.id)).getByRole('button'));
        const presentation = within(screen.getByRole('presentation'));
        expect(presentation.getByTestId(DataIds.Filter.ListItemIcon.id)).toBeInTheDocument();
        expect(presentation.getByTestId(DataIds.Filter.StyledCheckIcon.id)).toBeInTheDocument();
      });

      it('should has <StyledCheckIcon /> component correct styles', async () => {
        const { user } = handleRender({
          formFieldProps,
          hasOptionIcon: true,
          options,
          selectProps: { value: 'ACTIVE' },
        });
        await user.click(within(screen.getByTestId(DataIds.Filter.id)).getByRole('button'));
        const presentation = within(screen.getByRole('presentation'));
        expect(presentation.getByTestId(DataIds.Filter.StyledCheckIcon.id)).toHaveStyle({
          color: '#757575',
          fontSize: '1.25rem',
        });
      });
    });
  });

  describe('start adornment text', () => {
    it('should not be in the document when "startAdornmentText" is not defined', () => {
      handleRender({ formFieldProps, options, selectProps });
      expect(screen.queryByTestId(DataIds.Filter.StyledInputAdornment.id)).not.toBeInTheDocument();
    });

    it('should be in the document when "startAdornmentText" is defined', () => {
      handleRender({ formFieldProps, options, selectProps, startAdornmentText: 'Status' });
      const startAdornmentText = screen.getByTestId(DataIds.Filter.StyledInputAdornment.id);
      expect(startAdornmentText).toBeInTheDocument();
      expect(startAdornmentText).toHaveTextContent('Status');
    });

    it('should has <StyledInputAdornment /> component correct styles', () => {
      handleRender({ formFieldProps, options, selectProps, startAdornmentText: 'Status' });
      expect(screen.getByTestId(DataIds.Filter.StyledInputAdornment.id)).toHaveStyle({
        color: 'rgba(0, 0, 0, 0.57)',
        cursor: 'pointer',
        fontSize: '0.875rem',
        fontWeight: 400,
        lineHeight: '1.5rem',
        margin: 0,
        padding: 0,
      });
    });
  });
});
