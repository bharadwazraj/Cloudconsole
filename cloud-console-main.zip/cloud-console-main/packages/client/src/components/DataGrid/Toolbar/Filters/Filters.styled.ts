import { styled } from '@mui/material';
import { Box } from '@onespan/components';

export const StyledBox = styled(Box)(() => ({
  display: 'flex',
}));
