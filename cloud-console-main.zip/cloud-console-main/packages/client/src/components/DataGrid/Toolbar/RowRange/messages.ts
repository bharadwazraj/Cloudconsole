import { defineMessages } from 'react-intl';

export default defineMessages({
  multiPageResults: {
    defaultMessage: '{firstRowIndex}-{lastRowIndex} of {totalCount} results',
    id: 'components.DataGrid.Toolbar.multiPageResults',
  },
  onePageResults: {
    defaultMessage: '{lastRowIndex} results',
    id: 'components.DataGrid.Toolbar.onePageResults',
  },
  zeroResults: {
    defaultMessage: '0 results',
    id: 'components.DataGrid.Toolbar.noResults',
  },
});
