import type { ToolbarType } from '../types';

export type FiltersType = Pick<ToolbarType, 'filters'>;
