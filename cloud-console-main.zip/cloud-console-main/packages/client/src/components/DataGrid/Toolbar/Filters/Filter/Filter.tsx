import React, { useCallback, useMemo, useState } from 'react';
import { ListItemIcon } from '@mui/material';
import { Box, FormField, FormFieldLabel, Option, Select } from '@onespan/components';
import type { Theme } from '@mui/material/styles';
import type { DataGridFilterType } from '../../../types';
import {
  StyledCheckIcon,
  StyledInputAdornment,
  StyledOptionText,
  StyledOutlinedInput,
  StyledPaper,
} from './Filter.styled';
import { ColumnSortedDescendingIcon } from '../../../ColumnSortedDescendingIcon';
import { ColumnSortedAscendingIcon } from '../../../ColumnSortedAscendingIcon';
import DataIds from './dataIds';

export const Filter: React.FC<DataGridFilterType> = React.memo(
  ({
    formFieldLabelText,
    formFieldProps,
    hasOptionIcon,
    options,
    selectProps,
    startAdornmentText,
  }) => {
    const [open, setOpen] = useState(false);

    const handleClick = useCallback(() => {
      setOpen(!open);
    }, [open]);

    const iconComponent = useMemo(
      () => (open ? ColumnSortedAscendingIcon : ColumnSortedDescendingIcon),
      [open]
    );

    const startAdornment = useMemo(() => {
      if (startAdornmentText) {
        return (
          <StyledInputAdornment
            disableTypography
            data-testid={DataIds.Filter.StyledInputAdornment.id}
            position="start"
            onClick={handleClick}
          >
            {startAdornmentText}
          </StyledInputAdornment>
        );
      }
      return undefined;
    }, [handleClick, startAdornmentText]);

    const formFieldLabel = useMemo(() => {
      if (formFieldLabelText) {
        return <FormFieldLabel>{formFieldLabel}</FormFieldLabel>;
      }
      // need to return an empty box element that is not visible cause,
      // <FormField /> require an array of children with more than one element
      return <Box sx={{ display: 'none' }} />;
    }, [formFieldLabelText]);

    return (
      <StyledPaper
        data-testid={DataIds.Filter.StyledPaper.id}
        elevation={2}
        hasFormFieldLabelText={!!formFieldLabelText}
      >
        <FormField {...formFieldProps}>
          {formFieldLabel}
          <Select
            data-testid={DataIds.Filter.id}
            IconComponent={iconComponent}
            input={<StyledOutlinedInput onClick={handleClick} />}
            open={open}
            startAdornment={startAdornment}
            MenuProps={{
              MenuListProps: { sx: { padding: (theme) => theme.spacing(1, 0) } },
              PaperProps: { elevation: 2 },
            }}
            onClick={handleClick}
            {...selectProps}
          >
            {options.map(({ optionIconProps, optionProps, optionText, optionTextProps }, index) => {
              return (
                <Option
                  // eslint-disable-next-line react/no-array-index-key
                  key={index}
                  sx={{
                    margin: 0,
                    paddingBottom: (theme: Theme) => theme.spacing(1.5),
                    paddingTop: (theme: Theme) => theme.spacing(1.5),
                  }}
                  {...optionProps}
                >
                  {hasOptionIcon && (
                    <ListItemIcon data-testid={DataIds.Filter.ListItemIcon.id} {...optionIconProps}>
                      {selectProps?.value === optionProps?.value && (
                        <StyledCheckIcon data-testid={DataIds.Filter.StyledCheckIcon.id} />
                      )}
                    </ListItemIcon>
                  )}
                  <StyledOptionText
                    disableTypography
                    data-testid={DataIds.Filter.StyledListItemText.id}
                    primary={optionText}
                    {...optionTextProps}
                  />
                </Option>
              );
            })}
          </Select>
        </FormField>
      </StyledPaper>
    );
  }
);
