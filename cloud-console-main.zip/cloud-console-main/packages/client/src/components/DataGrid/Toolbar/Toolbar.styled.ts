import { Grid, styled } from '@mui/material';

export const StyledGridContainer = styled(Grid)(({ theme }) => ({
  marginBottom: theme.spacing(2.5),
}));

export const StyledGridItem = styled(Grid)(() => ({
  alignItems: 'center',
  display: 'flex',
  flexDirection: 'row',
  justifyContent: 'space-between',
}));
