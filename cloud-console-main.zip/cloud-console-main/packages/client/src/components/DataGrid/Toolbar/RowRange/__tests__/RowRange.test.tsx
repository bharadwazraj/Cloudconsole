import React from 'react';
import { render, screen } from '@testing-library/react';
import { TestWrapper } from '@cloud-console/test';
import { DataGridMock } from '../../../__mocks__';
import { Toolbar } from '../../Toolbar';
import DataIds from '../dataIds';
import type { DataGridMockType } from '../../../__mocks__/types';
import type { ToolbarType } from '../../types';

const handleRender = (
  { ...props }: DataGridMockType,
  { totalCount }: Pick<ToolbarType, 'totalCount'>
) => {
  return render(
    <TestWrapper providers={[['Intl']]}>
      <DataGridMock
        components={{ Toolbar: () => <Toolbar filters={[]} totalCount={totalCount} /> }}
        {...props}
      />
    </TestWrapper>
  );
};

describe('<RowRange /> component', () => {
  it('should match to snapshot', () => {
    const { asFragment } = handleRender({ numberOfRows: 9 }, { totalCount: 10 });
    expect(asFragment()).toMatchSnapshot();
  });

  it('should display row range for one page result', () => {
    handleRender({ numberOfRows: 9 }, { totalCount: 10 });
    expect(screen.getByTestId(DataIds.RowRange.id)).toHaveTextContent('10 results');
  });

  it('should display row range for multi page result', () => {
    const { asFragment } = handleRender({ numberOfRows: 999 }, { totalCount: 1001 });
    expect(asFragment()).toMatchSnapshot();
    expect(screen.getByTestId(DataIds.RowRange.id)).toHaveTextContent('1-25 of 1k+ results');
  });

  it('should display row range for zero result', () => {
    const { asFragment } = handleRender({ numberOfRows: 0, rows: [] }, { totalCount: 0 });
    expect(asFragment()).toMatchSnapshot();
    expect(screen.getByTestId(DataIds.RowRange.id)).toHaveTextContent('0 results');
  });

  it('should render row range text with correct styles', () => {
    handleRender({ numberOfRows: 999 }, { totalCount: 1001 });
    expect(screen.getByTestId(DataIds.RowRange.id)).toHaveStyle({
      color: '#444444',
      fontSize: '0.875rem',
      fontWeight: 400,
      lineHeight: '1.25rem',
    });
  });
});
