const abbreviations = ['k+', 'kk+', 'kkk+']; // abbreviations in steps of 1000x

const round = (totalCount: number, precision: number) => {
  // 10 ** 1 = 10, 10 ** 2 = 100 etc.
  const power = 10 ** precision;
  return Math.floor(totalCount * power) / power; // .floor() for down, .round() for up
};

export const useTotalCountAbbreviation = (totalCount: number, precision = 0): string => {
  let base = Math.floor(Math.log(Math.abs(totalCount)) / Math.log(1000));
  const suffix = abbreviations[Math.min(abbreviations.length - 1, base - 1)];
  base = abbreviations.indexOf(suffix) + 1;
  return suffix ? `${round(totalCount / 1000 ** base, precision)}${suffix}` : `${totalCount}`;
};
