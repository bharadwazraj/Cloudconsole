import React from 'react';
import { StyledGridContainer, StyledGridItem } from './Toolbar.styled';
import type { ToolbarType } from './types';
import { RowRange } from './RowRange';
import { Filters } from './Filters';
import DataIds from './dataIds';

// do not set React.memo(), as this will cause a problem with pagination status refreshing
export const Toolbar: React.FC<ToolbarType> = ({ filters, totalCount }) => {
  return (
    <StyledGridContainer container data-testid={DataIds.Toolbar.StyledGridContainer.id}>
      <StyledGridItem item data-testid={DataIds.Toolbar.StyledGridItem.id} xs={12}>
        <Filters filters={filters} />
        <RowRange totalCount={totalCount} />
      </StyledGridItem>
    </StyledGridContainer>
  );
};
