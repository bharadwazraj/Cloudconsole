import type { EnhancedDataGridProps } from '../types';

export type ToolbarType = Pick<EnhancedDataGridProps, 'filters' | 'totalCount'>;
