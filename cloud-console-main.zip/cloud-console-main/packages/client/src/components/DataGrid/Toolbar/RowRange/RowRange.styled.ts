import { styled } from '@mui/material';
import { Box } from '@onespan/components';

export const StyledBox = styled(Box)(() => ({
  color: '#444444',
  fontSize: '0.875rem',
  fontWeight: 400,
  lineHeight: '1.25rem',
}));
