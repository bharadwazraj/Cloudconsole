export default {
  ColumnUnsortedIcon: {
    id: 'ColumnUnsortedIcon',
  },
};
