import React from 'react';
import { render } from '@testing-library/react';
import { ColumnUnsortedIcon } from '../ColumnUnsortedIcon';

const handleRender = () => render(<ColumnUnsortedIcon />);

describe('<ColumnUnsortedIcon /> component', () => {
  it('should match to snapshot', () => {
    const { asFragment } = handleRender();
    expect(asFragment()).toMatchSnapshot();
  });

  it('should render sorted unsorted icon', () => {
    const { container } = handleRender();
    const svg = container.querySelector('svg');
    expect(svg).toBeInTheDocument();
    expect(svg).toHaveAttribute('fill', 'none');
    expect(svg).toHaveAttribute('height', '24');
    expect(svg).toHaveAttribute('viewBox', '0 0 24 24');
    expect(svg).toHaveAttribute('width', '24');
    expect(svg?.firstChild).toBeInTheDocument();
    expect(svg?.firstChild).toHaveAttribute(
      'd',
      'M11.2966 6.99624L8.70663 9.58624C8.07663 10.2162 8.51663 11.2962 9.40663 11.2962H14.5866C15.4766 11.2962 15.9266 10.2162 15.2966 9.58624L12.7066 6.99624C12.3166 6.60624 11.6866 6.60624 11.2966 6.99624ZM11.2966 17.0037L8.70663 14.4137C8.07663 13.7837 8.51663 12.7037 9.40663 12.7037H14.5866C15.4766 12.7037 15.9266 13.7837 15.2966 14.4137L12.7066 17.0037C12.3166 17.3937 11.6866 17.3937 11.2966 17.0037Z'
    );
    expect(svg?.firstChild).toHaveAttribute('fill', '#757575');
  });
});
