import React, { useCallback } from 'react';
import type { Theme } from '@mui/material/styles';
import { StyledContainerBox, StyledDataGrid, StyledInnerContainerBox } from './DataGrid.styled';
import type { DataGridType } from './types';
import { ColumnSortedAscendingIcon } from './ColumnSortedAscendingIcon';
import { ColumnSortedDescendingIcon } from './ColumnSortedDescendingIcon';
import { ColumnUnsortedIcon } from './ColumnUnsortedIcon';
import { Footer } from './Footer';
import { ColumnResizeIcon } from './ColumnResizeIcon';
import { NoRowsOverlay } from './NoRowsOverlay';
import { Toolbar } from './Toolbar';
import DataIds from './dataIds';

export const DataGrid: React.FC<DataGridType> = React.memo(
  ({ boxContainerProps, boxInnerContainerProps, dataGridProps }) => {
    const { filters, noRowsOverlayText, totalCount } = dataGridProps;

    const noRowsOverlay = useCallback(
      () => <NoRowsOverlay noRowsOverlayText={noRowsOverlayText} />,
      [noRowsOverlayText]
    );

    const toolbar = useCallback(
      () => <Toolbar filters={filters} totalCount={totalCount} />,
      [filters, totalCount]
    );

    return (
      <StyledContainerBox
        data-testid={DataIds.DataGrid.StyledContainerBox.id}
        {...boxContainerProps}
      >
        <StyledInnerContainerBox
          data-testid={DataIds.DataGrid.StyledInnerContainerBox.id}
          {...boxInnerContainerProps}
        >
          <StyledDataGrid
            disableColumnMenu
            disableSelectionOnClick
            pagination
            headerHeight={64}
            rowHeight={64}
            components={{
              ColumnResizeIcon,
              ColumnSortedAscendingIcon,
              ColumnSortedDescendingIcon,
              ColumnUnsortedIcon,
              Footer,
              NoRowsOverlay: noRowsOverlay,
              Toolbar: toolbar,
            }}
            componentsProps={{
              basePopper: {
                sx: {
                  '& .MuiDataGrid-menuList': {
                    '& > .MuiMenuItem-root': {
                      fontSize: '0.875rem',
                      lineHeight: '1.25rem',
                      margin: 0,
                      padding: (theme: Theme) => theme.spacing(1.5, 2),
                    },
                    minWidth: '240px',
                    padding: (theme: Theme) => theme.spacing(1, 0),
                  },
                },
              },
            }}
            {...dataGridProps}
          />
        </StyledInnerContainerBox>
      </StyledContainerBox>
    );
  }
);
