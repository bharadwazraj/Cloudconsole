export default {
  DataGrid: {
    StyledContainerBox: {
      id: 'DataGrid-StyledContainerBox',
    },
    StyledInnerContainerBox: {
      id: 'DataGrid-StyledInnerContainerBox',
    },
    id: 'DataGrid',
  },
};
