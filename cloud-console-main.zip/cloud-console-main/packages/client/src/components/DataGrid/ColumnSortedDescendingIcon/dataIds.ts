export default {
  ColumnSortedDescendingIcon: {
    id: 'ColumnSortedDescendingIcon',
  },
};
