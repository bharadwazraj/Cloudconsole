import React from 'react';
import { render } from '@testing-library/react';
import { ColumnSortedDescendingIcon } from '../ColumnSortedDescendingIcon';

const handleRender = () => render(<ColumnSortedDescendingIcon />);

describe('<ColumnSortedDescendingIcon /> component', () => {
  it('should match to snapshot', () => {
    const { asFragment } = handleRender();
    expect(asFragment()).toMatchSnapshot();
  });

  it('should render sorted descending icon', () => {
    const { container } = handleRender();
    const svg = container.querySelector('svg');
    expect(svg).toBeInTheDocument();
    expect(svg).toHaveAttribute('fill', 'none');
    expect(svg).toHaveAttribute('height', '24');
    expect(svg).toHaveAttribute('viewBox', '0 0 24 24');
    expect(svg).toHaveAttribute('width', '24');
    expect(svg?.firstChild).toBeInTheDocument();
    expect(svg?.firstChild).toHaveAttribute(
      'd',
      'M8.70623 11.4137L11.2962 14.0037C11.6862 14.3937 12.3162 14.3937 12.7062 14.0037L15.2962 11.4137C15.9262 10.7837 15.4762 9.70375 14.5862 9.70375H9.40623C8.51623 9.70375 8.07623 10.7837 8.70623 11.4137Z'
    );
    expect(svg?.firstChild).toHaveAttribute('fill', '#757575');
  });
});
