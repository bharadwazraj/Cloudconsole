import { styled } from '@mui/material';
import { DataGrid } from '@mui/x-data-grid';
import { Box } from '@onespan/components';

const borderColor = 'rgba(0, 0, 0, 0.1)';

export const StyledContainerBox = styled(Box)(() => ({
  display: 'flex',
  height: '100%',
  maxHeight: '1440px',
  minHeight: '450px',
}));

export const StyledInnerContainerBox = styled(Box)(() => ({
  flexGrow: 1,
}));

export const StyledDataGrid = styled(DataGrid)(() => ({
  '& .MuiDataGrid-cell': {
    '&:focus, &:focus-within': {
      outline: 'unset',
    },
    borderColor,
  },
  '& .MuiDataGrid-cellContent': {
    color: '#444444',
    lineHeight: '1.5rem',
  },
  '& .MuiDataGrid-columnHeader': {
    '&:focus, &:focus-within': {
      outline: 'unset',
    },
  },
  '& .MuiDataGrid-columnHeaderTitle': {
    color: '#444444',
    fontSize: '0.875rem',
    fontWeight: '400',
    lineHeight: '1.5rem',
  },
  '& .MuiDataGrid-columnHeaders': {
    borderColor,
  },
  '& .MuiDataGrid-iconButtonContainer': {
    '> button:hover, > button:focus': {
      '& > .MuiTouchRipple-root': {
        display: 'none',
      },
      backgroundColor: 'unset',
    },
    visibility: 'visible',
    width: 'auto',
  },
  '& .MuiDataGrid-main': {
    backgroundColor: '#ffffff',
    borderColor,
    borderStyle: 'solid',
    borderTopLeftRadius: '4px',
    borderTopRightRadius: '4px',
    borderWidth: '1px 1px 0 1px',
    boxShadow: '0 0 0 1px rgb(0 0 0 / 4%), 0 0 10px 0 rgb(0 0 0 / 4%)',
  },
  border: 'none',
}));
