import type { DataGridProps } from '@mui/x-data-grid';
import type { ListItemIconProps, ListItemTextProps } from '@mui/material';
import type {
  BoxProps,
  FormFieldProps,
  MenuItemProps,
  OptionProps,
  SelectProps,
} from '@onespan/components';

export type DataGridType = {
  boxContainerProps?: BoxProps;
  boxInnerContainerProps?: BoxProps;
  dataGridProps: DataGridProps & EnhancedDataGridProps;
};

export type EnhancedDataGridProps = {
  filters?: DataGridFilterType[];
  noRowsOverlayText?: string;
  totalCount: number;
};

export type DataGridFilterType = {
  formFieldLabelText?: string;
  formFieldProps: Omit<FormFieldProps, 'children' | 'ref'>;
  hasOptionIcon?: boolean;
  options: DataGridFilterOptionType[];
  selectProps?: Omit<SelectProps, 'children' | 'ref'>;
  startAdornmentText?: string;
};

export type DataGridFilterOptionType = {
  optionIconProps?: ListItemIconProps;
  optionProps?: Omit<OptionProps, 'children' | 'ref'> & Omit<MenuItemProps, 'children' | 'ref'>;
  optionText: string;
  optionTextProps?: ListItemTextProps;
};
