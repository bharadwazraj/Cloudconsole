import React, { useMemo } from 'react';
import { DataGrid, GridColumns } from '@mui/x-data-grid';
import type { GridRowsProp } from '@mui/x-data-grid/models/gridRows';
import { Box } from '@onespan/components';
import type { DataGridMockType } from './types';

type RowType = { id: number };

const columns: GridColumns<RowType> = [{ field: 'id', flex: 1, headerName: 'ID' }];

const data = (index: number): RowType => ({ id: index });

const generate = (numberOfRows: number) => {
  const array = [];
  // eslint-disable-next-line no-plusplus
  for (let index = 0; index <= numberOfRows; index++) {
    array.push(data(index + 1));
  }
  return array;
};

export const DataGridMock: React.FC<DataGridMockType> = (props) => {
  const { numberOfRows } = props;
  const rows: GridRowsProp<RowType> = useMemo(() => generate(numberOfRows || 9), [numberOfRows]);
  return (
    <Box sx={{ height: '500px', width: '100%' }}>
      <DataGrid disableSelectionOnClick columns={columns} pageSize={25} rows={rows} {...props} />
    </Box>
  );
};
