import type { DataGridProps } from '@mui/x-data-grid';

export type DataGridMockType = { numberOfRows?: number } & Partial<DataGridProps>;
