export default {
  Pagination: {
    PageOfPageCount: {
      id: 'Pagination-PageOfPageCount',
    },
    id: 'Pagination',
  },
};
