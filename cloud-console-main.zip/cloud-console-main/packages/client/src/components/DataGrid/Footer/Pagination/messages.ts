import { defineMessages } from 'react-intl';

export default defineMessages({
  pageOfPageCount: {
    defaultMessage: '{page} of {pageCount}',
    id: 'components.DataGrid.Footer.Pagination.pageOfPageCount',
  },
});
