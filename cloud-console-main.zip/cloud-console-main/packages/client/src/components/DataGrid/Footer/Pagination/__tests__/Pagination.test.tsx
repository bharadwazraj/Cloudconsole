import React from 'react';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { TestWrapper } from '@cloud-console/test';
import { DataGridMock } from '../../../__mocks__';
import { Pagination } from '../Pagination';
import DataIds from '../dataIds';

const FIRST_LIST_ITEM = 0;
const SECOND_LIST_ITEM = 1;
const THIRD_LIST_ITEM = 2;
const FOURTH_LIST_ITEM = 3;
const FIFTH_LIST_ITEM = 4;

const getListItems = () =>
  screen.getAllByRole('listitem').filter((listItem) => Boolean(listItem.firstChild));

// by default <DataGridMock /> has 10 elements, by changing pageSize to 5 it will set to pages to 2,
// that means we could test the displaying row range like "1 of 2"
const handleRender = () => ({
  user: userEvent.setup(),
  ...render(
    <TestWrapper providers={[['Intl']]}>
      <DataGridMock components={{ Pagination }} pageSize={5} />
    </TestWrapper>
  ),
});

describe('<Pagination /> component', () => {
  it('should match to snapshot', () => {
    const { asFragment } = handleRender();
    expect(asFragment()).toMatchSnapshot();
  });

  it('should render correct number of list items for pagination', () => {
    handleRender();
    const listItems = getListItems();
    expect(listItems).toHaveLength(5);
  });

  it('should render correct list items for pagination', () => {
    handleRender();
    const listItems = getListItems();
    const goToFirstPageButton = listItems[FIRST_LIST_ITEM].firstChild;
    const gotoPreviousPage = listItems[SECOND_LIST_ITEM].firstChild;
    const rowRange = listItems[THIRD_LIST_ITEM];
    const goToNextPage = listItems[FOURTH_LIST_ITEM].firstChild;
    const goToLastPage = listItems[FIFTH_LIST_ITEM].firstChild;
    expect(goToFirstPageButton).toBeInTheDocument();
    expect(goToFirstPageButton).toBeDisabled();
    expect(goToFirstPageButton).toHaveAccessibleName('Go to first page');
    expect(gotoPreviousPage).toBeInTheDocument();
    expect(gotoPreviousPage).toBeDisabled();
    expect(gotoPreviousPage).toHaveAccessibleName('Go to previous page');
    expect(rowRange).toBeInTheDocument();
    expect(rowRange).toHaveTextContent('1 of 2');
    expect(goToNextPage).toBeInTheDocument();
    expect(goToNextPage).not.toBeDisabled();
    expect(goToNextPage).toHaveStyle({
      color: '#757575',
    });
    expect(goToNextPage).toHaveAccessibleName('Go to next page');
    expect(goToLastPage).toBeInTheDocument();
    expect(goToLastPage).not.toBeDisabled();
    expect(goToNextPage).toHaveStyle({
      color: '#757575',
    });
    expect(goToLastPage).toHaveAccessibleName('Go to last page');
  });

  it('should change page', async () => {
    const { user } = handleRender();
    const listItemsBeforeClick = getListItems();
    const goToNextPageButton = listItemsBeforeClick[FOURTH_LIST_ITEM]
      .firstChild as HTMLButtonElement;
    const rowRangeBeforeClick = listItemsBeforeClick[THIRD_LIST_ITEM];
    expect(rowRangeBeforeClick).toHaveTextContent('1 of 2');
    await user.click(goToNextPageButton);
    const listItemsAfterClick = getListItems();
    const rowRangeAfterClick = listItemsAfterClick[THIRD_LIST_ITEM];
    expect(rowRangeAfterClick).toHaveTextContent('2 of 2');
  });

  it('should render page of page count with correct styles', () => {
    handleRender();
    expect(screen.getByTestId(DataIds.Pagination.PageOfPageCount.id)).toHaveStyle({
      fontSize: '0.875rem',
      fontWeight: 500,
      lineHeight: '1.5rem',
    });
  });
});
