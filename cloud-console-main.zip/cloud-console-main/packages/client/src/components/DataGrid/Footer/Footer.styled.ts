import { styled } from '@mui/material';
import { GridFooterContainer } from '@mui/x-data-grid';

export const StyledGridFooterContainer = styled(GridFooterContainer)(() => ({
  backgroundColor: '#ffffff',
  border: '1px solid rgba(0, 0, 0, 0.1)',
  borderRadius: '0 0 4px 4px',
  boxShadow: '0 0 0 1px rgb(0 0 0 / 4%), 0 0 10px 0 rgb(0 0 0 / 4%)',
  height: '64px',
  justifyContent: 'center',
  lineHeight: '4rem',
  minHeight: '64px',
}));
