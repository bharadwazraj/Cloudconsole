import React from 'react';
import { render, screen } from '@testing-library/react';
import { Footer } from '../Footer';
import { DataGridMock } from '../../__mocks__';
import DataIds from '../dataIds';
import { TestWrapper } from '../../../../testing';

const handleRender = () =>
  render(
    <TestWrapper providers={[['Intl']]}>
      <DataGridMock components={{ Footer }} />
    </TestWrapper>
  );

describe('<Footer />', () => {
  it('should match to snapshot', () => {
    const { asFragment } = handleRender();
    expect(asFragment()).toMatchSnapshot();
  });

  it('should render by default', () => {
    handleRender();
    const styledGridFooterContainer = screen.getByTestId(
      DataIds.Footer.StyledGridFooterContainer.id
    );
    expect(styledGridFooterContainer).toBeInTheDocument();
    expect(styledGridFooterContainer).toHaveStyle({
      backgroundColor: '#ffffff',
      border: '1px solid rgba(0, 0, 0, 0.1)',
      borderRadius: '0 0 4px 4px',
      boxShadow: '0 0 0 1px rgb(0 0 0 / 4%),0 0 10px 0 rgb(0 0 0 / 4%)',
      height: '64px',
      justifyContent: 'center',
      lineHeight: '4rem',
      minHeight: '64px',
    });
  });
});
