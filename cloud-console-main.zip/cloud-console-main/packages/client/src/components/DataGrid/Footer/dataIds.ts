export default {
  Footer: {
    StyledGridFooterContainer: {
      id: 'Footer-StyledGridFooterContainer',
    },
    id: 'Footer',
  },
};
