import React from 'react';
import { Pagination } from './Pagination';
import { StyledGridFooterContainer } from './Footer.styled';
import DataIds from './dataIds';

// do not set React.memo(), as this will cause a problem with pagination status refreshing
export const Footer: React.FC = () => {
  return (
    <StyledGridFooterContainer data-testid={DataIds.Footer.StyledGridFooterContainer.id}>
      <Pagination />
    </StyledGridFooterContainer>
  );
};
