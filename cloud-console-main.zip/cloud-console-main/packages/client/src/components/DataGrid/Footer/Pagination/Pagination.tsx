import React from 'react';
import {
  gridPageCountSelector,
  gridPageSelector,
  useGridApiContext,
  useGridSelector,
} from '@mui/x-data-grid';
import { Pagination as MuiPagination } from '@mui/material';
import { useIntl } from 'react-intl';
import { StyledPaginationItem, StyledSpan } from './Pagination.styled';
import messages from './messages';
import DataIds from './dataIds';

// do not set React.memo(), as this will cause a problem with pagination status refreshing
export const Pagination: React.FC = () => {
  const { formatMessage } = useIntl();
  const apiRef = useGridApiContext();
  const page = useGridSelector(apiRef, gridPageSelector);
  const pageCount = useGridSelector(apiRef, gridPageCountSelector);
  return (
    <MuiPagination
      showFirstButton
      showLastButton
      count={pageCount}
      page={page + 1}
      renderItem={(params) => {
        if (params.type === 'first') return <StyledPaginationItem {...params} />;
        if (params.type === 'previous') return <StyledPaginationItem {...params} />;
        if (params.type === 'page' && params.page === page + 1) {
          return (
            <StyledSpan data-testid={DataIds.Pagination.PageOfPageCount.id}>
              {formatMessage(messages.pageOfPageCount, { page: params.page, pageCount })}
            </StyledSpan>
          );
        }
        if (params.type === 'next') return <StyledPaginationItem {...params} />;
        if (params.type === 'last') return <StyledPaginationItem {...params} />;
        return null;
      }}
      onChange={(_, value) => apiRef.current.setPage(value - 1)}
    />
  );
};
