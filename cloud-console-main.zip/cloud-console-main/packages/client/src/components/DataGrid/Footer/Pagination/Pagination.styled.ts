import { PaginationItem, styled } from '@mui/material';

export const StyledPaginationItem = styled(PaginationItem)(() => ({
  '&:not(disabled)': {
    color: '#757575',
  },
}));

export const StyledSpan = styled('span')(() => ({
  fontSize: '0.875rem',
  fontWeight: 500,
  lineHeight: '1.5rem',
}));
