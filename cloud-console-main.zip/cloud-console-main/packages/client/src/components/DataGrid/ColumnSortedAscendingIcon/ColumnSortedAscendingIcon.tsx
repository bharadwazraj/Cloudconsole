import React from 'react';
import { SvgIcon } from '@mui/material';
import DataIds from './dataIds';

export const ColumnSortedAscendingIcon: React.FC = React.memo(() => {
  return (
    <SvgIcon
      data-testid={DataIds.ColumnSortedAscendingIcon.id}
      fill="none"
      height={24}
      viewBox="0 0 24 24"
      width={24}
    >
      <path
        d="M8.70623 12.5862L11.2962 9.99625C11.6862 9.60625 12.3162 9.60625 12.7062 9.99625L15.2962 12.5862C15.9262 13.2162 15.4762 14.2962 14.5862 14.2962H9.40623C8.51623 14.2962 8.07623 13.2162 8.70623 12.5862Z"
        fill="#757575"
      />
    </SvgIcon>
  );
});
