import React from 'react';
import { render } from '@testing-library/react';
import { ColumnSortedAscendingIcon } from '../ColumnSortedAscendingIcon';

const handleRender = () => render(<ColumnSortedAscendingIcon />);

describe('<ColumnSortedAscendingIcon /> component', () => {
  it('should match to snapshot', () => {
    const { asFragment } = handleRender();
    expect(asFragment()).toMatchSnapshot();
  });

  it('should render sorted ascending icon', () => {
    const { container } = handleRender();
    const svg = container.querySelector('svg');
    expect(svg).toBeInTheDocument();
    expect(svg).toHaveAttribute('fill', 'none');
    expect(svg).toHaveAttribute('height', '24');
    expect(svg).toHaveAttribute('viewBox', '0 0 24 24');
    expect(svg).toHaveAttribute('width', '24');
    expect(svg?.firstChild).toBeInTheDocument();
    expect(svg?.firstChild).toHaveAttribute(
      'd',
      'M8.70623 12.5862L11.2962 9.99625C11.6862 9.60625 12.3162 9.60625 12.7062 9.99625L15.2962 12.5862C15.9262 13.2162 15.4762 14.2962 14.5862 14.2962H9.40623C8.51623 14.2962 8.07623 13.2162 8.70623 12.5862Z'
    );
    expect(svg?.firstChild).toHaveAttribute('fill', '#757575');
  });
});
