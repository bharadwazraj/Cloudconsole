export default {
  ColumnSortedAscendingIcon: {
    id: 'ColumnSortedAscendingIcon',
  },
};
