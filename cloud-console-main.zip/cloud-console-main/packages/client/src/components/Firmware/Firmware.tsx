import React from 'react';
import { FirmwareLatest } from './FirmwareLatest';

export const Firmware: React.FC = React.memo(() => {
  return <FirmwareLatest />;
});
