import { styled } from '@mui/system';
import { Typography } from '@onespan/components';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import MemoryIcon from '@mui/icons-material/Memory';
import { Stack } from '@mui/material';

export const StyledStack = styled(Stack)(({ theme }) => ({
  alignItems: 'center',
  display: 'flex',
  flexDirection: 'row',
  gap: theme.spacing(1),
}));

export const StyledMemoryIcon = styled(MemoryIcon)(() => ({
  color: '#757575',
  fontSize: '1.125rem',
  lineHeight: '1.5rem',
}));

export const StyledVersion = styled(Typography)(() => ({
  fontSize: '0.875rem',
  lineHeight: '1.5rem',
}));

export const StyledCircleIcon = styled(CheckCircleIcon)(({ theme }) => ({
  color: '#0B6634',
  fontSize: '1rem',
  lineHeight: '1.25rem',
  margin: theme.spacing(0.5, 0, 0.5, 0),
}));

export const StyledLatest = styled(Typography)(() => ({
  color: '#0B6634',
  fontSize: '0.875rem',
  fontWeight: 400,
  lineHeight: '1.25rem',
}));

export const StyledCaption = styled(Typography)(() => ({
  color: '#444',
  fontSize: '0.75rem',
  fontWeight: 400,
  lineHeight: '1.25rem',
  margin: 0,
  padding: 0,
}));
