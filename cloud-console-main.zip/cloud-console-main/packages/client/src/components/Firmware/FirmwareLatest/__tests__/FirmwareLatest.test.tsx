import React from 'react';
import { render, screen } from '@testing-library/react';
import { FirmwareLatest } from '../FirmwareLatest';
import { TestWrapper } from '../../../../testing';
import DataIds from '../dataIds';
import messages from '../messages';

const handleRender = () =>
  render(
    <TestWrapper providers={[['Intl']]}>
      <FirmwareLatest />
    </TestWrapper>
  );

describe('<FirmwareLatest /> component', () => {
  it('should match to snapshot', () => {
    const { asFragment } = handleRender();
    expect(asFragment()).toMatchSnapshot();
  });

  it('should render correct icons <MemoryIcon/> and <CheckCircleIcon/>', () => {
    handleRender();
    expect(screen.getByTestId(DataIds.FirmwareLatest.MemoryIcon.id)).toBeInTheDocument();
    expect(screen.getByTestId(DataIds.FirmwareLatest.CheckCircleIcon.id)).toBeInTheDocument();
  });

  it('should has correct version information text', () => {
    handleRender();
    expect(screen.getByTestId(DataIds.FirmwareLatest.Latest.id)).toHaveTextContent(
      messages.latest.defaultMessage
    );
  });

  it('should has correct caption text', () => {
    handleRender();
    expect(screen.getByTestId(DataIds.FirmwareLatest.Caption.id)).toHaveTextContent(
      messages.caption.defaultMessage
    );
  });
});
