import React from 'react';
import { useIntl } from 'react-intl';
import { Box } from '@onespan/components';
import {
  StyledCaption,
  StyledCircleIcon,
  StyledLatest,
  StyledMemoryIcon,
  StyledStack,
  StyledVersion,
} from './FirmwareLatest.styled';
import messages from './messages';
import DataIds from './dataIds';

export const FirmwareLatest: React.FC = React.memo(() => {
  const { formatMessage } = useIntl();

  return (
    <Box data-testid={DataIds.FirmwareLatest.id}>
      <StyledStack>
        <StyledMemoryIcon data-testid={DataIds.FirmwareLatest.MemoryIcon.id} />
        <StyledVersion data-testid={DataIds.FirmwareLatest.Version.id}>v8.255565</StyledVersion>
        <StyledCircleIcon data-testid={DataIds.FirmwareLatest.CheckCircleIcon.id} />
        <StyledLatest data-testid={DataIds.FirmwareLatest.Latest.id}>
          {formatMessage(messages.latest)}
        </StyledLatest>
      </StyledStack>
      <StyledCaption data-testid={DataIds.FirmwareLatest.Caption.id}>
        {formatMessage(messages.caption)}
      </StyledCaption>
    </Box>
  );
});
