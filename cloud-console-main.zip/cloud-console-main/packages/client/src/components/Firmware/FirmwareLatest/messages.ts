import { defineMessages } from 'react-intl';

export default defineMessages({
  caption: {
    defaultMessage: 'You are already using the latest version of firmware.',
    id: 'components.Firmware.FirmwareLatest.label.caption',
  },
  latest: {
    defaultMessage: 'Latest',
    id: 'components.Firmware.FirmwareLatest.label.latest',
  },
});
