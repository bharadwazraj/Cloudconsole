export default {
  FirmwareLatest: {
    Caption: {
      id: 'FirmwareLatest-Caption',
    },
    CheckCircleIcon: {
      id: 'FirmwareLatest-CheckCircleIcon',
    },
    Latest: {
      id: 'FirmwareLatest-Latest',
    },
    MemoryIcon: {
      id: 'FirmwareLatest-MemoryIcon',
    },
    Version: {
      id: 'FirmwareLatest-Version',
    },
    id: 'FirmwareLatest',
  },
};
