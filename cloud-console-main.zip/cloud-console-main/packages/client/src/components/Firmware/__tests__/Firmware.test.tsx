import React from 'react';
import { render } from '@testing-library/react';
import { Firmware } from '../Firmware';
import { TestWrapper } from '../../../testing';

const handleRender = () =>
  render(
    <TestWrapper providers={[['Intl']]}>
      <Firmware />
    </TestWrapper>
  );

describe('<Firmware /> component', () => {
  it('should match to snapshot', () => {
    const { asFragment } = handleRender();
    expect(asFragment()).toMatchSnapshot();
  });
});
