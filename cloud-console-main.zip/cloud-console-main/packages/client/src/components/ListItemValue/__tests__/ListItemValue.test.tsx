import React from 'react';
import { render, screen } from '@testing-library/react';
import { ListItemValue } from '../ListItemValue';
import type { ListItemValueType } from '../types';

const handleRender = (props?: ListItemValueType) => render(<ListItemValue {...props} />);

describe('<ListItemValue /> component', () => {
  it('should check the text <ListItemValue/> component', () => {
    const { asFragment } = handleRender({ text: 'Digipass' });
    expect(asFragment()).toMatchSnapshot();
    expect(screen.getByText(/digipass/i)).toHaveTextContent('Digipass');
  });

  it('should check the component <ListItemValue/> is exist', () => {
    const { asFragment } = handleRender({ component: <div>Digipass</div> });
    expect(asFragment()).toMatchSnapshot();
    expect(screen.getByText(/digipass/i)).toHaveTextContent('Digipass');
  });

  it('should check if <ListItemValue/> component is empty', () => {
    const { asFragment, container } = handleRender();
    expect(asFragment()).toMatchSnapshot();
    expect(container).toBeEmptyDOMElement();
  });
});
