import { styled } from '@mui/material';
import { Typography } from '@onespan/components';

export const StyledValue = styled(Typography)(() => ({
  fontSize: '0.875rem',
  fontWeight: 400,
  lineHeight: '1.25rem',
  margin: 0,
  padding: 0,
}));
