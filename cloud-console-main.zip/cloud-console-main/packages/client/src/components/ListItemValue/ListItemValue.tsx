import React from 'react';
import { Box } from '@mui/material';
import type { ListItemValueType } from './types';
import { StyledValue } from './ListItemValue.styled';

export const ListItemValue: React.FC<ListItemValueType> = React.memo(({ component, text }) => {
  if (component) {
    return <Box>{component}</Box>;
  }
  if (text) {
    return <StyledValue>{text}</StyledValue>;
  }
  return null;
});
