import type React from 'react';

export type ListItemValueType = {
  component?: React.ReactNode;
  text?: string;
};
