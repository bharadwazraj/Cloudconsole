export default {
  DeviceStatusChip: {
    Active: {
      Label: {
        id: 'DeviceStatusChip-Active-Label',
      },
      id: 'DeviceStatusChip-Active',
    },
    Blocked: {
      Label: {
        id: 'DeviceStatusChip-Blocked-Label',
      },
      id: 'DeviceStatusChip-Blocked',
    },
    BlockedPending: {
      Label: {
        id: 'DeviceStatusChip-BlockedPending-Label',
      },
      id: 'DeviceStatusChip-BlockedPending',
    },
    Inactive: {
      Label: {
        id: 'DeviceStatusChip-Inactive-Label',
      },
      id: 'DeviceStatusChip-Inactive',
    },
    ResetPending: {
      Label: {
        id: 'DeviceStatusChip-ResetPending-Label',
      },
      id: 'DeviceStatusChip-ResetPending',
    },
    UnblockPending: {
      Label: {
        id: 'DeviceStatusChip-UnblockPending-Label',
      },
      id: 'DeviceStatusChip-UnblockPending',
    },
    id: 'DeviceStatusChip',
  },
};
