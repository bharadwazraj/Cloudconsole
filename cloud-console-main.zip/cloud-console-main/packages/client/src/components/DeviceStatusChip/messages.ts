import { defineMessages } from 'react-intl';

export default defineMessages({
  active: {
    defaultMessage: 'Active',
    id: 'components.DeviceStatusChip.active',
  },
  blocked: {
    defaultMessage: 'Blocked',
    id: 'components.DeviceStatusChip.blocked',
  },
  blockedPending: {
    defaultMessage: 'Blocked pending',
    id: 'components.DeviceStatusChip.blockedPending',
  },
  inactive: {
    defaultMessage: 'Inactive',
    id: 'components.DeviceStatusChip.inactive',
  },
  resetPending: {
    defaultMessage: 'Reset pending',
    id: 'components.DeviceStatusChip.resetPending',
  },
  startAdornmentText: {
    defaultMessage: 'Status',
    id: 'components.DeviceStatusChip.startAdornmentText',
  },
  unblockPending: {
    defaultMessage: 'Unblock pending',
    id: 'components.DeviceStatusChip.unblockPending',
  },
});
