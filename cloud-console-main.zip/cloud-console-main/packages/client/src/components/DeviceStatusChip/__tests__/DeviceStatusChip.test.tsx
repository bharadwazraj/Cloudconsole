import React from 'react';
import { render, screen } from '@testing-library/react';
import { camelCase } from 'lodash-es';
import { TestWrapper } from '../../../testing';
import { DeviceStatusChip } from '../DeviceStatusChip';
import type { DeviceStatusType } from '../types';
import messages from '../messages';
import DataIds from '../dataIds';

const handleRender = (status: DeviceStatusType['status']) => {
  return render(
    <TestWrapper providers={[['Intl']]}>
      <DeviceStatusChip status={status} />
    </TestWrapper>
  );
};

describe('<DeviceStatusChip /> component', () => {
  describe('when success', () => {
    it('should render <StyledSuccessChip /> with correct styles', () => {
      handleRender('ACTIVE');
      expect(screen.getByTestId(DataIds.DeviceStatusChip.Active.id)).toHaveStyle({
        backgroundColor: 'rgba(12, 120, 62, 0.09)',
        borderRadius: '99px',
        height: '24px',
        padding: '4px 8px',
      });
    });

    it('should render <StyledSuccessLabelChip /> with correct styles', () => {
      handleRender('ACTIVE');
      expect(screen.getByTestId(DataIds.DeviceStatusChip.Active.Label.id)).toHaveStyle({
        color: '#0B6634',
      });
    });
  });

  describe('when danger', () => {
    it('should render <StyledDangerChip /> with correct styles', () => {
      handleRender('BLOCKED');
      expect(screen.getByTestId(DataIds.DeviceStatusChip.Blocked.id)).toHaveStyle({
        backgroundColor: 'rgba(204, 51, 51, 0.09)',
        borderRadius: '99px',
        height: '24px',
        padding: '4px 8px',
      });
    });

    it('should render <StyledDangerLabelChip /> with correct styles', () => {
      handleRender('BLOCKED');
      expect(screen.getByTestId(DataIds.DeviceStatusChip.Blocked.Label.id)).toHaveStyle({
        color: '#A72A2A',
      });
    });
  });

  describe('when default', () => {
    it('should render <StyledDefaultChip /> with correct styles', () => {
      handleRender('INACTIVE');
      expect(screen.getByTestId(DataIds.DeviceStatusChip.Inactive.id)).toHaveStyle({
        backgroundColor: 'rgba(0, 0, 0, 0.08)',
        borderRadius: '99px',
        height: '24px',
        padding: '4px 8px',
      });
    });

    it('should render <StyledDefaultLabelChip /> with correct styles', () => {
      handleRender('INACTIVE');
      expect(screen.getByTestId(DataIds.DeviceStatusChip.Inactive.Label.id)).toHaveStyle({
        color: '#444444',
      });
    });
  });

  describe.each<DeviceStatusType['status']>([
    'ACTIVE',
    'INACTIVE',
    'BLOCKED',
    'BLOCKED_PENDING',
    'RESET_PENDING',
    'UNBLOCK_PENDING',
  ])('when status is %s', (status) => {
    const text = messages[camelCase(status) as keyof typeof messages].defaultMessage;
    it(`should render correct status text "${text}"`, () => {
      const { asFragment } = handleRender(status);
      const regex = new RegExp(`${status.replace('_', ' ').toLowerCase()}`, 'i');
      const label = screen.getByText(regex);
      expect(asFragment()).toMatchSnapshot();
      expect(label).toHaveTextContent(text);
    });
  });

  it('should render empty component', () => {
    const { container } = handleRender(null as never);
    expect(container.firstChild).toBeEmptyDOMElement();
  });
});
