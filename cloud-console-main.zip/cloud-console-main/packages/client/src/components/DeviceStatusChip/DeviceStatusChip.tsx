import React from 'react';
import { useIntl } from 'react-intl';
import type { DeviceStatusType } from './types';
import {
  StyledDangerChip,
  StyledDangerLabelChip,
  StyledDefaultChip,
  StyledDefaultLabelChip,
  StyledSuccessChip,
  StyledSuccessLabelChip,
} from './DeviceStatusChip.styled';
import messages from './messages';
import DataIds from './dataIds';

export const DeviceStatusChip: React.FC<DeviceStatusType> = React.memo(({ status }) => {
  const { formatMessage } = useIntl();

  switch (status) {
    case 'ACTIVE': {
      return (
        <StyledSuccessChip
          data-testid={DataIds.DeviceStatusChip.Active.id}
          label={
            <StyledSuccessLabelChip data-testid={DataIds.DeviceStatusChip.Active.Label.id}>
              {formatMessage(messages.active)}
            </StyledSuccessLabelChip>
          }
        />
      );
    }
    case 'INACTIVE': {
      return (
        <StyledDefaultChip
          data-testid={DataIds.DeviceStatusChip.Inactive.id}
          label={
            <StyledDefaultLabelChip data-testid={DataIds.DeviceStatusChip.Inactive.Label.id}>
              {formatMessage(messages.inactive)}
            </StyledDefaultLabelChip>
          }
        />
      );
    }
    case 'BLOCKED': {
      return (
        <StyledDangerChip
          data-testid={DataIds.DeviceStatusChip.Blocked.id}
          label={
            <StyledDangerLabelChip data-testid={DataIds.DeviceStatusChip.Blocked.Label.id}>
              {formatMessage(messages.blocked)}
            </StyledDangerLabelChip>
          }
        />
      );
    }
    case 'UNBLOCK_PENDING': {
      return (
        <StyledSuccessChip
          data-testid={DataIds.DeviceStatusChip.UnblockPending.id}
          label={
            <StyledSuccessLabelChip data-testid={DataIds.DeviceStatusChip.UnblockPending.Label.id}>
              {formatMessage(messages.unblockPending)}
            </StyledSuccessLabelChip>
          }
        />
      );
    }
    case 'BLOCKED_PENDING': {
      return (
        <StyledDangerChip
          data-testid={DataIds.DeviceStatusChip.BlockedPending.id}
          label={
            <StyledDangerLabelChip data-testid={DataIds.DeviceStatusChip.BlockedPending.Label.id}>
              {formatMessage(messages.blockedPending)}
            </StyledDangerLabelChip>
          }
        />
      );
    }
    case 'RESET_PENDING': {
      return (
        <StyledDangerChip
          data-testid={DataIds.DeviceStatusChip.ResetPending.id}
          label={
            <StyledDangerLabelChip data-testid={DataIds.DeviceStatusChip.ResetPending.Label.id}>
              {formatMessage(messages.resetPending)}
            </StyledDangerLabelChip>
          }
        />
      );
    }
    default: {
      return null;
    }
  }
});
