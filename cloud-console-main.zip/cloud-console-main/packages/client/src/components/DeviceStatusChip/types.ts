import type { DeviceStatusEnum } from '../../enums';

export type DeviceStatusType = {
  status: `${DeviceStatusEnum}`;
};
