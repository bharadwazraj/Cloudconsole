import { Chip, styled } from '@mui/material';

// success
export const StyledSuccessLabelChip = styled('span')(() => ({
  color: '#0B6634',
}));

export const StyledSuccessChip = styled(Chip)(({ theme }) => ({
  '& > .MuiChip-label': {
    padding: 0,
  },
  backgroundColor: 'rgba(12, 120, 62, 0.09)',
  borderRadius: '99px',
  height: '24px',
  padding: theme.spacing(0.5, 1),
}));

// danger
export const StyledDangerLabelChip = styled('span')(() => ({
  color: '#A72A2A',
}));

export const StyledDangerChip = styled(Chip)(({ theme }) => ({
  '& > .MuiChip-label': {
    padding: 0,
  },
  backgroundColor: 'rgba(204, 51, 51, 0.09)',
  borderRadius: '99px',
  height: '24px',
  padding: theme.spacing(0.5, 1),
}));

// default
export const StyledDefaultLabelChip = styled('span')(() => ({
  color: '#444444',
}));

export const StyledDefaultChip = styled(Chip)(({ theme }) => ({
  '& > .MuiChip-label': {
    padding: 0,
  },
  backgroundColor: 'rgba(0, 0, 0, 0.08)',
  borderRadius: '99px',
  height: '24px',
  padding: theme.spacing(0.5, 1),
}));
