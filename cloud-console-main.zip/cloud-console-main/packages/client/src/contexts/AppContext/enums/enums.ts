export enum AppActionTypeEnum {
  TOGGLE_DRAWER = 'app/toggle-drawer',
}
