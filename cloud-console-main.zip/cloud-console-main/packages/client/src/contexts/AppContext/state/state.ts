import type { AppStateType } from './types';

export const APP_INITIAL_STATE: AppStateType = {
  isDrawerOpened: false,
};
