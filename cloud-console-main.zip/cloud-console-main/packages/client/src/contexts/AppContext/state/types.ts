export type AppStateType = {
  isDrawerOpened: boolean;
};
