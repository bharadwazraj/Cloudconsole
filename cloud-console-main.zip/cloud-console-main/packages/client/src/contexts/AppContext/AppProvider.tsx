import React, {
  createContext,
  Dispatch,
  PropsWithChildren,
  Reducer,
  useMemo,
  useReducer,
} from 'react';
import { APP_INITIAL_STATE, AppStateType } from './state';
import { Action, reducer } from './reducer';

export const AppContext = createContext<{
  dispatch?: Dispatch<Action>;
  state: AppStateType;
}>({ state: APP_INITIAL_STATE });

// eslint-disable-next-line react/require-default-props
type AppContextProviderType = { initialState?: AppStateType };

export const AppProvider: React.FC<PropsWithChildren<AppContextProviderType>> = ({
  initialState = APP_INITIAL_STATE,
  children,
}) => {
  const [state, dispatch] = useReducer<Reducer<AppStateType, Action>>(reducer, initialState);
  const value = useMemo(() => ({ dispatch, state }), [state, dispatch]);
  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};
