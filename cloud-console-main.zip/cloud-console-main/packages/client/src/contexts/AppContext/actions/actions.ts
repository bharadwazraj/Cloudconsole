import type { ToggleDrawerActionType } from './types';
import { AppActionTypeEnum } from '../enums';

export const toggleDrawer: ToggleDrawerActionType = () => ({
  type: AppActionTypeEnum.TOGGLE_DRAWER,
});
