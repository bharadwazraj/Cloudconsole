import type { ActionType } from '../../utils';
import type { AppActionTypeEnum } from '../enums';

export type ToggleDrawerActionType = () => ActionType<AppActionTypeEnum.TOGGLE_DRAWER>;
