import { toggleDrawer } from '../actions';
import { AppActionTypeEnum } from '../../enums';

describe('<AppContext /> actions', () => {
  it('should call "setDeviceResetConfirmationDialog" action', () => {
    expect(toggleDrawer()).toEqual({
      type: AppActionTypeEnum.TOGGLE_DRAWER,
    });
  });
});
