import React from 'react';
import { render, screen } from '@testing-library/react';
import { useAppActions } from '../hooks';
import { AppProvider } from '../AppProvider';

describe('<AppProvider /> provider', () => {
  it('should throw an error if context is undefined', () => {
    // to keep console clean and throw error silently
    const spy = jest.spyOn(console, 'error').mockImplementation(() => null);
    const Component = () => {
      const { toggleDrawer } = useAppActions();
      toggleDrawer();
      return <div>testing a component without a context</div>;
    };
    expect(() => render(<Component />)).toThrow('useAppContext must be used within a AppProvider.');
    spy.mockRestore();
  });

  it('should render a context with default props', () => {
    const Component = () => {
      return <AppProvider>testing a component with a context</AppProvider>;
    };
    render(<Component />);
    expect(screen.getByText(/testing a component with a context/)).toHaveTextContent(
      'testing a component with a context'
    );
  });
});
