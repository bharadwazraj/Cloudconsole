import React, { PropsWithChildren } from 'react';
import { renderHook } from '@testing-library/react';
import { TestWrapper } from '../../../../testing';
import { useAppActions } from '../useAppActions';

const testWrapper: React.FC<PropsWithChildren> = ({ children }) => (
  <TestWrapper providers={[['AppContext']]}>{children}</TestWrapper>
);
const handleRender = (wrapper?: typeof testWrapper) =>
  renderHook(() => useAppActions(), { wrapper });

describe('useAppActions() hook', () => {
  it('should return app actions', () => {
    const { result } = handleRender(testWrapper);
    expect(result.current).toEqual({
      toggleDrawer: expect.any(Function),
    });
  });

  it('should throw an error if used outside of the <AppProvider />', () => {
    const spy = jest.spyOn(console, 'error').mockImplementation(() => null);
    try {
      handleRender();
    } catch (error: unknown) {
      expect((error as Error).message).toBe('useAppContext must be used within a AppProvider.');
    }
    spy.mockReset();
  });
});
