import React, { PropsWithChildren } from 'react';
import { renderHook } from '@testing-library/react';
import { TestWrapper } from '../../../../testing';
import { APP_INITIAL_STATE } from '../../state';
import { useAppState } from '../useAppState';

const wrapper: React.FC<PropsWithChildren> = ({ children }) => (
  <TestWrapper providers={[['AppContext']]}>{children}</TestWrapper>
);
const handleRender = () => renderHook(() => useAppState(), { wrapper });

describe('useAppState() hook', () => {
  it('should return app state', () => {
    const { result } = handleRender();
    expect(result.current).toEqual(APP_INITIAL_STATE);
  });
});
