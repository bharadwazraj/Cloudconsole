import type { toggleDrawer } from '../actions';

export type Actions = {
  toggleDrawer: typeof toggleDrawer;
};
