import { useContext, useMemo } from 'react';
import { AppContext } from '../AppProvider';
import { getBoundActions } from '../../utils';
import type { Actions } from './types';
import type { Action } from '../reducer';
import * as actions from '../actions';

export const useAppActions = () => {
  const context = useContext(AppContext);
  if (context.dispatch === undefined) {
    throw new Error(`useAppContext must be used within a AppProvider.`);
  }
  const { dispatch } = context;
  return useMemo(() => getBoundActions<Action, Actions, Actions>(dispatch, actions), [dispatch]);
};
