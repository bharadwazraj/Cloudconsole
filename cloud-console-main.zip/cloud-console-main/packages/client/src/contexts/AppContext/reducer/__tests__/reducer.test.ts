import produce from 'immer';
import { reducer } from '../reducer';
import { APP_INITIAL_STATE } from '../../state';
import { AppActionTypeEnum } from '../../enums';

describe('<AppContext /> reducer', () => {
  it('should set "isDrawerOpened" to true', () => {
    expect(
      reducer(APP_INITIAL_STATE, {
        type: AppActionTypeEnum.TOGGLE_DRAWER,
      })
    ).toEqual(
      produce(APP_INITIAL_STATE, (draft) => {
        // eslint-disable-next-line no-param-reassign
        draft.isDrawerOpened = true;
      })
    );
  });
});
