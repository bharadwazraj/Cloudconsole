// eslint-disable-next-line consistent-return
/* eslint-disable no-param-reassign */
import produce from 'immer';
import type { Action } from './types';
import { APP_INITIAL_STATE } from '../state';
import { AppActionTypeEnum } from '../enums';

export const reducer = produce((draft, action: Action) => {
  // eslint-disable-next-line sonarjs/no-small-switch
  switch (action.type) {
    case AppActionTypeEnum.TOGGLE_DRAWER: {
      draft.isDrawerOpened = !draft.isDrawerOpened;
      break;
    }
    default: {
      throw new Error(`Unhandled action type ${action}`);
    }
  }
}, APP_INITIAL_STATE);
