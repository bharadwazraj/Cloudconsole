export type ActionType<T, P = unknown> = {
  payload?: P;
  type: T;
};
