import type { Dispatch } from 'react';

export const getBoundActions = <D, A, R>(dispatch: Dispatch<D>, actions: A): R => {
  return Object.entries(actions).reduce((acc, [actionName, action]): R => {
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    acc[actionName] = (...args) => {
      const firstArg = args[0];
      // avoid passing synthetic event to action creator
      if (firstArg?.nativeEvent != null || firstArg?.target != null) {
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-ignore
        return dispatch(action());
      }
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      return dispatch(action(...args));
    };
    return acc;
  }, {} as R);
};
