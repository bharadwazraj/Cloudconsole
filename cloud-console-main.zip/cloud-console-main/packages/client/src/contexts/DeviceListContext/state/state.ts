import type { DeviceListStateType } from './types';

export const DEVICE_LIST_INITIAL_STATE: DeviceListStateType = {
  deviceBlockConfirmationDialog: { data: undefined, isOpen: false },
  deviceResetConfirmationDialog: { data: undefined, isOpen: false },
  deviceUnblockConfirmationDialog: { data: undefined, isOpen: false },
  page: 0,
  pageSize: 25,
  sortModel: [{ field: 'customerId', sort: 'asc' }], // TODO: set appropriate column name after API integration
};
