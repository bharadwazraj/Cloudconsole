import type { GridRowParams, GridSortModel } from '@mui/x-data-grid';
import type { DeviceListType } from '../../../features/Console/components/DeviceList/types';

export type DeviceListStateType = {
  deviceBlockConfirmationDialog: {
    data?: GridRowParams<DeviceListType>['row'];
    isOpen: boolean;
  };
  deviceResetConfirmationDialog: {
    data?: GridRowParams<DeviceListType>['row'];
    isOpen: boolean;
  };
  deviceUnblockConfirmationDialog: {
    data?: GridRowParams<DeviceListType>['row'];
    isOpen: boolean;
  };
  page: number;
  pageSize: number;
  sortModel: GridSortModel;
};
