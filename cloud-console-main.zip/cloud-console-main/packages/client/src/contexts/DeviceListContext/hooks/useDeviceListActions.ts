import { useContext, useMemo } from 'react';
import { getBoundActions } from '../../utils';
import type { Actions } from './types';
import * as actions from '../actions';
import { DeviceListContext } from '../DeviceListProvider';
import type { Action } from '../reducer';

const useDeviceListActions = () => {
  const { dispatch } = useContext(DeviceListContext);
  if (!dispatch) {
    throw new Error(`useDeviceListActions must be used within a DeviceListContextProvider.`);
  }
  return useMemo(() => getBoundActions<Action, Actions, Actions>(dispatch, actions), [dispatch]);
};

export { useDeviceListActions };
