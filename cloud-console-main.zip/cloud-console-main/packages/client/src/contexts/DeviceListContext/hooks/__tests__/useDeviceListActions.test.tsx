import React, { PropsWithChildren } from 'react';
import { renderHook } from '@testing-library/react';
import { TestWrapper } from '../../../../testing';
import { useDeviceListActions } from '../useDeviceListActions';

const testWrapper: React.FC<PropsWithChildren> = ({ children }) => (
  <TestWrapper providers={[['DeviceListContext']]}>{children}</TestWrapper>
);
const handleRender = (wrapper?: typeof testWrapper) =>
  renderHook(() => useDeviceListActions(), { wrapper });

describe('useDeviceListActions() hook', () => {
  it('should return device list actions', () => {
    const { result } = handleRender(testWrapper);
    expect(result.current).toEqual({
      setDeviceBlockConfirmationDialog: expect.any(Function),
      setDeviceResetConfirmationDialog: expect.any(Function),
      setDeviceUnblockConfirmationDialog: expect.any(Function),
      setPage: expect.any(Function),
      setPageSize: expect.any(Function),
      setSortModel: expect.any(Function),
    });
  });

  it('should throw an error if used outside of the <DeviceListContextProvider />', () => {
    const spy = jest.spyOn(console, 'error').mockImplementation(() => null);
    try {
      handleRender();
    } catch (error: unknown) {
      expect((error as Error).message).toBe(
        'useDeviceListActions must be used within a DeviceListContextProvider.'
      );
    }
    spy.mockReset();
  });
});
