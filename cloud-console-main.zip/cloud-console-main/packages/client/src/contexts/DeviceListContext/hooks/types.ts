import type {
  setDeviceBlockConfirmationDialog,
  setDeviceResetConfirmationDialog,
  setDeviceUnblockConfirmationDialog,
  setPage,
  setPageSize,
  setSortModel,
} from '../actions';

export type Actions = {
  setDeviceBlockConfirmationDialog: typeof setDeviceBlockConfirmationDialog;
  setDeviceResetConfirmationDialog: typeof setDeviceResetConfirmationDialog;
  setDeviceUnblockConfirmationDialog: typeof setDeviceUnblockConfirmationDialog;
  setPage: typeof setPage;
  setPageSize: typeof setPageSize;
  setSortModel: typeof setSortModel;
};
