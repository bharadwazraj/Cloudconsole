import { useContext } from 'react';
import { DeviceListContext } from '../DeviceListProvider';

const useDeviceListState = () => {
  const { state } = useContext(DeviceListContext);
  return state;
};

export { useDeviceListState };
