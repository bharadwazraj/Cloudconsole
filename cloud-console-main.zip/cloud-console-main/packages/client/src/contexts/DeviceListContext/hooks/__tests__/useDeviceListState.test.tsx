import React, { PropsWithChildren } from 'react';
import { renderHook } from '@testing-library/react';
import { TestWrapper } from '../../../../testing';
import { useDeviceListState } from '../useDeviceListState';
import { DEVICE_LIST_INITIAL_STATE } from '../../state';

const wrapper: React.FC<PropsWithChildren> = ({ children }) => (
  <TestWrapper providers={[['DeviceListContext']]}>{children}</TestWrapper>
);
const handleRender = () => renderHook(() => useDeviceListState(), { wrapper });

describe('useAppState() hook', () => {
  it('should return device list state', () => {
    const { result } = handleRender();
    expect(result.current).toEqual(DEVICE_LIST_INITIAL_STATE);
  });
});
