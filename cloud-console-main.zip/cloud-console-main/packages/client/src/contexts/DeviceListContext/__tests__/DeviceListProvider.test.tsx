import React from 'react';
import { render, screen } from '@testing-library/react';
import { useDeviceListActions } from '../hooks';
import { DeviceListProvider } from '../DeviceListProvider';

describe('<DeviceListProvider /> component', () => {
  it('should throw an error if context is undefined', () => {
    // to keep console clean and throw error silently
    const spy = jest.spyOn(console, 'error').mockImplementation(() => null);
    const Component = () => {
      const { setPageSize } = useDeviceListActions();
      setPageSize(1);
      return <div />;
    };
    expect(() => render(<Component />)).toThrow(
      'useDeviceListActions must be used within a DeviceListContextProvider.'
    );
    spy.mockRestore();
  });

  it('should render a context with default props', () => {
    const Component = () => {
      return <DeviceListProvider>testing a component with a context</DeviceListProvider>;
    };
    render(<Component />);
    expect(screen.getByText(/testing a component with a context/i)).toHaveTextContent(
      'testing a component with a context'
    );
  });
});
