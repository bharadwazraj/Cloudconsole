import React, {
  createContext,
  Dispatch,
  PropsWithChildren,
  Reducer,
  useMemo,
  useReducer,
} from 'react';
import { DEVICE_LIST_INITIAL_STATE, DeviceListStateType } from './state';
import { reducer, Action } from './reducer';

export const DeviceListContext = createContext<{
  dispatch?: Dispatch<Action>;
  state: DeviceListStateType;
}>({ state: DEVICE_LIST_INITIAL_STATE });

// eslint-disable-next-line react/require-default-props
type DeviceListContextProviderType = { initialState?: DeviceListStateType };

export const DeviceListProvider: React.FC<PropsWithChildren<DeviceListContextProviderType>> = ({
  initialState = DEVICE_LIST_INITIAL_STATE,
  children,
}) => {
  const [state, dispatch] = useReducer<Reducer<DeviceListStateType, Action>>(reducer, initialState);
  const value = useMemo(() => ({ dispatch, state }), [state, dispatch]);
  return <DeviceListContext.Provider value={value}>{children}</DeviceListContext.Provider>;
};
