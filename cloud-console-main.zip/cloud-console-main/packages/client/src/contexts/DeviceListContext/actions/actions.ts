import type {
  SetDeviceBlockConfirmationDialogActionType,
  SetDeviceResetConfirmationDialogActionType,
  SetDeviceUnblockConfirmationDialogActionType,
  SetPageActionType,
  SetPageSizeActionType,
  SetSortModelActionType,
} from './types';
import { DeviceListActionTypeEnum } from '../enums';

export const setDeviceBlockConfirmationDialog: SetDeviceBlockConfirmationDialogActionType = (
  payload
) => ({
  payload,
  type: DeviceListActionTypeEnum.SET_DEVICE_BLOCK_CONFIRMATION_DIALOG,
});

export const setDeviceResetConfirmationDialog: SetDeviceResetConfirmationDialogActionType = (
  payload
) => ({
  payload,
  type: DeviceListActionTypeEnum.SET_DEVICE_RESET_CONFIRMATION_DIALOG,
});

export const setDeviceUnblockConfirmationDialog: SetDeviceUnblockConfirmationDialogActionType = (
  payload
) => ({
  payload,
  type: DeviceListActionTypeEnum.SET_DEVICE_UNBLOCK_CONFIRMATION_DIALOG,
});

export const setPage: SetPageActionType = (payload) => ({
  payload,
  type: DeviceListActionTypeEnum.SET_PAGE,
});

export const setPageSize: SetPageSizeActionType = (payload) => ({
  payload,
  type: DeviceListActionTypeEnum.SET_PAGE_SIZE,
});

export const setSortModel: SetSortModelActionType = (payload) => ({
  payload,
  type: DeviceListActionTypeEnum.SET_SORT_MODEL,
});
