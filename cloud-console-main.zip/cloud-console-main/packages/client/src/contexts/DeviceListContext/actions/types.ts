import type { ActionType } from '../../utils';
import type { DeviceListActionTypeEnum } from '../enums';
import type { DeviceListStateType } from '../state';

export type SetDeviceBlockConfirmationDialogActionType = (
  payload: DeviceListStateType['deviceBlockConfirmationDialog']
) => ActionType<
  DeviceListActionTypeEnum.SET_DEVICE_BLOCK_CONFIRMATION_DIALOG,
  DeviceListStateType['deviceBlockConfirmationDialog']
>;

export type SetDeviceResetConfirmationDialogActionType = (
  payload: DeviceListStateType['deviceResetConfirmationDialog']
) => ActionType<
  DeviceListActionTypeEnum.SET_DEVICE_RESET_CONFIRMATION_DIALOG,
  DeviceListStateType['deviceResetConfirmationDialog']
>;

export type SetDeviceUnblockConfirmationDialogActionType = (
  payload: DeviceListStateType['deviceUnblockConfirmationDialog']
) => ActionType<
  DeviceListActionTypeEnum.SET_DEVICE_UNBLOCK_CONFIRMATION_DIALOG,
  DeviceListStateType['deviceUnblockConfirmationDialog']
>;

export type SetPageActionType = (
  payload: DeviceListStateType['pageSize']
) => ActionType<DeviceListActionTypeEnum.SET_PAGE, DeviceListStateType['page']>;

export type SetPageSizeActionType = (
  payload: DeviceListStateType['pageSize']
) => ActionType<DeviceListActionTypeEnum.SET_PAGE_SIZE, DeviceListStateType['pageSize']>;

export type SetSortModelActionType = (
  payload: DeviceListStateType['sortModel']
) => ActionType<DeviceListActionTypeEnum.SET_SORT_MODEL, DeviceListStateType['sortModel']>;
