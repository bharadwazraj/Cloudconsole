import {
  setDeviceBlockConfirmationDialog,
  setDeviceResetConfirmationDialog,
  setDeviceUnblockConfirmationDialog,
  setPage,
  setPageSize,
  setSortModel,
} from '../actions';
import { DeviceListActionTypeEnum } from '../../enums';

describe('<DeviceListContext /> actions', () => {
  it('should call "setDeviceResetConfirmationDialog" action', () => {
    expect(setDeviceBlockConfirmationDialog({ isOpen: true })).toEqual({
      payload: { data: undefined, isOpen: true },
      type: DeviceListActionTypeEnum.SET_DEVICE_BLOCK_CONFIRMATION_DIALOG,
    });
  });

  it('should call "setDeviceUnblockConfirmationDialog" action', () => {
    expect(setDeviceUnblockConfirmationDialog({ isOpen: true })).toEqual({
      payload: { data: undefined, isOpen: true },
      type: DeviceListActionTypeEnum.SET_DEVICE_UNBLOCK_CONFIRMATION_DIALOG,
    });
  });

  it('should call "setDeviceResetConfirmationDialog" action', () => {
    expect(setDeviceResetConfirmationDialog({ isOpen: true })).toEqual({
      payload: { data: undefined, isOpen: true },
      type: DeviceListActionTypeEnum.SET_DEVICE_RESET_CONFIRMATION_DIALOG,
    });
  });

  it('should call "setPage" action', () => {
    expect(setPage(0)).toEqual({ payload: 0, type: DeviceListActionTypeEnum.SET_PAGE });
  });

  it('should call "setPageSize" action', () => {
    expect(setPageSize(25)).toEqual({ payload: 25, type: DeviceListActionTypeEnum.SET_PAGE_SIZE });
  });

  it('should call "setSortModel" action', () => {
    expect(setSortModel([{ field: 'id', sort: 'asc' }])).toEqual({
      payload: [{ field: 'id', sort: 'asc' }],
      type: DeviceListActionTypeEnum.SET_SORT_MODEL,
    });
  });
});
