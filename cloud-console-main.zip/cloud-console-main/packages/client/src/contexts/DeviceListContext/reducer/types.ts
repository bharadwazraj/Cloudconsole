import type { ActionType } from '../../utils';
import type { DeviceListActionTypeEnum } from '../enums';
import type { DeviceListStateType } from '../state';

export type Action =
  | Required<
      ActionType<
        DeviceListActionTypeEnum.SET_DEVICE_BLOCK_CONFIRMATION_DIALOG,
        DeviceListStateType['deviceBlockConfirmationDialog']
      >
    >
  | Required<
      ActionType<
        DeviceListActionTypeEnum.SET_DEVICE_RESET_CONFIRMATION_DIALOG,
        DeviceListStateType['deviceResetConfirmationDialog']
      >
    >
  | Required<
      ActionType<
        DeviceListActionTypeEnum.SET_DEVICE_UNBLOCK_CONFIRMATION_DIALOG,
        DeviceListStateType['deviceUnblockConfirmationDialog']
      >
    >
  | Required<ActionType<DeviceListActionTypeEnum.SET_PAGE, DeviceListStateType['page']>>
  | Required<ActionType<DeviceListActionTypeEnum.SET_PAGE_SIZE, DeviceListStateType['pageSize']>>
  | Required<ActionType<DeviceListActionTypeEnum.SET_SORT_MODEL, DeviceListStateType['sortModel']>>;
