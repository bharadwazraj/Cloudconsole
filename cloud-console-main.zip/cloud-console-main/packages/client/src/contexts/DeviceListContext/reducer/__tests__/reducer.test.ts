import produce from 'immer';
import { reducer } from '../reducer';
import { DEVICE_LIST_INITIAL_STATE } from '../../state';
import { DeviceListActionTypeEnum } from '../../enums';

describe('<DeviceListContext /> reducer', () => {
  it('should set "deviceBlockConfirmationDialog"', () => {
    expect(
      reducer(DEVICE_LIST_INITIAL_STATE, {
        payload: { isOpen: true },
        type: DeviceListActionTypeEnum.SET_DEVICE_BLOCK_CONFIRMATION_DIALOG,
      })
    ).toEqual(
      produce(DEVICE_LIST_INITIAL_STATE, (draft) => {
        // eslint-disable-next-line no-param-reassign
        draft.deviceBlockConfirmationDialog = { data: undefined, isOpen: true };
      })
    );
  });

  it('should set "deviceResetConfirmationDialog"', () => {
    expect(
      reducer(DEVICE_LIST_INITIAL_STATE, {
        payload: { isOpen: true },
        type: DeviceListActionTypeEnum.SET_DEVICE_RESET_CONFIRMATION_DIALOG,
      })
    ).toEqual(
      produce(DEVICE_LIST_INITIAL_STATE, (draft) => {
        // eslint-disable-next-line no-param-reassign
        draft.deviceResetConfirmationDialog = { data: undefined, isOpen: true };
      })
    );
  });

  it('should set "deviceUnblockConfirmationDialog"', () => {
    expect(
      reducer(DEVICE_LIST_INITIAL_STATE, {
        payload: { isOpen: true },
        type: DeviceListActionTypeEnum.SET_DEVICE_UNBLOCK_CONFIRMATION_DIALOG,
      })
    ).toEqual(
      produce(DEVICE_LIST_INITIAL_STATE, (draft) => {
        // eslint-disable-next-line no-param-reassign
        draft.deviceUnblockConfirmationDialog = { data: undefined, isOpen: true };
      })
    );
  });

  it('should set "page"', () => {
    expect(
      reducer(DEVICE_LIST_INITIAL_STATE, {
        payload: 1,
        type: DeviceListActionTypeEnum.SET_PAGE,
      })
    ).toEqual(
      produce(DEVICE_LIST_INITIAL_STATE, (draft) => {
        // eslint-disable-next-line no-param-reassign
        draft.page = 1;
      })
    );
  });

  it('should set "pageSize"', () => {
    expect(
      reducer(DEVICE_LIST_INITIAL_STATE, {
        payload: 50,
        type: DeviceListActionTypeEnum.SET_PAGE_SIZE,
      })
    ).toEqual(
      produce(DEVICE_LIST_INITIAL_STATE, (draft) => {
        // eslint-disable-next-line no-param-reassign
        draft.pageSize = 50;
      })
    );
  });

  it('should set "sortModel"', () => {
    expect(
      reducer(DEVICE_LIST_INITIAL_STATE, {
        payload: [{ field: 'id', sort: 'desc' }],
        type: DeviceListActionTypeEnum.SET_SORT_MODEL,
      })
    ).toEqual(
      produce(DEVICE_LIST_INITIAL_STATE, (draft) => {
        // eslint-disable-next-line no-param-reassign
        draft.sortModel = [{ field: 'id', sort: 'desc' }];
      })
    );
  });
});
