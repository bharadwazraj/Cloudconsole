// eslint-disable-next-line consistent-return
/* eslint-disable no-param-reassign */
import produce from 'immer';
import { DEVICE_LIST_INITIAL_STATE } from '../state';
import { DeviceListActionTypeEnum } from '../enums';
import type { Action } from './types';

export const reducer = produce((draft, { payload, type }: Action) => {
  switch (type) {
    case DeviceListActionTypeEnum.SET_PAGE:
      draft.page = payload;
      break;
    case DeviceListActionTypeEnum.SET_PAGE_SIZE:
      draft.pageSize = payload;
      break;
    case DeviceListActionTypeEnum.SET_SORT_MODEL:
      draft.sortModel = payload;
      break;
    case DeviceListActionTypeEnum.SET_DEVICE_BLOCK_CONFIRMATION_DIALOG:
      draft.deviceBlockConfirmationDialog = payload;
      break;
    case DeviceListActionTypeEnum.SET_DEVICE_RESET_CONFIRMATION_DIALOG:
      draft.deviceResetConfirmationDialog = payload;
      break;
    case DeviceListActionTypeEnum.SET_DEVICE_UNBLOCK_CONFIRMATION_DIALOG:
      draft.deviceUnblockConfirmationDialog = payload;
      break;
    default: {
      throw new Error(`Unhandled action type ${type}`);
    }
  }
}, DEVICE_LIST_INITIAL_STATE);
