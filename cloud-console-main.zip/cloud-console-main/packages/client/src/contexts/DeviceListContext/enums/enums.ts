export enum DeviceListActionTypeEnum {
  SET_DEVICE_BLOCK_CONFIRMATION_DIALOG = 'device-list/set-device-block-confirmation-dialog',
  SET_DEVICE_RESET_CONFIRMATION_DIALOG = 'device-list/set-device-reset-confirmation-dialog',
  SET_DEVICE_UNBLOCK_CONFIRMATION_DIALOG = 'device-list/set-device-unblock-confirmation-dialog',
  SET_PAGE = 'device-list/set-page',
  SET_PAGE_SIZE = 'device-list/set-page-sze',
  SET_SORT_MODEL = 'device-list/set-sort-model',
}
