import React from 'react';
import { render, screen } from '@testing-library/react';
import Console from '../Console';
import DeviceListDataIds from '../components/DeviceList/dataIds';
import DeviceOverviewDataIds from '../components/DeviceOverview/dataIds';
import { TestWrapper } from '../../../testing';

const handleRender = () =>
  render(
    <TestWrapper providers={[['Intl']]}>
      <Console />
    </TestWrapper>
  );

describe('<Console /> component', () => {
  it('should render <DeviceList/> component', () => {
    handleRender();
    expect(screen.getByTestId(DeviceListDataIds.DeviceList.id)).toBeInTheDocument();
  });

  it('should render <DeviceOverview/> component', () => {
    handleRender();
    expect(screen.getByTestId(DeviceOverviewDataIds.DeviceOverview.id)).toBeInTheDocument();
  });
});
