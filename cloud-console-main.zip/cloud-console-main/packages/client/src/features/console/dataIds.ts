export default {
  Console: {
    id: 'Console',
  },
};
