import { Grid, styled } from '@mui/material';

export const StyledGridContainer = styled(Grid)(({ theme }) => ({
  [theme.breakpoints.up('md')]: {
    minHeight: '100%',
  },
  [theme.breakpoints.down('md')]: {
    minHeight: 'unset',
  },
}));
