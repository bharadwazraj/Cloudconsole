import React from 'react';
import { Grid } from '@mui/material';
import { DeviceOverview } from './components/DeviceOverview';
import { DeviceList } from './components/DeviceList';
import DataIds from './dataIds';
import { DeviceListProvider } from '../../contexts/DeviceListContext';
import { StyledGridContainer } from './Console.styled';

const Console: React.FC = () => {
  return (
    <StyledGridContainer
      container
      columnSpacing={{ md: 2.5 }}
      data-testid={DataIds.Console.id}
      rowSpacing={{ md: 0, xs: 2.5 }}
    >
      <Grid item md={4} xs={12}>
        <DeviceOverview />
      </Grid>
      <Grid item md={8} xs={12}>
        <DeviceListProvider>
          <DeviceList />
        </DeviceListProvider>
      </Grid>
    </StyledGridContainer>
  );
};

export default React.memo(Console);
