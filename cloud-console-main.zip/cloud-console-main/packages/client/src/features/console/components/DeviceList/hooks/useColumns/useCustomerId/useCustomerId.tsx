import React, { useMemo } from 'react';
import type { GridColDef } from '@mui/x-data-grid';
import { useIntl } from 'react-intl';
import type { DeviceListType } from '../../../types';
import { DeviceListColumnEnum } from '../../../enums';
import messages from '../messages';
import { StyledSpan } from './useCustomerId.styled';

export const useCustomerId = () => {
  const { formatMessage } = useIntl();
  return useMemo<GridColDef<DeviceListType, DeviceListType['customerId']>>(
    () => ({
      field: DeviceListColumnEnum.CUSTOMER_ID,
      flex: 1,
      headerName: formatMessage(messages.customerId),
      renderCell: (params) => {
        const { row } = params;
        const { customerId } = row;
        return <StyledSpan>{customerId}</StyledSpan>;
      },
    }),
    [formatMessage]
  );
};
