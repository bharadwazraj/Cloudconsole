import { defineMessages } from 'react-intl';

export default defineMessages({
  block: {
    defaultMessage: 'Block',
    id: 'features.console.components.DeviceList.DataGrid.column.actions.block',
  },
  reset: {
    defaultMessage: 'Reset',
    id: 'features.console.components.DeviceList.DataGrid.column.actions.reset',
  },
  unblock: {
    defaultMessage: 'Unblock',
    id: 'features.console.components.DeviceList.DataGrid.column.actions.unblock',
  },
});
