import React, { useMemo } from 'react';
import { useIntl } from 'react-intl';
import { Box } from '@onespan/components';
import type { ListSubheaderType } from '@cloud-console/components/CollapsibleList';
import { CollapsibleList } from '@cloud-console/components/CollapsibleList';
import type { ListItemType } from '@cloud-console/components/ListItems';
import { ListItemValue } from '@cloud-console/components/ListItemValue';
import { ListItemLabel } from '@cloud-console/components/ListItemLabel';
import messages from './messages';
import DataIds from './dataIds';

export const DeviceStatistics: React.FC = React.memo(() => {
  const { formatMessage } = useIntl();

  const listItems = useMemo<ListItemType[]>(
    () => [
      {
        divider: true,
        label: <ListItemLabel text={formatMessage(messages.numberOfDigipass)} />,
        value: <ListItemValue text="10000" />,
      },
      {
        divider: true,
        label: <ListItemLabel text={formatMessage(messages.activatedDigipass)} />,
        value: <ListItemValue text="6000" />,
      },
      {
        divider: true,
        label: <ListItemLabel text={formatMessage(messages.availableDigipass)} />,
        value: <ListItemValue text="3000" />,
      },
      {
        label: <ListItemLabel text={formatMessage(messages.blockedDigipass)} />,
        value: <ListItemValue text="3000" />,
      },
    ],
    [formatMessage]
  );

  const listSubHeader = useMemo<ListSubheaderType>(
    () => ({
      text: formatMessage(messages.title),
    }),
    [formatMessage]
  );

  return (
    <Box data-testid={DataIds.DeviceStatistics.id}>
      <CollapsibleList listItems={listItems} listSubHeader={listSubHeader} />
    </Box>
  );
});
