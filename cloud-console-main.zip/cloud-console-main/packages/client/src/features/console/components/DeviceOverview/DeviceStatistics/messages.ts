import { defineMessages } from 'react-intl';

export default defineMessages({
  activatedDigipass: {
    defaultMessage: 'Activated Digipass',
    id: 'features.Console.DeviceOverview.DeviceStatistics.label.activatedDigipass',
  },
  availableDigipass: {
    defaultMessage: 'Available Digipass',
    id: 'features.Console.DeviceOverview.DeviceStatistics.label.availableDigipass',
  },
  blockedDigipass: {
    defaultMessage: 'Blocked Digipass',
    id: 'features.Console.DeviceOverview.DeviceStatistics.label.blockedDigipass',
  },
  numberOfDigipass: {
    defaultMessage: 'Number Of Digipass',
    id: 'features.Console.DeviceOverview.DeviceStatistics.label.numberOfDigipass',
  },
  title: {
    defaultMessage: 'Overview',
    id: 'features.Console.DeviceOverview.DeviceStatistics.title',
  },
});
