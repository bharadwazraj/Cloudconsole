import React from 'react';
import { render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { TestWrapper } from '@cloud-console/test';
import {
  DEVICE_LIST_INITIAL_STATE,
  DeviceListStateType,
} from '@cloud-console/contexts/DeviceListContext';
import messages from '../messages';
import DataIds from '../dataIds';
import { DeviceUnblockConfirmationDialog } from '../DeviceUnblockConfirmationDialog';

const deviceListState: DeviceListStateType = {
  ...DEVICE_LIST_INITIAL_STATE,
  deviceUnblockConfirmationDialog: {
    data: {
      customerId: 'E-10032849',
      deviceSerialNumber: '49-3535521-0',
      expires: '21.12.2022, 11:09:26',
      status: 'BLOCKED',
    },
    isOpen: true,
  },
};

const handleRender = (initialState?: Partial<DeviceListStateType>) => ({
  user: userEvent.setup(),
  ...render(
    <TestWrapper
      providers={[
        ['Theme'],
        ['DeviceListContext', { initialState: { ...deviceListState, ...initialState } }],
        ['Intl'],
      ]}
    >
      <DeviceUnblockConfirmationDialog />
    </TestWrapper>
  ),
});

describe('<DeviceUnblockConfirmationDialog/ > component', () => {
  describe('<DialogTitle /> component', () => {
    it('should render correct title', () => {
      handleRender();
      expect(screen.getByText(/unblock device/i)).toHaveTextContent(messages.title.defaultMessage);
    });

    it('should close dialog when click "Cancel" button', async () => {
      const { user } = handleRender();
      const dialogTitle = within(
        screen.getByTestId(DataIds.DeviceUnblockConfirmationDialog.DialogTitle.id)
      );
      expect(screen.getByTestId(DataIds.DeviceUnblockConfirmationDialog.id)).toBeInTheDocument();
      await user.click(dialogTitle.getByRole('button'));
      expect(
        screen.queryByTestId(DataIds.DeviceUnblockConfirmationDialog.id)
      ).not.toBeInTheDocument();
    });
  });

  describe('<DialogContent /> component', () => {
    it('should render appropriate text content', () => {
      handleRender();
      expect(screen.getByText(/E-10032849/i)).toHaveTextContent(
        messages.content.defaultMessage
          .replace('{deviceSerialNumber}', '49-3535521-0')
          .replace('{customerId}', 'E-10032849')
          .replace(/\n\n/gm, ' ')
      );
    });
  });

  describe('<DialogActions /> component', () => {
    it('should render dialog button actions, "Cancel" and "Unblock"', () => {
      handleRender();
      const dialogActions = within(
        screen.getByTestId(DataIds.DeviceUnblockConfirmationDialog.DialogActions.id)
      );
      expect(dialogActions.getByRole('button', { name: /cancel/i })).toHaveTextContent(
        messages.cancelButton.defaultMessage
      );
      expect(dialogActions.getByRole('button', { name: /unblock/i })).toHaveTextContent(
        messages.unblockButton.defaultMessage
      );
    });

    it('should close dialog when click "Cancel" button', async () => {
      const { user } = handleRender();
      const dialogActions = within(
        screen.getByTestId(DataIds.DeviceUnblockConfirmationDialog.DialogActions.id)
      );
      expect(screen.getByTestId(DataIds.DeviceUnblockConfirmationDialog.id)).toBeInTheDocument();
      await user.click(dialogActions.getByRole('button', { name: /cancel/i }));
      expect(
        screen.queryByTestId(DataIds.DeviceUnblockConfirmationDialog.id)
      ).not.toBeInTheDocument();
    });
  });

  it('should not render <DeviceUnblockConfirmationDialog /> if data is not provided', () => {
    handleRender({
      deviceUnblockConfirmationDialog: { data: undefined, isOpen: true },
    });
    expect(
      screen.queryByTestId(DataIds.DeviceUnblockConfirmationDialog.id)
    ).not.toBeInTheDocument();
  });
});
