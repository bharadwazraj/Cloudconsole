import { renderHook } from '@testing-library/react';
import React, { PropsWithChildren } from 'react';
import { TestWrapper } from '@cloud-console/test';
import { DeviceListColumnEnum } from '../../../../enums';
import messages from '../../messages';
import { useExpires } from '../useExpires';

const wrapper: React.FC<PropsWithChildren> = ({ children }) => (
  <TestWrapper providers={[['Intl']]}>{children}</TestWrapper>
);
const handleRender = () => renderHook(() => useExpires(), { wrapper });

describe('useExpires() hook', () => {
  it('should return correct expires column configuration', () => {
    const { result } = handleRender();
    expect(result.current).toEqual({
      field: DeviceListColumnEnum.EXPIRES,
      flex: 1,
      headerName: messages.expires.defaultMessage,
      renderCell: expect.any(Function),
    });
  });
});
