import React, { useMemo } from 'react';
import { useIntl } from 'react-intl';
import { Box } from '@onespan/components';
import { ListItemLabel } from '@cloud-console/components/ListItemLabel';
import { ListItemValue } from '@cloud-console/components/ListItemValue';
import type { ListItemType } from '@cloud-console/components/ListItems';
import { List } from '@cloud-console/components/List';
import { Firmware } from '@cloud-console/components/Firmware';
import messages from './messages';
import DataIds from './dataIds';

export const DeviceFirmwareInformation: React.FC = React.memo(() => {
  const { formatMessage } = useIntl();

  const listItems = useMemo<ListItemType[]>(
    () => [
      {
        divider: true,
        label: <ListItemLabel text={formatMessage(messages.firmware)} />,
        value: <ListItemValue component={<Firmware />} />,
      },
      {
        label: <ListItemLabel text={formatMessage(messages.apps)} />,
        value: <ListItemValue text="FIDO, OATH, Digipass, Cronto, MyBank E-Sigh" />,
      },
    ],
    [formatMessage]
  );

  return (
    <Box data-testid={DataIds.DeviceFirmwareInformation.id}>
      <List listItems={listItems} />
    </Box>
  );
});
