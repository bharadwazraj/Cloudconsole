import { defineMessages } from 'react-intl';

export default defineMessages({
  noRowsOverlayText: {
    defaultMessage: 'No digipass match your search query. Try your search again.',
    id: 'features.Console.components.DeviceList.DataGrid.label.noRowsOverlayText',
  },
});
