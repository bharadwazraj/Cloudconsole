import React from 'react';
import { render, screen } from '@testing-library/react';
import { TestWrapper } from '@cloud-console/test';
import { DeviceOverview } from '../DeviceOverview';
import DeviceStatisticsDataIds from '../DeviceStatistics/dataIds';
import DeviceFirmwareInformationDataIds from '../DeviceFirmwareInformation/dataIds';

const handleRender = () =>
  render(
    <TestWrapper providers={[['Intl']]}>
      <DeviceOverview />
    </TestWrapper>
  );

describe('<DeviceOverview /> component', () => {
  it('should match snapshot', () => {
    const { asFragment } = handleRender();
    expect(asFragment()).toMatchSnapshot();
  });

  it('should render by default <DeviceStatistics /> component', () => {
    handleRender();
    expect(screen.getByTestId(DeviceStatisticsDataIds.DeviceStatistics.id)).toBeInTheDocument();
  });

  it('should render by default <DeviceFirmwareInformation /> component', () => {
    handleRender();
    expect(
      screen.getByTestId(DeviceFirmwareInformationDataIds.DeviceFirmwareInformation.id)
    ).toBeInTheDocument();
  });
});
