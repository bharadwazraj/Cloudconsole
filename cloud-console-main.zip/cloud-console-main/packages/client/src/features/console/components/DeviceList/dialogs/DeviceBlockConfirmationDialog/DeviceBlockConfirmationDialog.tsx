import React, { useCallback } from 'react';
import { Button, Dialog, DialogActions, DialogContent, DialogTitle } from '@onespan/components';
import { useIntl } from 'react-intl';
import BlockIcon from '@mui/icons-material/Block';
import {
  useDeviceListActions,
  useDeviceListState,
} from '@cloud-console/contexts/DeviceListContext';
import messages from './messages';
import DataIds from './dataIds';

export const DeviceBlockConfirmationDialog: React.FC = React.memo(() => {
  const { formatMessage } = useIntl();
  const { setDeviceBlockConfirmationDialog } = useDeviceListActions();
  const { deviceBlockConfirmationDialog } = useDeviceListState();
  const { data, isOpen } = deviceBlockConfirmationDialog;

  const handleClose = useCallback(
    () => setDeviceBlockConfirmationDialog({ data: undefined, isOpen: false }),
    [setDeviceBlockConfirmationDialog]
  );

  if (!data) return null;

  const { customerId, deviceSerialNumber } = data;

  return (
    <Dialog
      data-testid={DataIds.DeviceBlockConfirmationDialog.id}
      open={isOpen}
      onClose={handleClose}
    >
      <DialogTitle
        data-testid={DataIds.DeviceBlockConfirmationDialog.DialogTitle.id}
        closeButtonProps={{
          'aria-label': formatMessage(messages.cancelButton),
          onClick: handleClose,
        }}
      >
        {formatMessage(messages.title)}
      </DialogTitle>
      <DialogContent data-testid={DataIds.DeviceBlockConfirmationDialog.DialogContent.id}>
        {formatMessage(messages.content, { customerId, deviceSerialNumber })}
      </DialogContent>
      <DialogActions data-testid={DataIds.DeviceBlockConfirmationDialog.DialogActions.id}>
        <Button autoFocus variant="outlined" onClick={handleClose}>
          {formatMessage(messages.cancelButton)}
        </Button>
        <Button startIcon={<BlockIcon />} variant="contained" onClick={handleClose}>
          {formatMessage(messages.blockButton)}
        </Button>
      </DialogActions>
    </Dialog>
  );
});
