import React from 'react';
import { Grid } from '@mui/material';
import DataIds from './dataIds';
import { DeviceStatistics } from './DeviceStatistics';
import { DeviceFirmwareInformation } from './DeviceFirmwareInformation';

export const DeviceOverview: React.FC = React.memo(() => {
  return (
    <Grid container data-testid={DataIds.DeviceOverview.id} spacing={2.5}>
      <Grid item xs={12}>
        <DeviceStatistics />
      </Grid>
      <Grid item xs={12}>
        <DeviceFirmwareInformation />
      </Grid>
    </Grid>
  );
});
