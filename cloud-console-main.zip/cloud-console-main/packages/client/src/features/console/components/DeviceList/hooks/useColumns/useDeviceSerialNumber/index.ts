export * from './useDeviceSerialNumber';
