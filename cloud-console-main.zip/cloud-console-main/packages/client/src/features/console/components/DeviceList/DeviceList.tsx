import React, { useCallback, useMemo } from 'react';
import { Grid } from '@mui/material';
import { useIntl } from 'react-intl';
import type { GridRowModel, GridSortModel } from '@mui/x-data-grid';
import { DataGrid } from '@cloud-console/components/DataGrid';
import {
  useDeviceListActions,
  useDeviceListState,
} from '@cloud-console/contexts/DeviceListContext';
import DataIds from './dataIds';
import { StyledGridContainer } from './DeviceList.styled';
import messages from './messages';
import { rows } from './__mock-data__/data';
import { useColumns } from './hooks/useColumns';
import { useStatusFilter } from './hooks/useStatusFilter';
import { DeviceResetConfirmationDialog } from './dialogs/DeviceResetConfirmationDialog';
import { DeviceUnblockConfirmationDialog } from './dialogs/DeviceUnblockConfirmationDialog';
import type { DeviceListType } from './types';
import { DeviceBlockConfirmationDialog } from './dialogs/DeviceBlockConfirmationDialog';

export const DeviceList: React.FC = React.memo(() => {
  const { formatMessage } = useIntl();
  const { page, pageSize, sortModel } = useDeviceListState();
  const { setPage, setPageSize, setSortModel } = useDeviceListActions();
  const columns = useColumns();
  const statusFilter = useStatusFilter();

  const getRowId = useCallback((row: GridRowModel<DeviceListType>) => row.customerId, []);

  const filters = useMemo(() => [{ ...statusFilter }], [statusFilter]);

  const noRowsOverlayText = useMemo(
    () => formatMessage(messages.noRowsOverlayText),
    [formatMessage]
  );

  const handlePageChange = useCallback(
    (newPage: number) => {
      setPage(newPage);
    },
    [setPage]
  );

  const handlePageSizeChange = useCallback(
    (newPage: number) => {
      setPageSize(newPage);
    },
    [setPageSize]
  );

  const handleSortModelChange = useCallback(
    (newSortModel: GridSortModel) => {
      setSortModel(newSortModel);
    },
    [setSortModel]
  );

  return (
    <>
      <StyledGridContainer container data-testid={DataIds.DeviceList.id}>
        <Grid item xs={12}>
          <DataGrid
            dataGridProps={{
              columns,
              filters,
              getRowId,
              noRowsOverlayText,
              onPageChange: handlePageChange,
              onPageSizeChange: handlePageSizeChange,
              onSortModelChange: handleSortModelChange,
              page,
              pageSize,
              rows,
              sortModel,
              totalCount: rows.length,
            }}
          />
        </Grid>
      </StyledGridContainer>
      <DeviceBlockConfirmationDialog />
      <DeviceResetConfirmationDialog />
      <DeviceUnblockConfirmationDialog />
    </>
  );
});
