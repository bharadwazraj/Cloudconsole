import type { DeviceStatusType } from '@cloud-console/components/DeviceStatusChip';

export type DeviceListType = {
  customerId: string;
  deviceSerialNumber: string;
  expires: string;
  status: DeviceStatusType['status'];
};
