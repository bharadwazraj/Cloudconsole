import { defineMessages } from 'react-intl';

export default defineMessages({
  blockButton: {
    defaultMessage: 'Block',
    id: 'features.Console.components.DeviceList.dialogs.DeviceBlockConfirmationDialog.blockButton',
  },
  cancelButton: {
    defaultMessage: 'Cancel',
    id: 'features.Console.components.DeviceList.dialogs.DeviceBlockConfirmationDialog.cancelButton',
  },
  content: {
    defaultMessage:
      'Are you sure you want to block the device "{deviceSerialNumber}" linked to customer ID "{customerId}"?\n\nThe Device will be blocked once it comes online. Blocking a device will temporarily disable it. You can unblock a device anytime.',
    id: 'features.Console.components.DeviceList.dialogs.DeviceBlockConfirmationDialog.content',
  },
  title: {
    defaultMessage: 'Block device?',
    id: 'features.Console.components.DeviceList.dialogs.DeviceBlockConfirmationDialog.title',
  },
});
