import React, { useMemo } from 'react';
import type { GridColDef } from '@mui/x-data-grid';
import { useIntl } from 'react-intl';
import type { DeviceListType } from '../../../types';
import messages from '../messages';
import { DeviceListColumnEnum } from '../../../enums';
import { StyledSpan } from './useExpires.styled';

export const useExpires = () => {
  const { formatMessage } = useIntl();
  return useMemo<GridColDef<DeviceListType, DeviceListType['expires']>>(
    () => ({
      field: DeviceListColumnEnum.EXPIRES,
      flex: 1,
      headerName: formatMessage(messages.expires),
      renderCell: (params) => {
        const { row } = params;
        const { expires } = row;
        return <StyledSpan>{new Date(expires).toLocaleString(navigator.language)}</StyledSpan>;
      },
    }),
    [formatMessage]
  );
};
