import { defineMessages } from 'react-intl';

export default defineMessages({
  apps: {
    defaultMessage: 'Apps',
    id: 'features.Console.DeviceOverview.DeviceFirmwareInformation.label.apps',
  },
  firmware: {
    defaultMessage: 'Firmware',
    id: 'features.Console.DeviceOverview.DeviceFirmwareInformation.label.firmware',
  },
});
