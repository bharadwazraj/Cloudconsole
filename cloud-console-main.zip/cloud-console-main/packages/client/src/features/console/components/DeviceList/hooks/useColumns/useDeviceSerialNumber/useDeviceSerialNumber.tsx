import React, { useMemo } from 'react';
import type { GridColDef } from '@mui/x-data-grid';
import { useIntl } from 'react-intl';
import type { DeviceListType } from '../../../types';
import { DeviceListColumnEnum } from '../../../enums';
import messages from '../messages';
import { StyledSpan } from './useDeviceSerialNumber.styled';

export const useDeviceSerialNumber = () => {
  const { formatMessage } = useIntl();
  return useMemo<GridColDef<DeviceListType, DeviceListType['deviceSerialNumber']>>(
    () => ({
      field: DeviceListColumnEnum.DEVICE_SERIAL_NUMBER,
      flex: 1,
      headerName: formatMessage(messages.deviceSerialNumber),
      renderCell: (params) => {
        const { row } = params;
        const { deviceSerialNumber } = row;
        return <StyledSpan>{deviceSerialNumber}</StyledSpan>;
      },
    }),
    [formatMessage]
  );
};
