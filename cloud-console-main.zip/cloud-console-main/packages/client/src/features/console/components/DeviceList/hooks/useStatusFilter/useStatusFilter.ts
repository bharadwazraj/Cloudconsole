import { useCallback, useMemo, useState } from 'react';
import type { SelectChangeEvent } from '@mui/material';
import { useIntl } from 'react-intl';
import type { DataGridFilterType } from '@cloud-console/components/DataGrid';
import { DeviceFilterStatusEnum } from '@cloud-console/enums';
import messages from './messages';
import type { DeviceStatusFilterType } from './types';

export const useStatusFilter = () => {
  const { formatMessage } = useIntl();
  const [value, setValue] = useState<DeviceStatusFilterType>('ALL');

  const onChange = useCallback((event: SelectChangeEvent<unknown>) => {
    setValue(event.target.value as DeviceStatusFilterType);
  }, []);

  return useMemo<DataGridFilterType>(
    () => ({
      formFieldProps: { id: '' },
      hasOptionIcon: true,
      options: [
        {
          optionProps: { value: DeviceFilterStatusEnum.ALL },
          optionText: formatMessage(messages.all),
        },
        {
          optionProps: { value: DeviceFilterStatusEnum.ACTIVE },
          optionText: formatMessage(messages.active),
        },
        {
          optionProps: { value: DeviceFilterStatusEnum.INACTIVE },
          optionText: formatMessage(messages.inactive),
        },
        {
          optionProps: { value: DeviceFilterStatusEnum.BLOCKED },
          optionText: formatMessage(messages.blocked),
        },
        {
          optionProps: { value: DeviceFilterStatusEnum.UNBLOCK_PENDING },
          optionText: formatMessage(messages.unblockPending),
        },
        {
          optionProps: { value: DeviceFilterStatusEnum.BLOCKED_PENDING },
          optionText: formatMessage(messages.blockedPending),
        },
        {
          optionProps: { value: DeviceFilterStatusEnum.RESET_PENDING },
          optionText: formatMessage(messages.resetPending),
        },
      ],
      selectProps: { onChange, value },
      startAdornmentText: formatMessage(messages.startAdornmentText),
    }),
    [formatMessage, onChange, value]
  );
};
