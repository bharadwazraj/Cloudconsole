import React, { PropsWithChildren } from 'react';
import { renderHook } from '@testing-library/react';
import { TestWrapper } from '@cloud-console/test';
import { useColumns } from '../useColumns';
import messages from '../messages';
import { DeviceListColumnEnum } from '../../../enums';

const wrapper: React.FC<PropsWithChildren> = ({ children }) => (
  <TestWrapper providers={[['DeviceListContext'], ['Intl']]}>{children}</TestWrapper>
);
const handleRender = () => renderHook(() => useColumns(), { wrapper });

describe('useColumns() hook', () => {
  it('should return correct columns configuration', () => {
    const { result } = handleRender();
    expect(result.current).toEqual([
      {
        field: DeviceListColumnEnum.CUSTOMER_ID,
        flex: 1,
        headerName: messages.customerId.defaultMessage,
        renderCell: expect.any(Function),
      },
      {
        field: DeviceListColumnEnum.DEVICE_SERIAL_NUMBER,
        flex: 1,
        headerName: messages.deviceSerialNumber.defaultMessage,
        renderCell: expect.any(Function),
      },
      {
        field: DeviceListColumnEnum.EXPIRES,
        flex: 1,
        headerName: messages.expires.defaultMessage,
        renderCell: expect.any(Function),
      },
      {
        field: DeviceListColumnEnum.STATUS,
        flex: 1,
        headerName: messages.status.defaultMessage,
        renderCell: expect.any(Function),
      },
      {
        align: 'right',
        field: DeviceListColumnEnum.ACTIONS,
        flex: 1,
        getActions: expect.any(Function),
        type: 'actions',
      },
    ]);
  });
});
