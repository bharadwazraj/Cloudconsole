export default {
  DeviceBlockConfirmationDialog: {
    DialogActions: {
      id: 'DeviceBlockConfirmationDialog-DialogActions',
    },
    DialogContent: {
      id: 'DeviceBlockConfirmationDialog-DialogContent',
    },
    DialogTitle: {
      id: 'DeviceBlockConfirmationDialog-DialogTitle',
    },
    id: 'DeviceBlockConfirmationDialog',
  },
};
