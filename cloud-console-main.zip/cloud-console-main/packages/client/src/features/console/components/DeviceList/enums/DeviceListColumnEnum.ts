export enum DeviceListColumnEnum {
  ACTIONS = 'actions',
  CUSTOMER_ID = 'customerId',
  DEVICE_SERIAL_NUMBER = 'deviceSerialNumber',
  EXPIRES = 'expires',
  STATUS = 'status',
}
