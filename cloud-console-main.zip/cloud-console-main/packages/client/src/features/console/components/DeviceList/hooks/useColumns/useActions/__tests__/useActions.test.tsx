import React, { PropsWithChildren } from 'react';
import { renderHook } from '@testing-library/react';
import { TestWrapper } from '@cloud-console/test';
import type { DeviceStatusType } from '@cloud-console/components/DeviceStatusChip';
import { useActions } from '../useActions';
import { DeviceListColumnEnum } from '../../../../enums';
import messages from '../messages';
import type { DeviceListType } from '../../../../types';

const row: DeviceListType = {
  customerId: 'E-10032849',
  deviceSerialNumber: '49-3535521-0',
  expires: '21.12.2022, 11:09:26',
  status: null as never,
};
const wrapper: React.FC<PropsWithChildren> = ({ children }) => (
  <TestWrapper providers={[['DeviceListContext'], ['Intl']]}>{children}</TestWrapper>
);
const handleRender = () => renderHook(() => useActions(), { wrapper });

describe('useActions() hook', () => {
  it('should return correct actions column configuration', () => {
    const { result } = handleRender();
    expect(result.current).toEqual({
      align: 'right',
      field: DeviceListColumnEnum.ACTIONS,
      flex: 1,
      getActions: expect.any(Function),
      type: 'actions',
    });
  });

  describe('when status is not defined or it does not match', () => {
    it('should render at least one action "Reset"', () => {
      const { result } = handleRender();
      const actions = result.current.getActions({ columns: [], getValue: jest.fn(), id: '', row });
      const reset = actions.find(({ props }) => props.label === messages.reset.defaultMessage);
      expect(actions).toHaveLength(1);
      expect(reset).toBeDefined();
    });
  });

  describe.each<DeviceStatusType['status']>(['BLOCKED', 'BLOCKED_PENDING'])(
    'when status is %s',
    (status) => {
      it(`should contain unblock action `, () => {
        const { result } = handleRender();
        const actions = result.current.getActions({
          columns: [],
          getValue: jest.fn(),
          id: '',
          row: { ...row, status },
        });
        const unblock = actions.find(
          ({ props }) => props.label === messages.unblock.defaultMessage
        );
        expect(unblock).toBeDefined();
      });
    }
  );

  describe.each<DeviceStatusType['status']>([
    'ACTIVE',
    'INACTIVE',
    'UNBLOCK_PENDING',
    'RESET_PENDING',
  ])('when status is %s', (status) => {
    it(`should contain block action `, () => {
      const { result } = handleRender();
      const actions = result.current.getActions({
        columns: [],
        getValue: jest.fn(),
        id: '',
        row: { ...row, status },
      });
      const block = actions.find(({ props }) => props.label === messages.block.defaultMessage);
      expect(block).toBeDefined();
    });
  });
});
