export default {
  DeviceList: {
    id: 'DeviceList',
  },
};
