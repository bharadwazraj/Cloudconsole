export default {
  DeviceOverview: {
    id: 'DeviceOverview',
  },
};
