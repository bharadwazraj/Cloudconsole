import { useMemo } from 'react';
import type { GridColumns } from '@mui/x-data-grid';
import type { DeviceListType } from '../../types';
import { useDeviceSerialNumber } from './useDeviceSerialNumber';
import { useCustomerId } from './useCustomerId';
import { useExpires } from './useExpires';
import { useStatus } from './useStatus';
import { useActions } from './useActions';

export const useColumns = () => {
  const customerId = useCustomerId();
  const deviceSerialNumber = useDeviceSerialNumber();
  const expires = useExpires();
  const status = useStatus();
  const actions = useActions();
  return useMemo<GridColumns<DeviceListType>>(
    () => [
      { ...customerId },
      { ...deviceSerialNumber },
      { ...expires },
      { ...status },
      { ...actions },
    ],
    [actions, customerId, deviceSerialNumber, expires, status]
  );
};
