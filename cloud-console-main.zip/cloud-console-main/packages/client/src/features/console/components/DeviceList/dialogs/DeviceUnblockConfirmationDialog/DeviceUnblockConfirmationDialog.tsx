import React, { useCallback } from 'react';
import { Button, Dialog, DialogActions, DialogContent, DialogTitle } from '@onespan/components';
import { useIntl } from 'react-intl';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import {
  useDeviceListActions,
  useDeviceListState,
} from '@cloud-console/contexts/DeviceListContext';
import messages from './messages';
import DataIds from './dataIds';

export const DeviceUnblockConfirmationDialog: React.FC = React.memo(() => {
  const { formatMessage } = useIntl();
  const { setDeviceUnblockConfirmationDialog } = useDeviceListActions();
  const { deviceUnblockConfirmationDialog } = useDeviceListState();
  const { data, isOpen } = deviceUnblockConfirmationDialog;

  const handleClose = useCallback(
    () => setDeviceUnblockConfirmationDialog({ data: undefined, isOpen: false }),
    [setDeviceUnblockConfirmationDialog]
  );

  if (!data) return null;

  const { customerId, deviceSerialNumber } = data;

  return (
    <Dialog
      data-testid={DataIds.DeviceUnblockConfirmationDialog.id}
      open={isOpen}
      onClose={handleClose}
    >
      <DialogTitle
        data-testid={DataIds.DeviceUnblockConfirmationDialog.DialogTitle.id}
        closeButtonProps={{
          'aria-label': formatMessage(messages.cancelButton),
          onClick: handleClose,
        }}
      >
        {formatMessage(messages.title)}
      </DialogTitle>
      <DialogContent data-testid={DataIds.DeviceUnblockConfirmationDialog.DialogContent.id}>
        {formatMessage(messages.content, { customerId, deviceSerialNumber })}
      </DialogContent>
      <DialogActions data-testid={DataIds.DeviceUnblockConfirmationDialog.DialogActions.id}>
        <Button autoFocus variant="outlined" onClick={handleClose}>
          {formatMessage(messages.cancelButton)}
        </Button>
        <Button startIcon={<CheckCircleOutlineIcon />} variant="contained" onClick={handleClose}>
          {formatMessage(messages.unblockButton)}
        </Button>
      </DialogActions>
    </Dialog>
  );
});
