// TODO: remove that file after integration with API
import { random } from 'lodash-es';
import type { DeviceListType } from '../types';

export const rows: DeviceListType[] = [];

const status: DeviceListType['status'][] = [
  'ACTIVE',
  'INACTIVE',
  'BLOCKED',
  'UNBLOCK_PENDING',
  'BLOCKED_PENDING',
  'RESET_PENDING',
];

const data = (): DeviceListType => {
  return {
    customerId: `E-${random(10000000, 99999999)}`,
    deviceSerialNumber: `${random(10, 99)}-${random(1000000, 9999999)}-${random(0, 9)}`,
    expires: new Date().toISOString(),
    status: status[random(0, 5)],
  };
};

// eslint-disable-next-line no-plusplus
for (let i = 0; i <= 1000; i++) {
  rows.push(data());
}
