import { defineMessages } from 'react-intl';

export default defineMessages({
  cancelButton: {
    defaultMessage: 'Cancel',
    id: 'features.Console.components.DeviceList.dialogs.DeviceUnblockConfirmationDialog.cancelButton',
  },
  content: {
    defaultMessage:
      'Are you sure you want to unblock the device "{deviceSerialNumber}" linked to customer ID "{customerId}"?\n\nThe device will be unblocked once it comes online. This will make the device active again.',
    id: 'features.Console.components.DeviceList.dialogs.DeviceUnblockConfirmationDialog.content',
  },
  title: {
    defaultMessage: 'Unblock device?',
    id: 'features.Console.components.DeviceList.dialogs.DeviceUnblockConfirmationDialog.title',
  },
  unblockButton: {
    defaultMessage: 'Unblock',
    id: 'features.Console.components.DeviceList.dialogs.DeviceUnblockConfirmationDialog.unblockButton',
  },
});
