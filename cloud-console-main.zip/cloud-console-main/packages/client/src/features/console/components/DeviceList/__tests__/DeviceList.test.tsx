import React from 'react';
import { render, screen } from '@testing-library/react';
import { TestWrapper } from '@cloud-console/test';
import { DeviceList } from '../DeviceList';
import DataIds from '../dataIds';

const handleRender = () =>
  render(
    <TestWrapper providers={[['DeviceListContext'], ['Intl']]}>
      <DeviceList />
    </TestWrapper>
  );

describe('<DeviceList /> component', () => {
  it('should render <DeviceList /> component', () => {
    handleRender();
    const deviceList = screen.getByTestId(DataIds.DeviceList.id);
    expect(deviceList).toBeInTheDocument();
  });
});
