import type { DeviceFilterStatusEnum } from '@cloud-console/enums';

export type DeviceStatusFilterType = `${DeviceFilterStatusEnum}`;
