import { styled } from '@mui/material';
import BlockIcon from '@mui/icons-material/Block';
import SettingsBackupRestoreIcon from '@mui/icons-material/SettingsBackupRestore';
import { GridActionsCellItem } from '@mui/x-data-grid';

export const StyledBlockIcon = styled(BlockIcon)(() => ({
  color: 'rgb(68 68 68 / 74%)',
  fontSize: '1.25rem',
}));

export const StyledResetAction = styled(GridActionsCellItem)(() => ({
  color: '#D0021B',
}));

export const StyledResetIcon = styled(SettingsBackupRestoreIcon)(() => ({
  color: '#D0021B',
  fontSize: '1.25rem',
}));
