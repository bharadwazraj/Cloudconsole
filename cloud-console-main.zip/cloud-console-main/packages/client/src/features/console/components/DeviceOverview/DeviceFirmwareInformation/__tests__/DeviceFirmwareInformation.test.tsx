import React from 'react';
import { render, screen } from '@testing-library/react';
import { TestWrapper } from '@cloud-console/test';
import messages from '../messages';
import { DeviceFirmwareInformation } from '../DeviceFirmwareInformation';

const FIRMWARE_LABEL = 0;

const handleRender = () =>
  render(
    <TestWrapper providers={[['Intl']]}>
      <DeviceFirmwareInformation />
    </TestWrapper>
  );

describe('<DeviceFirmwareInformation /> component', () => {
  it('should match to snapshot', () => {
    const { asFragment } = handleRender();
    expect(asFragment()).toMatchSnapshot();
  });

  describe('device information list', () => {
    it('should has "Firmware" title', () => {
      handleRender();
      expect(screen.getAllByText(/firmware/i)[FIRMWARE_LABEL]).toHaveTextContent(
        messages.firmware.defaultMessage
      );
    });

    it('should has "Apps" title', () => {
      handleRender();
      expect(screen.getByText(/apps/i)).toHaveTextContent(messages.apps.defaultMessage);
    });
  });
});
