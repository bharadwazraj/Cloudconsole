export default {
  DeviceStatistics: {
    id: 'DeviceStatistics',
  },
};
