export default {
  DeviceUnblockConfirmationDialog: {
    DialogActions: {
      id: 'DeviceUnblockConfirmationDialog-DialogActions',
    },
    DialogContent: {
      id: 'DeviceUnblockConfirmationDialog-DialogContent',
    },
    DialogTitle: {
      id: 'DeviceUnblockConfirmationDialog-DialogTitle',
    },
    id: 'DeviceUnblockConfirmationDialog',
  },
};
