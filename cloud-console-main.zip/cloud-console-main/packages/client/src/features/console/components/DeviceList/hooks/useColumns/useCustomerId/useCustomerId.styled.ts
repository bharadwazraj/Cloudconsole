import { styled } from '@mui/material';

export const StyledSpan = styled('span')(() => ({
  color: '#444444',
  fontSize: '0.875rem',
  fontWeight: 600,
  lineHeight: '1.5rem',
}));
