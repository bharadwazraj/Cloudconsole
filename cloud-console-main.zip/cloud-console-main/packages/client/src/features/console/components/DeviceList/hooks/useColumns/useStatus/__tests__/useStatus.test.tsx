import { renderHook } from '@testing-library/react';
import React, { PropsWithChildren } from 'react';
import { TestWrapper } from '@cloud-console/test';
import { DeviceListColumnEnum } from '../../../../enums';
import messages from '../../messages';
import { useStatus } from '../useStatus';

const wrapper: React.FC<PropsWithChildren> = ({ children }) => (
  <TestWrapper providers={[['Intl']]}>{children}</TestWrapper>
);
const handleRender = () => renderHook(() => useStatus(), { wrapper });

describe('useStatus() hook', () => {
  it('should return correct status column configuration', () => {
    const { result } = handleRender();
    expect(result.current).toEqual({
      field: DeviceListColumnEnum.STATUS,
      flex: 1,
      headerName: messages.status.defaultMessage,
      renderCell: expect.any(Function),
    });
  });
});
