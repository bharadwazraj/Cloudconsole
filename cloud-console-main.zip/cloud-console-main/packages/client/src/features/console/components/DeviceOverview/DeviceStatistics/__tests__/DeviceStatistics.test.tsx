import React from 'react';
import { render, screen } from '@testing-library/react';
import { TestWrapper } from '@cloud-console/test';
import { DeviceStatistics } from '../DeviceStatistics';
import messages from '../messages';

const handleRender = () =>
  render(
    <TestWrapper providers={[['Intl']]}>
      <DeviceStatistics />
    </TestWrapper>
  );

describe('<DigipassStatistics /> component', () => {
  it('should match to snapshot', () => {
    const { asFragment } = handleRender();
    expect(asFragment()).toMatchSnapshot();
  });

  it('should has correct title', () => {
    handleRender();
    expect(screen.getByText(/overview/i)).toHaveTextContent(messages.title.defaultMessage);
  });
});
