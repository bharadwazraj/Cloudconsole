import React, { PropsWithChildren } from 'react';
import { act, renderHook } from '@testing-library/react';
import type { SelectChangeEvent } from '@mui/material';
import { TestWrapper } from '@cloud-console/test';
import { DeviceFilterStatusEnum } from '@cloud-console/enums';
import { useStatusFilter } from '../useStatusFilter';
import messages from '../messages';

const wrapper: React.FC<PropsWithChildren> = ({ children }) => (
  <TestWrapper providers={[['Intl']]}>{children}</TestWrapper>
);
const handleRender = () => renderHook(() => useStatusFilter(), { wrapper });

describe('useStatusFilter() hook', () => {
  it('should return status filter config', () => {
    const { result } = handleRender();
    expect(result.current).toEqual({
      formFieldProps: { id: '' },
      hasOptionIcon: true,
      options: [
        {
          optionProps: { value: DeviceFilterStatusEnum.ALL },
          optionText: messages.all.defaultMessage,
        },
        {
          optionProps: { value: DeviceFilterStatusEnum.ACTIVE },
          optionText: messages.active.defaultMessage,
        },
        {
          optionProps: { value: DeviceFilterStatusEnum.INACTIVE },
          optionText: messages.inactive.defaultMessage,
        },
        {
          optionProps: { value: DeviceFilterStatusEnum.BLOCKED },
          optionText: messages.blocked.defaultMessage,
        },
        {
          optionProps: { value: DeviceFilterStatusEnum.UNBLOCK_PENDING },
          optionText: messages.unblockPending.defaultMessage,
        },
        {
          optionProps: { value: DeviceFilterStatusEnum.BLOCKED_PENDING },
          optionText: messages.blockedPending.defaultMessage,
        },
        {
          optionProps: { value: DeviceFilterStatusEnum.RESET_PENDING },
          optionText: messages.resetPending.defaultMessage,
        },
      ],
      selectProps: { onChange: expect.any(Function), value: DeviceFilterStatusEnum.ALL },
      startAdornmentText: messages.startAdornmentText.defaultMessage,
    });
  });

  it('should set value when function onChange has been called', () => {
    const event: Partial<SelectChangeEvent> = {
      target: {
        name: 'status',
        value: DeviceFilterStatusEnum.ACTIVE,
        ...new Event('status').target,
      },
    } as Partial<SelectChangeEvent>;

    const { result } = handleRender();
    expect(result.current.selectProps?.value).toEqual(DeviceFilterStatusEnum.ALL);
    act(() => {
      if (result.current.selectProps?.onChange)
        result.current.selectProps?.onChange(event as SelectChangeEvent, <div />);
    });
    expect(result.current.selectProps?.value).toEqual(DeviceFilterStatusEnum.ACTIVE);
  });
});
