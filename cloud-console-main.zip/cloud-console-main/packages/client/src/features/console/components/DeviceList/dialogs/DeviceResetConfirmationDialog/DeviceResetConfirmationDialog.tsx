import React, { useCallback } from 'react';
import { Button, Dialog, DialogActions, DialogContent, DialogTitle } from '@onespan/components';
import { useIntl } from 'react-intl';
import SettingsBackupRestoreIcon from '@mui/icons-material/SettingsBackupRestore';
import {
  useDeviceListActions,
  useDeviceListState,
} from '@cloud-console/contexts/DeviceListContext';
import messages from './messages';
import DataIds from './dataIds';

export const DeviceResetConfirmationDialog: React.FC = React.memo(() => {
  const { formatMessage } = useIntl();
  const { setDeviceResetConfirmationDialog } = useDeviceListActions();
  const { deviceResetConfirmationDialog } = useDeviceListState();
  const { data, isOpen } = deviceResetConfirmationDialog;

  const handleClose = useCallback(
    () => setDeviceResetConfirmationDialog({ data: undefined, isOpen: false }),
    [setDeviceResetConfirmationDialog]
  );

  if (!data) return null;

  const { customerId, deviceSerialNumber } = data;

  return (
    <Dialog
      data-testid={DataIds.DeviceResetConfirmationDialog.id}
      open={isOpen}
      status="error"
      onClose={handleClose}
    >
      <DialogTitle
        data-testid={DataIds.DeviceResetConfirmationDialog.DialogTitle.id}
        closeButtonProps={{
          'aria-label': formatMessage(messages.cancelButton),
          onClick: handleClose,
        }}
      >
        {formatMessage(messages.title)}
      </DialogTitle>
      <DialogContent data-testid={DataIds.DeviceResetConfirmationDialog.DialogContent.id}>
        {formatMessage(messages.content, { customerId, deviceSerialNumber })}
      </DialogContent>
      <DialogActions data-testid={DataIds.DeviceResetConfirmationDialog.DialogActions.id}>
        {/* TODO: change order of buttons, right know it does not matter because of implementation @onespan/components */}
        {/* TODO: need to fix @onespan/components */}
        <Button autoFocus variant="outlined" onClick={handleClose}>
          {formatMessage(messages.cancelButton)}
        </Button>
        {/* TODO: check in future if color has been change to "error", right now is impossible to override color like this */}
        <Button
          color="error"
          startIcon={<SettingsBackupRestoreIcon />}
          variant="contained"
          onClick={handleClose}
        >
          {formatMessage(messages.resetButton)}
        </Button>
      </DialogActions>
    </Dialog>
  );
});
