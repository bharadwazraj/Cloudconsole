import React, { useMemo } from 'react';
import type { GridColDef } from '@mui/x-data-grid';
import { useIntl } from 'react-intl';
import { DeviceStatusChip } from '@cloud-console/components/DeviceStatusChip';
import type { DeviceListType } from '../../../types';
import messages from '../messages';
import { DeviceListColumnEnum } from '../../../enums';

export const useStatus = () => {
  const { formatMessage } = useIntl();
  return useMemo<GridColDef<DeviceListType, DeviceListType['status']>>(
    () => ({
      field: DeviceListColumnEnum.STATUS,
      flex: 1,
      headerName: formatMessage(messages.status),
      renderCell: (params) => {
        const { row } = params;
        const { status } = row;
        return <DeviceStatusChip status={status} />;
      },
    }),
    [formatMessage]
  );
};
