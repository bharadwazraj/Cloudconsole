import { renderHook } from '@testing-library/react';
import React, { PropsWithChildren } from 'react';
import { TestWrapper } from '@cloud-console/test';
import { DeviceListColumnEnum } from '../../../../enums';
import messages from '../../messages';
import { useDeviceSerialNumber } from '../useDeviceSerialNumber';

const wrapper: React.FC<PropsWithChildren> = ({ children }) => (
  <TestWrapper providers={[['Intl']]}>{children}</TestWrapper>
);
const handleRender = () => renderHook(() => useDeviceSerialNumber(), { wrapper });

describe('useDeviceSerialNumber() hook', () => {
  it('should return correct device serial number column configuration', () => {
    const { result } = handleRender();
    expect(result.current).toEqual({
      field: DeviceListColumnEnum.DEVICE_SERIAL_NUMBER,
      flex: 1,
      headerName: messages.deviceSerialNumber.defaultMessage,
      renderCell: expect.any(Function),
    });
  });
});
