import { defineMessages } from 'react-intl';

export default defineMessages({
  active: {
    defaultMessage: 'Active',
    id: 'features.Console.components.DeviceList.DataGrid.filter.status.active',
  },
  all: {
    defaultMessage: 'All',
    id: 'features.Console.components.DeviceList.DataGrid.filter.status.all',
  },
  blocked: {
    defaultMessage: 'Blocked',
    id: 'features.Console.components.DeviceList.DataGrid.filter.status.blocked',
  },
  blockedPending: {
    defaultMessage: 'Blocked pending',
    id: 'features.Console.components.DeviceList.DataGrid.filter.status.blockedPending',
  },
  inactive: {
    defaultMessage: 'Inactive',
    id: 'features.Console.components.DeviceList.DataGrid.filter.status.inactive',
  },
  resetPending: {
    defaultMessage: 'Reset pending',
    id: 'features.Console.components.DeviceList.DataGrid.filter.status.resetPending',
  },
  startAdornmentText: {
    defaultMessage: 'Status',
    id: 'features.Console.components.DeviceList.DataGrid.label.startAdornmentText',
  },
  unblockPending: {
    defaultMessage: 'Unblock pending',
    id: 'features.Console.components.DeviceList.DataGrid.filter.status.unblockPending',
  },
});
