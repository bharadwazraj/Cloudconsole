export default {
  DeviceResetConfirmationDialog: {
    DialogActions: {
      id: 'DeviceResetConfirmationDialog-DialogActions',
    },
    DialogContent: {
      id: 'DeviceResetConfirmationDialog-DialogContent',
    },
    DialogTitle: {
      id: 'DeviceResetConfirmationDialog-DialogTitle',
    },
    id: 'DeviceResetConfirmationDialog',
  },
};
