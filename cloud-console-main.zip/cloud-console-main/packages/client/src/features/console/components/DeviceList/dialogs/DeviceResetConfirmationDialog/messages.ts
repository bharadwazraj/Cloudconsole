import { defineMessages } from 'react-intl';

export default defineMessages({
  cancelButton: {
    defaultMessage: 'Cancel',
    id: 'features.Console.components.DeviceList.dialogs.DeviceResetConfirmationDialog.cancelButton',
  },
  content: {
    defaultMessage:
      'Are you sure you want to reset the device "{deviceSerialNumber}" linked to customer ID "{customerId}"?\n\nResetting a device will format all the user data and remove it from the list of active devices. This will make it a free device and this action cannot be undone.',
    id: 'features.Console.components.DeviceList.dialogs.DeviceResetConfirmationDialog.content',
  },
  resetButton: {
    defaultMessage: 'Reset',
    id: 'features.Console.components.DeviceList.dialogs.DeviceResetConfirmationDialog.resetButton',
  },
  title: {
    defaultMessage: 'Reset device?',
    id: 'features.Console.components.DeviceList.dialogs.DeviceResetConfirmationDialog.title',
  },
});
