import { defineMessages } from 'react-intl';

export default defineMessages({
  customerId: {
    defaultMessage: 'Customer ID',
    id: 'features.console.components.DeviceList.DataGrid.column.customerId',
  },
  deviceSerialNumber: {
    defaultMessage: 'Device serial no.',
    id: 'features.console.components.DeviceList.DataGrid.column.deviceSerialNumber',
  },
  expires: {
    defaultMessage: 'Expires',
    id: 'features.console.components.DeviceList.DataGrid.column.expires',
  },
  status: {
    defaultMessage: 'Status',
    id: 'features.console.components.DeviceList.DataGrid.column.status',
  },
});
