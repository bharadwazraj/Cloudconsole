export default {
  DeviceFirmwareInformation: {
    id: 'DeviceFirmwareInformation',
  },
};
