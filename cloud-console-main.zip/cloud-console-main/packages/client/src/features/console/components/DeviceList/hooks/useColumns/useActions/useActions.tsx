import React, { useCallback, useMemo } from 'react';
import type { GridActionsCellItemProps, GridActionsColDef, GridRowParams } from '@mui/x-data-grid';
import { GridActionsCellItem } from '@mui/x-data-grid';
import { useIntl } from 'react-intl';
import { useDeviceListActions } from '@cloud-console/contexts/DeviceListContext';
import type { DeviceListType } from '../../../types';
import { DeviceListColumnEnum } from '../../../enums';
import messages from './messages';
import { StyledBlockIcon, StyledResetAction, StyledResetIcon } from './useActions.styled';

const isActive = ({ status }: DeviceListType) => status === 'ACTIVE';
const isBlocked = ({ status }: DeviceListType) => status === 'BLOCKED';
const isBlockedPending = ({ status }: DeviceListType) => status === 'BLOCKED_PENDING';
const isInactive = ({ status }: DeviceListType) => status === 'INACTIVE';
const isResetPending = ({ status }: DeviceListType) => status === 'RESET_PENDING';
const isUnblockPending = ({ status }: DeviceListType) => status === 'UNBLOCK_PENDING';

export const useActions = () => {
  const { formatMessage } = useIntl();
  const {
    setDeviceBlockConfirmationDialog,
    setDeviceResetConfirmationDialog,
    setDeviceUnblockConfirmationDialog,
  } = useDeviceListActions();

  const handleBlockAction = useCallback(
    (data: GridRowParams<DeviceListType>['row']) =>
      setDeviceBlockConfirmationDialog({ data, isOpen: true }),
    [setDeviceBlockConfirmationDialog]
  );

  const handleResetAction = useCallback(
    (data: GridRowParams<DeviceListType>['row']) =>
      setDeviceResetConfirmationDialog({ data, isOpen: true }),
    [setDeviceResetConfirmationDialog]
  );

  const handleUnblockAction = useCallback(
    (data: GridRowParams<DeviceListType>['row']) =>
      setDeviceUnblockConfirmationDialog({ data, isOpen: true }),
    [setDeviceUnblockConfirmationDialog]
  );

  const getBlockAction = useCallback(
    ({
      row,
    }: GridRowParams<DeviceListType>): React.ReactElement<GridActionsCellItemProps> | undefined => {
      const isVisible =
        isActive(row) || isInactive(row) || isUnblockPending(row) || isResetPending(row);
      if (isVisible) {
        return (
          <GridActionsCellItem
            showInMenu
            icon={<StyledBlockIcon />}
            label={formatMessage(messages.block)}
            onClick={() => handleBlockAction(row)}
          />
        );
      }
      return undefined;
    },
    [formatMessage, handleBlockAction]
  );

  const getResetAction = useCallback(
    ({ row }: GridRowParams<DeviceListType>): React.ReactElement<GridActionsCellItemProps> => {
      return (
        <StyledResetAction
          showInMenu
          icon={<StyledResetIcon />}
          label={formatMessage(messages.reset)}
          onClick={() => handleResetAction(row)}
        />
      );
    },
    [formatMessage, handleResetAction]
  );

  const getUnblockAction = useCallback(
    ({
      row,
    }: GridRowParams<DeviceListType>): React.ReactElement<GridActionsCellItemProps> | undefined => {
      const isVisible = isBlocked(row) || isBlockedPending(row);
      if (isVisible) {
        return (
          <GridActionsCellItem
            showInMenu
            icon={<StyledBlockIcon />}
            label={formatMessage(messages.unblock)}
            onClick={() => handleUnblockAction(row)}
          />
        );
      }
      return undefined;
    },
    [formatMessage, handleUnblockAction]
  );

  const getActions = useCallback(
    (params: GridRowParams<DeviceListType>): React.ReactElement<GridActionsCellItemProps>[] => {
      const actions: React.ReactElement<GridActionsCellItemProps>[] = [];

      const block = getBlockAction(params);
      const unblock = getUnblockAction(params);
      const reset = getResetAction(params);

      if (block) actions.push(block);
      if (unblock) actions.push(unblock);
      actions.push(reset);

      return actions;
    },
    [getBlockAction, getResetAction, getUnblockAction]
  );

  return useMemo<GridActionsColDef<DeviceListType>>(
    () => ({
      align: 'right',
      field: DeviceListColumnEnum.ACTIONS,
      flex: 1,
      getActions,
      type: 'actions',
    }),
    [getActions]
  );
};
