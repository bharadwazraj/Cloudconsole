export { default } from './Console';
