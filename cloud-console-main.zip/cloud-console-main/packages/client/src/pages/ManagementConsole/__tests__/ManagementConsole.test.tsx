import React from 'react';
import { render, screen } from '@testing-library/react';
import { ManagementConsole } from '../ManagementConsole';
import ConsoleDataIds from '../../../features/console/dataIds';
import { TestWrapper } from '../../../testing';

const handleRender = () =>
  render(
    <TestWrapper providers={[['Intl']]}>
      <ManagementConsole />
    </TestWrapper>
  );

describe('<ManagementConsole /> component', () => {
  it('should render <ManagementConsole /> component', () => {
    handleRender();
    const console = screen.getByTestId(ConsoleDataIds.Console.id);
    expect(console).toBeInTheDocument();
  });
});
