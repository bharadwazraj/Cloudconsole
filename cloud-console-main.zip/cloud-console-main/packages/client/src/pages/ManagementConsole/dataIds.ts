export default {
  ManagementConsole: {
    id: 'ManagementConsole',
  },
};
