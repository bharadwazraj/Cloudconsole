import React from 'react';
import { Grid } from '@mui/material';
import Console from '../../features/console';
import DataIds from './dataIds';
import { StyledGridContainer } from './ManagementConsole.styled';

export const ManagementConsole: React.FC = () => {
  return (
    <StyledGridContainer container data-testid={DataIds.ManagementConsole.id}>
      <Grid item xs={12}>
        <Console />
      </Grid>
    </StyledGridContainer>
  );
};

export default React.memo(ManagementConsole);
