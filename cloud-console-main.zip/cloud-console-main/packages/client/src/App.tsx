import React from 'react';
import { Main } from '@cloud-console/components/Main';
import { ReactRouter } from '@cloud-console/components/ReactRouter';

export const App: React.FC = React.memo(() => {
  return (
    <Main>
      <ReactRouter />
    </Main>
  );
});
