const path = require('path');

module.exports = {
  env: {
    browser: true,
    commonjs: true,
    node: true,
    es6: true,
  },
  ignorePatterns: ['test/resolvers.ts'],
  extends: ['oss-ui'],
  parserOptions: { ecmaVersion: 'latest', sourceType: 'module' },
  overrides: [
    {
      files: ['**/*.ts', '**/*.tsx'],
      extends: [
        'oss-ui',
        'oss-ui-typescript',
        'prettier',
        'plugin:import/recommended',
        'plugin:import/typescript',
      ],
      parser: '@typescript-eslint/parser',
      parserOptions: {
        project: path.join(__dirname, 'tsconfig.json'),
        ecmaVersion: 'latest',
      },
      rules: {
        'react/prop-types': 'off',
        'react/jsx-props-no-spreading': 'off',
        'react/jsx-filename-extension': 'off',
        'react/jsx-sort-props': [
          2,
          {
            callbacksLast: true,
            ignoreCase: true,
            noSortAlphabetically: false,
            shorthandFirst: true,
            shorthandLast: false,
            multiline: 'last',
          },
        ],
        'import/no-unresolved': 'off',
        'no-restricted-exports': 'off',
        '@typescript-eslint/no-misused-promises': ['error', { checksVoidReturn: false }],
        // keep this til testing-library fixes their latest version of user-event library
        '@typescript-eslint/await-thenable': 'off',
        '@typescript-eslint/unbound-method': 'off',
        'typescript-sort-keys/interface': 'error',
        'typescript-sort-keys/string-enum': 'error',
        'sort-destructure-keys/sort-destructure-keys': [2, { caseSensitive: true }],
        'sort-keys': 0, // disable default eslint sort-keys
        'sort-keys/sort-keys-fix': 1,
      },
      settings: {
        'import/parsers': {
          '@typescript-eslint/parser': ['.ts', '.tsx'],
        },
        'import/resolver': {
          typescript: {
            alwaysTryTypes: true,
          },
        },
      },
    },
  ],
  plugins: [
    'babel',
    'react',
    'react-hooks',
    'sort-keys',
    'sort-destructure-keys',
    'typescript-sort-keys',
  ],
  settings: { react: { version: 'detect' } },
};
