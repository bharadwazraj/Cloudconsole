const { dependencies: deps } = require('../package.json');

module.exports = {
  name: 'cloudconsole_osp',
  filename: 'mfe/remoteEntry.js',
  remotes: {},
  exposes: {
    './App': './src/App',
  },
  shared: {
    ...deps,
  },
};
