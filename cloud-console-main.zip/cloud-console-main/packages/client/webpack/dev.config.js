/* eslint-disable import/no-extraneous-dependencies */
const { merge } = require('webpack-merge');
const SourceMapDevToolPlugin = require('webpack/lib/SourceMapDevToolPlugin');
const ESLintPlugin = require('eslint-webpack-plugin');
const path = require('path');
const commonConf = require('./common.config');
// eslint-disable-next-line import/extensions
const eslintFile = require('../.eslintrc.js');

const CLIENT_PORT = process.env.CLIENT_PORT || 3007;
const SERVER_PORT = process.env.SERVER_PORT || 3070;

const devConfig = {
  mode: 'development',
  output: {
    publicPath: `http://localhost:${CLIENT_PORT}/`,
    chunkFilename: 'assets/chunk.[name].[contenthash].js',
    path: path.resolve(__dirname, '../build'),
  },
  optimization: {
    runtimeChunk: 'single',
  },
  devServer: {
    port: CLIENT_PORT,
    hot: true,
    proxy: {
      '/mock-server/': {
        target: `http://localhost:${CLIENT_PORT}`,
        router: () => `http://localhost:${SERVER_PORT}`,
        logLevel: 'debug' /* optional */,
      },
    },
    headers: { 'Access-Control-Allow-Origin': '*' },
    historyApiFallback: true,
    allowedHosts: ['.onespan-internal.com', 'localhost'],
  },
  devtool: false,
  plugins: [
    new SourceMapDevToolPlugin({}),
    new ESLintPlugin({
      cache: true,
      cwd: path.resolve(__dirname),
      emitWarning: true,
      failOnError: false,
      formatter: 'codeframe',
      useEslintrc: false,
      baseConfig: {
        ...eslintFile,
      },
    }),
  ],
};

module.exports = (env) => {
  return merge(commonConf(env), devConfig);
};
