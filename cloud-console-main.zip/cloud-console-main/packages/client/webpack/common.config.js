/* eslint-disable import/no-extraneous-dependencies */
const path = require('path');
const ModuleFederationPlugin = require('webpack/lib/container/ModuleFederationPlugin');
const TsconfigPathsPlugin = require('tsconfig-paths-webpack-plugin');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const remoteOptions = require('./remotes.config');

module.exports = () => {
  return {
    resolve: {
      // https://www.npmjs.com/package/tsconfig-paths-webpack-plugin
      plugins: [new TsconfigPathsPlugin()],
      extensions: ['.tsx', '.ts', '.jsx', '.js', '.json'],
      modules: ['src', 'node_modules'],
    },
    output: {
      filename: `mfe/assets/index_[contenthash].js`,
      chunkFilename: 'mfe/assets/chunk.[name].[contenthash].js',
      path: path.resolve(__dirname, '../build'),
    },
    module: {
      rules: [
        {
          test: /\.(ts|tsx|js|jsx)$/,
          exclude: /node_modules/,
          use: {
            loader: 'babel-loader',
            options: {
              presets: ['@babel/preset-react', '@babel/preset-env', '@babel/preset-typescript'],
              plugins: ['@babel/plugin-transform-runtime'],
            },
          },
        },
        {
          test: /\.json$/,
          loader: 'json-loader',
        },
        {
          test: /\.m?js/,
          type: 'javascript/auto',
          resolve: {
            fullySpecified: false,
          },
        },
        {
          test: /\.css$/,
          use: ['style-loader', 'css-loader'],
        },
        {
          test: /\.svg$/,
          use: ['file-loader'],
        },
      ],
    },
    plugins: [
      new HtmlWebpackPlugin({
        template: './public/template.html',
        cache: false,
        hash: true,
      }),
      new ModuleFederationPlugin(remoteOptions),
    ],
  };
};
