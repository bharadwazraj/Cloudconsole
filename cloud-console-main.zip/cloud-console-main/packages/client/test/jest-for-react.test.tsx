import 'jest-extended';

describe('test setup for react and .tsx', () => {
  it('is defined correctly', () => {
    expect(true).toEqual(true);
  });
});
