// eslint-disable-next-line @typescript-eslint/no-empty-function
export default function globalSetup() {}
