export function setup() {
  // Do your setup here.
  // This function prevents linting errors related to isolatedModules
}

setup();
