# @osp/cloud-console-client

## Table of Contents

1. [Development server](#development-server)
2. [Built-in resources](#built-in-resources)
3. [Tutorials and guidelines](#tutorials-and-guidelines)

### Development server

```sh
# start the webpack watcher and server, application will be accessible
# through the browser at http://localhost:3007/
yarn dev
```

### Built-in resources

* React
* Jest
* Typescript
* @onespan/components
* @mui
* react-router-dom
* built in reducer
* axios

### Tutorials and guidelines

* [Webpack module federation](https://jira.onespan.com/confluence/display/EAG/Webpack+module+federation)
