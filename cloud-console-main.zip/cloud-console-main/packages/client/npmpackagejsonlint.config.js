module.exports = {
  extends: '@oss-ui/npm-package-json-lint-config',
  rules: {
    'no-file-dependencies': 'off',
    'no-git-dependencies': 'off',
  },
};
