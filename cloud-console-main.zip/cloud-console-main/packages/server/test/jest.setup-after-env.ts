import 'jest-extended';

jest.useFakeTimers();

afterAll(() => {
  jest.runAllTimers();
});
