export const newAccountMock = {
  accountUuid: '1ee4ba89-06a0-449b-af89-e878e96d8f23',
  realm: `DIstring`,
  userUuid: '70bb859c-7de9-430c-b5fb-ffdcc107a0cd',
};

export const account = {
  emailAddress: 'jhonPACT@onespan.com',
  password: 'MyPwd@0n3Sp4N',
  firstName: 'jhon',
  lastName: 'PACT',
  customerName: 'onespan',
};

export const conflictedUserException = {
  extensions: {
    response: {
      status: 409,
      body: {
        status: 409,
        traceID: '6ca0f6904afa46fb45bdf44f11e0dcf3',
        timestamp: '2021-11-11T21:21:34.396362421Z',
        error: 'Conflict',
        message: 'Request execution exception, please verify logs',
        errors: [
          {
            object: 'SignUpRequest',
            field: 'realm.create',
            message: 'Realm already exist.',
          },
        ],
      },
    },
  },
};
