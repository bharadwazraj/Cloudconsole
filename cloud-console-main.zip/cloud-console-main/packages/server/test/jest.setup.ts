import { StatusCodes, ReasonPhrases } from 'http-status-codes';
import Promise from 'bluebird';
// eslint-disable-next-line import/no-unresolved, import/extensions
import { logger, httpLogger } from '../src/logger';

declare global {
  type MockedHttpErrorStatus = StatusCodes.NOT_FOUND | StatusCodes.METHOD_NOT_ALLOWED;
  type MockedHttpError = { name: string; message: string; status: MockedHttpErrorStatus };

  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace NodeJS {
    interface Global {
      STANDARD_HTTP_ERRORS: Record<MockedHttpErrorStatus, MockedHttpError>;
      INDEX_CONTENT: string;
    }
  }
}

logger.level = 'error';
httpLogger.level = 'error';

// global.Promise = Promise;
// Aha! tricked you :P
Object.assign(global, { Promise });

global.STANDARD_HTTP_ERRORS = {
  404: { name: 'NotFoundError', message: ReasonPhrases.NOT_FOUND, status: StatusCodes.NOT_FOUND },
  405: {
    name: 'MethodNotAllowedError',
    message: ReasonPhrases.METHOD_NOT_ALLOWED,
    status: StatusCodes.METHOD_NOT_ALLOWED,
  },
};
