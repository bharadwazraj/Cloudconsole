export const contentType: Record<'JSON' | 'HTML', [string, RegExp]> = {
  JSON: ['Content-Type', /application\/json/],
  HTML: ['Content-Type', /text\/html/],
};
