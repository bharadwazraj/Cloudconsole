import { StatusCodes } from 'http-status-codes';
import request from 'supertest';
import app from '../src/app';

const contentType = 'Content-Type';

describe('app', () => {
  describe('/', () => {
    it('returns the index view with "@mfe/client" title', () =>
      request(app)
        .get('/')
        .expect(contentType, /text\/html/)
        .expect(StatusCodes.OK)
        .then(({ text }) => {
          expect(text).toContain('@mfe/client');
        }));
  });

  describe('actuator', () => {
    it('returns a info json object', () =>
      request(app)
        .get('/info')
        .expect(contentType, /application\/json/)
        .expect(StatusCodes.OK)
        .then((response) => {
          expect(response.body).toHaveProperty('build');
        }));

    it('returns a metrics json object', () =>
      request(app)
        .get('/metrics')
        .expect(contentType, /application\/json/)
        .expect(StatusCodes.OK)
        .then((response) => {
          expect(response.body).toHaveProperty('uptime');
        }));

    it('returns a health json object', () =>
      request(app)
        .get('/health')
        .expect(contentType, /application\/json/)
        .expect(StatusCodes.OK)
        .then((response) => {
          expect(response.body).toHaveProperty('status');
        }));
  });
});
