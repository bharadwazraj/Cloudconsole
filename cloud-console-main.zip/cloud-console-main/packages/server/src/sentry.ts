// eslint-disable-next-line import/no-extraneous-dependencies
import * as Sentry from '@sentry/node';
// eslint-disable-next-line import/no-extraneous-dependencies
import { RewriteFrames } from '@sentry/integrations';
import type { RequestHandler, ErrorRequestHandler } from 'express';

import pkg from '../package.json';

type SentryHandlers = {
  request: RequestHandler;
  error: ErrorRequestHandler;
};

type Args = { SENTRY_DSN?: string };

export default function sentry({ SENTRY_DSN: dsn }: Args): SentryHandlers {
  let request: RequestHandler = (req, res, next) => next();
  let error: ErrorRequestHandler = (err, req, res, next) => next(err);

  if (dsn) {
    Sentry.init({
      dsn,
      release: `${pkg.name}@${pkg.version}`,
      integrations: [new RewriteFrames()],
    });

    request = Sentry.Handlers.requestHandler({
      request: ['data', 'headers', 'method', 'query_string', 'url'],
    });

    error = Sentry.Handlers.errorHandler();
  }

  return { request, error };
}
