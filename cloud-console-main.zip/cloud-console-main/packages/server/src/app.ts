import express from 'express';
import path from 'path';
import cookieParser from 'cookie-parser';
import hbs from 'express-hbs';
import format from 'date-fns/format';
import actuator from 'express-actuator';
import compression from 'compression';
import expressPino from 'express-pino-logger';

import { httpLogger } from './logger';
import config from './config';
import sentry from './sentry';

import * as errors from './middlewares/errors';
import clients from './middlewares/clients';

const accessLogger = expressPino({ logger: httpLogger });

const app = express();
const conf = config();
const sentryHandlers = sentry(conf);

app.use(sentryHandlers.request);
app.use(accessLogger);
app.engine('hbs', hbs.express4({}));

app.set('view engine', 'hbs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.json());

app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(compression());

const BUILD_TIMESTAMP = process.env.BUILD_TIMESTAMP || '';

// Routes
app.use(
  actuator({
    infoDateFormat: conf.DATE_FORMAT,
    infoBuildOptions: {
      time: format(BUILD_TIMESTAMP, conf.DATE_FORMAT),
    },
  })
);

clients(app);

app.use(sentryHandlers.error);
app.use(errors.handleError);

export default app;
