/* istanbul ignore file */
import { devLogger, prodLogger } from '@oss-ui/express-server';
import pkg from '../package.json';

const isProduction = process.env.NODE_ENV === 'production';
const pino = isProduction ? prodLogger : devLogger;
const defaultLevel = process.env.LOGGING_LEVEL || (isProduction ? 'info' : 'debug');
const defaultOptions = { name: pkg.name, level: defaultLevel };

export const level = defaultLevel;
// By default process.env.LOGGING_LEVEL controls the instance unless overwritten
export const logger = pino({ ...defaultOptions });
export const httpLogger = pino({
  ...defaultOptions,
  level: process.env.LOGGING_LEVEL_HTTP || defaultLevel,
});
