/* eslint-disable jest/expect-expect, @typescript-eslint/unbound-method */
import { StatusCodes } from 'http-status-codes';
import type { Application, Request, Response } from 'express';
import * as errors from './errors';

describe('middlewares errors', () => {
  describe('errors.catchAllTo404(req, res, next)', () => {
    it('passes with a new 404 error', () => {
      // const next = jest.fn();
      // const res = {} as Response;
      // res.status = jest.fn().mockReturnValue(res);
      // res.send = jest.fn().mockReturnValue(res);
      // errors.catchAllTo404({} as Request, res, next);
      // expect(res.status).toHaveBeenCalledTimes(1);
      // expect(res.send).toHaveBeenCalledWith(ReasonPhrases.NOT_FOUND);
    });
  });

  describe('errors.handleError(err, req, res, next)', () => {
    let testError: Error;
    let req: Request;
    let res: Response;

    const next = jest.fn();

    beforeEach(() => {
      req = {
        log: { error: jest.fn() },
        accepts: jest.fn(),
        app: {
          get: jest.fn(),
        } as unknown as Application,
      } as unknown as Request;

      res = {
        status: jest.fn(),
        json: jest.fn(),
        render: jest.fn(),
        format: jest.fn(),
      } as unknown as Response;
    });

    function makeTestError(status = StatusCodes.NOT_FOUND) {
      return {
        name: 'test error',
        status,
        message: 'I am a test error message',
      };
    }

    beforeEach(() => {
      testError = makeTestError(StatusCodes.NOT_FOUND);
    });

    describe.each([
      StatusCodes.BAD_REQUEST,
      StatusCodes.NOT_FOUND,
      StatusCodes.INTERNAL_SERVER_ERROR,
      undefined,
    ])('give err.status is %s', (status) => {
      const expectedStatus = status || StatusCodes.INTERNAL_SERVER_ERROR;

      it(`sets the response status code to ${expectedStatus}`, () => {
        Object.assign(testError, { status });

        errors.handleError(testError, req, res, next);

        const { status: resStatus } = res;

        expect(resStatus).toHaveBeenCalledTimes(1);
        expect(resStatus).toHaveBeenCalledWith(expectedStatus);

        expect(next).toHaveBeenCalledTimes(0);
      });
    });

    describe('given format should be "application/json"', () => {
      it('sends back json: {message: err.message, error: {}}', () => {
        (res.format as jest.MockedFunction<typeof res.format>).mockImplementation((format) =>
          format.json()
        );

        errors.handleError(testError, req, res, next);

        expect(res.json).toHaveBeenCalledTimes(1);
        expect(res.json).toHaveBeenCalledWith({
          ...testError,
        });
        expect(next).toHaveBeenCalledTimes(0);
      });
    });

    describe.each([
      ['unspecified', 'default'],
      ['text/html', 'text/html'],
    ])('given Accept is %s', (accept, formatKey) => {
      it('renders the "error" view with data {message: err.message, error: {}}', () => {
        (res.format as jest.MockedFunction<typeof res.format>).mockImplementation((format) =>
          format[formatKey]()
        );

        errors.handleError(testError, req, res, next);

        const { render } = res;
        expect(render).toHaveBeenCalledTimes(1);
        expect(render).toHaveBeenCalledWith('error', {
          ...testError,
        });

        expect(next).toHaveBeenCalledTimes(0);
      });
    });

    describe('given `res.sentry` is present in the response', () => {
      it('includes `sentry` in the data', () => {
        (res.format as jest.MockedFunction<typeof res.format>).mockImplementation((format) =>
          format.json()
        );

        const resWithSentry = { sentry: 'abcd', ...res } as Response;

        errors.handleError(testError, req, resWithSentry, next);

        expect(res.json).toHaveBeenCalledTimes(1);
        expect(res.json).toHaveBeenCalledWith({
          ...testError,
          sentry: 'abcd',
        });
        expect(next).toHaveBeenCalledTimes(0);
      });
    });

    describe.each([
      ['development', makeTestError(StatusCodes.NOT_FOUND)],
      ['test', makeTestError(StatusCodes.NOT_FOUND)],
      ['production', makeTestError(StatusCodes.NOT_FOUND)],
    ])('given app ENV is "%s"', (env, errorData) => {
      beforeEach(() => {
        (req.app.get as jest.MockedFunction<(name: string) => unknown>).mockReturnValue(env);
        (res.format as jest.MockedFunction<typeof res.format>).mockImplementation((format) =>
          format.default()
        );
      });

      it('includes err in the response', () => {
        errors.handleError(testError, req, res, next);

        expect(req.app.get).toHaveBeenCalledWith('env');

        const { render } = res;
        expect(render).toHaveBeenCalledTimes(1);
        expect(render).toHaveBeenCalledWith('error', {
          ...errorData,
          message: testError.message,
        });
        expect(next).toHaveBeenCalledTimes(0);
      });
    });
  });
});
