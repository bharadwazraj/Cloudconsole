import fs from 'fs';
import express, { Express, Request, Response } from 'express';

import { clientDir, clientIndexFile } from '../web-client';

import { logger } from '../logger';

logger.info(clientIndexFile);

export default function clients(app: Express) {
  // If client dir has "index.html"
  // It will render and ignore clients.render
  app.use(express.static(clientDir));

  // If no index.html found, we should be serving index.html anyhow.
  // We expect our clients/static apps to use push state
  app.get('*', (req: Request, res: Response) => {
    // Test existence of index before rendering
    // Client dev mode can make the index disappear from disk
    /* istanbul ignore next */
    if (!fs.existsSync(clientIndexFile) && app.get('env') !== 'production') {
      res.render('dev');
    } else {
      res.sendFile(clientIndexFile);
    }
  });
}
