import { StatusCodes } from 'http-status-codes';
import type { RequestHandler, ErrorRequestHandler } from 'express';

// catch 404 and forward to error handler
export const catchAllTo404: RequestHandler = (req, res, next) => {
  next();
};

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Response {
      sentry?: string;
    }
  }
}

// error handler
export const handleError: ErrorRequestHandler = (err, req, res, next) => {
  // expressjs uses arity to identify error handlers
  /* eslint @typescript-eslint/no-unused-vars: ["error", { "argsIgnorePattern": "^next$" }] */
  const { status = StatusCodes.INTERNAL_SERVER_ERROR, name, message, stack } = err;

  res.status(status);
  if (status >= StatusCodes.INTERNAL_SERVER_ERROR) {
    req.log.error(err);
  }

  // set data, only providing error in development
  const data = {
    status,
    name,
    message,
    ...(req.app.get('env') === 'development' ? { stack } : {}),
    ...(res.sentry ? { sentry: res.sentry } : {}),
  };

  const render = () => res.render('error', { ...data });

  res.format({
    'text/html': render,
    json() {
      res.json({ ...data });
    },
    default: render,
  });
};
