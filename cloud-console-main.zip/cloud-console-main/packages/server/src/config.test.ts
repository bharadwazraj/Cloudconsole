import config from './config';

describe('config()', () => {
  describe('.APP_ID', () => {
    it('reflects process.pid', () => {
      expect(config()).toHaveProperty('APP_ID', process.pid);
    });
  });
  describe.each([
    ['HOSTNAME', 'HOSTNAME', 'hostname', 'localhost'],
    ['SYNC_PORT', 'SYNC_PORT', 'sync_port', '3002'],
    ['PORT', 'PORT', 'port', '3000'],
    ['PROTOCOL', 'PROTOCOL', 'protocol', 'http'],
    ['SENTRY_DSN', 'SENTRY_DSN', 'sentry_dsn', ''],
    ['SSL_KEY_PATH', 'SSL_KEY_PATH', 'ssl_key_path', ''],
    ['SSL_CERT_PATH', 'SSL_CERT_PATH', 'ssl_cert_path', ''],
  ])('.%s', (key, envKey, envValue, defaultValue) => {
    let originalEnvValue: string | undefined;

    beforeEach(() => {
      originalEnvValue = process.env[envKey];
    });

    afterEach(() => {
      if (originalEnvValue === undefined) {
        delete process.env[envKey];
      } else {
        process.env[envKey] = originalEnvValue;
      }
    });

    describe(`when process.env.${envKey} is provided`, () => {
      beforeEach(() => {
        process.env[envKey] = envValue;
      });

      it('has the env var value', () => {
        expect(config()).toHaveProperty(key, envValue);
      });
    });

    describe(`when env.${envKey} is NOT provided`, () => {
      beforeEach(() => {
        delete process.env[envKey];
      });

      it(`defaults to "${defaultValue}"`, () => {
        expect(config()).toHaveProperty(key, defaultValue);
      });
    });
  });
});
