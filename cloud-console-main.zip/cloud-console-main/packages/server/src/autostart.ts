/* istanbul ignore file */

import { start } from '.';

if (module.hot) {
  module.hot.accept('./index', start);
}
start();
