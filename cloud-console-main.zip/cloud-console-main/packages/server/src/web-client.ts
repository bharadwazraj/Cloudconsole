import path from 'path';

// look for client build folder
export const clientDir = path.join(__dirname, '../../client', 'build');

export const clientIndexFile = path.join(clientDir, 'index.html');
