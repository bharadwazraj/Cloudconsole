declare module 'express-hbs';
