import * as MockedServer from '@oss-ui/express-server';

import config from './config';
import * as main from './index';
import app from './app';
import { logger } from './logger';

jest.mock('./config', () => ({
  __esModule: true,
  default: jest.fn(() => ({ answer: 42 })),
  JSON_DATA_DIR: 'mocked?',
}));

const mockedConfig = config as jest.MockedFunction<typeof config>;

jest.mock('@oss-ui/express-server', () => ({
  server: jest.fn(() => {
    return {
      start: jest.fn(),
      restart: jest.fn(),
      stop: jest.fn(),
    };
  }),
}));

describe('index', () => {
  let instance: {
    start: (conf: Record<string, unknown>) => void;
    stop: () => void;
    restart: () => void;
  };

  beforeAll(() => {
    instance = MockedServer.server.mock.results[0].value;
  });

  it('creates a server instance with app', () => {
    expect(MockedServer.server).toHaveBeenCalledWith(app, { logger, ...config() });
  });

  it('returns an interface to manage the server', () => {
    expect(main).toMatchObject({
      start: expect.any(Function),
      stop: expect.any(Function),
      restart: expect.any(Function),
    });
  });

  describe('.start()', () => {
    it('starts the server with the config', () => {
      main.start();

      expect(instance.start).toHaveBeenCalledTimes(1);
      expect(instance.start).toHaveBeenCalledWith(mockedConfig.mock.results[0].value);
    });
  });

  describe('.stop()', () => {
    it('stops the server instance', () => {
      main.stop();

      expect(instance.stop).toHaveBeenCalledTimes(1);
    });
  });

  describe('.restart()', () => {
    it('restarts the server instance', () => {
      main.restart();

      expect(instance.restart).toHaveBeenCalledTimes(1);
      expect(instance.restart).toHaveBeenCalledWith();
    });
  });
});
