export type Config = {
  APP_ID: number;
  FETCH_TIMEOUT: number;
  DATE_FORMAT: string;
  HOSTNAME: string;
  SYNC_PORT: string;
  PORT: string;
  PROTOCOL: string;
  SENTRY_DSN: string;
  SSL_KEY_PATH: string;
  SSL_CERT_PATH: string;
  API_ALLOW_INSECURE: boolean;
  PROJECT_NAME: string;
};

export default function config(): Config {
  return {
    APP_ID: process.pid,
    PROJECT_NAME: process.env.PROJECT_NAME || 'mock-server',
    FETCH_TIMEOUT: Number(process.env.FETCH_TIMEOUT || 3000),
    DATE_FORMAT: process.env.DATE_FORMAT || 'YYYY-MM-DD HH:mm:ssZZ',
    HOSTNAME: process.env.HOSTNAME || 'localhost',

    SYNC_PORT: process.env.SYNC_PORT || '3002',
    PORT: process.env.PORT || '3000',
    PROTOCOL: process.env.PROTOCOL || 'http',

    SENTRY_DSN: process.env.SENTRY_DSN || '',

    SSL_KEY_PATH: process.env.SSL_KEY_PATH || '',
    SSL_CERT_PATH: process.env.SSL_CERT_PATH || '',
    API_ALLOW_INSECURE: (process.env.API_ALLOW_INSECURE || 'false') === 'true',
  };
}
