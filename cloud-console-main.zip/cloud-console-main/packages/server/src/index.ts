import { server } from '@oss-ui/express-server';

import config from './config';
import app from './app';
import { logger } from './logger';

const secrets = config();
const instance = server(app, { logger, ...secrets });

export function start() {
  instance.start(secrets);
}

export function stop() {
  instance.stop();
}

export function restart() {
  instance.restart();
}

/* istanbul ignore next */
if (module.hot) {
  module.hot.dispose(() => stop());
}
