import * as Sentry from '@sentry/node';
import type { Request, Response } from 'express';
import pkg from '../package.json';
import sentry from './sentry';

describe('sentry({ SENTRY_DSN })', () => {
  describe('when `SENTRY_DSN` is falsy', () => {
    it('returns an object with noop `request` and `error` middlewares', () => {
      const handlers = sentry({ SENTRY_DSN: undefined });

      expect(handlers).toMatchObject({
        request: expect.any(Function),
        error: expect.any(Function),
      });

      const next = jest.fn();
      const req = {} as Request;
      const res = {} as Response;
      handlers.request(req, res, next);
      expect(next).toHaveBeenCalledTimes(1);
      expect(next).toHaveBeenCalledWith();

      const err = {};
      handlers.error(err, req, res, next);
      expect(next).toHaveBeenCalledTimes(2);
      expect(next).toHaveBeenCalledWith(err);
    });
  });

  describe('when `SENTRY_DSN` as a thruty value', () => {
    /* eslint-disable @typescript-eslint/no-empty-function */
    const request = (): void => {};
    const error = (): void => {};
    let handlers: Record<string, unknown>;

    beforeAll(() => {
      jest.spyOn(Sentry, 'init').mockReturnValue(undefined);

      jest.spyOn(Sentry.Handlers, 'requestHandler').mockReturnValue(request);
      jest.spyOn(Sentry.Handlers, 'errorHandler').mockReturnValue(error);

      handlers = sentry({ SENTRY_DSN: 'my-sentry-dsn' });
    });

    it('initializes Sentry with the provided dsn', () => {
      expect(Sentry.init).toHaveBeenCalledWith(
        expect.objectContaining({
          dsn: 'my-sentry-dsn',
          release: `${pkg.name}@${pkg.version}`,
        })
      );
    });

    it('returns an object with real `request` and `error` middlewares', () => {
      expect(handlers).toMatchObject({ request, error });
    });
  });
});
