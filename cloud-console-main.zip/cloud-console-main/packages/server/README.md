# @osp/cloud-console-server

The server package is supposed to provide a means to serve the client bundle

### Start the server

```sh
yarn start
```
