/** @type {import('ts-jest/dist/types').InitialOptionsTsJest} */
module.exports = {
  preset: 'ts-jest',
  testEnvironment: 'node',
  modulePathIgnorePatterns: ['<rootDir>/build/'],
  transform: {
    '\\.(js|ts)$': 'ts-jest',
  },
  testRegex: undefined,
  testMatch: ['<rootDir>/**/*.test.ts'],
  setupFiles: ['<rootDir>/test/jest.setup.ts'],
  setupFilesAfterEnv: ['<rootDir>/test/jest.setup-after-env.ts'],
  globalSetup: '<rootDir>/test/jest.global-setup.ts',
  globalTeardown: '<rootDir>/test/jest.global-teardown.ts',
  reporters: ['default', 'anthem-jest-sonar-reporter', 'jest-junit'],
  // A list of reporter names that Jest uses when writing coverage reports
  coverageReporters: ['cobertura', 'json', 'text', 'lcov', 'clover'],
  coverageThreshold: {
    global: {
      branches: 75,
      functions: 75,
      lines: 75,
      statements: 0,
    },
  },
};
