/* eslint-disable import/no-extraneous-dependencies */
// Default imports for opentelemetry
const { diag, DiagConsoleLogger, DiagLogLevel } = require('@opentelemetry/api');
const { BatchSpanProcessor, ConsoleSpanExporter } = require('@opentelemetry/sdk-trace-base');
const { NodeTracerProvider } = require('@opentelemetry/sdk-trace-node');
const { Resource } = require('@opentelemetry/resources');
const { SemanticResourceAttributes } = require('@opentelemetry/semantic-conventions');

// Extra exporters
const { CollectorTraceExporter } = require('@opentelemetry/exporter-collector-grpc');
const grpc = require('@grpc/grpc-js');

// Instrumentation specific to this project
const { PinoInstrumentation } = require('@opentelemetry/instrumentation-pino');
const { registerInstrumentations } = require('@opentelemetry/instrumentation');
const { HttpInstrumentation } = require('@opentelemetry/instrumentation-http');
const { DnsInstrumentation } = require('@opentelemetry/instrumentation-dns');
const { ExpressInstrumentation } = require('@opentelemetry/instrumentation-express');

// Safe defaults
const OTEL_RESOURCE_ATTRIBUTES = process.env.OTEL_RESOURCE_ATTRIBUTES || '';
const OTEL_TRACE_EXPORTER = process.env.OTEL_TRACE_EXPORTER || 'console';

const extractOtelAttributes = () => {
  const opentelemetryAttributes = {};
  const otelAttributes = OTEL_RESOURCE_ATTRIBUTES.split(',');

  otelAttributes.forEach((otelAttribute) => {
    const keyAndValue = otelAttribute.split('=');
    let key = keyAndValue[0];
    const value = keyAndValue[1];
    if (key === 'service.name') {
      key = SemanticResourceAttributes.SERVICE_NAME;
    }
    opentelemetryAttributes[key] = value;
  });

  return opentelemetryAttributes;
};

const provider = new NodeTracerProvider({
  resource: new Resource(extractOtelAttributes()),
});

if (process.env.OTEL_TRACE_DEBUGGER === 'true') {
  diag.setLogger(new DiagConsoleLogger(), DiagLogLevel.ALL);
}

// If bootleg, use otlp
if (OTEL_TRACE_EXPORTER === 'otlp') {
  const createCredentials = () => {
    const tlsCredentials = grpc.credentials.createSsl();
    // Do not verify server certificate (self-signed)
    tlsCredentials.connectionOptions.rejectUnauthorized = false;
    return tlsCredentials;
  };

  const openTelemetryCollectorUrl = process.env.OTEL_EXPORTER_OTLP_ENDPOINT;
  const collectorOptions = {
    url: openTelemetryCollectorUrl,
    credentials: createCredentials(),
  };
  const openTelemetryExporter = new CollectorTraceExporter(collectorOptions);
  provider.addSpanProcessor(new BatchSpanProcessor(openTelemetryExporter));
}

// If locally, use console
if (OTEL_TRACE_EXPORTER === 'console') {
  const consoleExporter = new ConsoleSpanExporter();
  provider.addSpanProcessor(new BatchSpanProcessor(consoleExporter));
}

provider.register();

registerInstrumentations({
  instrumentations: [
    new PinoInstrumentation({
      // Optional hook to insert additional context to log object.
      logHook: (span, record) => {
        // eslint-disable-next-line no-param-reassign
        record['resource.service.name'] = provider.resource.attributes['service.name'];
      },
    }),
    new ExpressInstrumentation(),
    new HttpInstrumentation(),
    new DnsInstrumentation(),
  ],
});
