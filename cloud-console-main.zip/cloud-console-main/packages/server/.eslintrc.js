const path = require('path');

module.exports = {
  parser: '@babel/eslint-parser',
  root: true,
  extends: ['oss-ui-base', 'plugin:jest/recommended'],
  rules: {
    // -----------------------------------------------
    // The following is actually turned off on purpose
    // -----------------------------------------------
    'import/no-extraneous-dependencies': [
      'error',
      {
        devDependencies: ['./src/**/__tests__/*.*', './src/*.pact.ts'],
      },
    ],
  },
  overrides: [
    {
      files: ['**/*.ts'],
      extends: ['oss-ui-base', 'oss-ui-typescript', 'prettier'],
      parser: '@typescript-eslint/parser',
      parserOptions: {
        project: path.join(__dirname, 'tsconfig.json'),
        requireConfigFile: false,
        babelOptions: {
          babelrc: false,
          configFile: false,
          // your babel options
          presets: ['@babel/preset-env'],
        },
      },
      rules: {
        'import/no-unresolved': 'off',
        // -----------------------------------------------
        // The following is actually turned off on purpose
        // -----------------------------------------------
        'import/no-extraneous-dependencies': [
          'error',
          {
            devDependencies: ['./src/**/__tests__/*.*', './src/*.pact.ts'],
          },
        ],
        '@typescript-eslint/no-misused-promises': ['error', { checksVoidReturn: false }],
      },
    },
  ],
  env: { es6: true },
  globals: { process: true },
  parserOptions: { ecmaVersion: 2018, sourceType: 'module' },
  plugins: ['babel'],
};
