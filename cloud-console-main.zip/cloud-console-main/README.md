# Digipass Management Cloud Console

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Installation](#installation)
3. [Packages](#packages)
4. [Tutorials and guidelines](#tutorials-and-guidelines)

### Prerequisites

- Install [node LTS >16.x](https://nodejs.org/en/download/)
- Install yarn `npm install -g yarn`
- Upgrade yarn `npm upgrade --global yarn` (Optional)

### Installation

```sh
# install required dependencies
yarn install

# install git hooks
yarn prepare
```

### Packages

* [Client](./packages/client/README.md)
* [Server](./packages/server/README.md)

### Tutorials and guidelines

* [Frontend Architecture](https://jira.onespan.com/confluence/display/EAG/Frontend+Architecture)
* [Common mistakes with React Testing Library](https://kentcdodds.com/blog/common-mistakes-with-react-testing-library)




